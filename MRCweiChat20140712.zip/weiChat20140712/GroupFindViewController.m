//
//  GroupFindViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "GroupFindViewController.h"
#import "GroupChatViewController.h"
#import "GroupCreateViewController.h"
#import "GroupAddViewController.h"
@interface GroupFindViewController ()

@end

@implementation GroupFindViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    //创建数据
    [self loadData];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [_searchBar resignFirstResponder];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"群列表";
    self.resultDataArray=[NSMutableArray arrayWithCapacity:0];
    //创建UI
    [self createTableView];
  
    //创建右导航
    [self createRightNav];
    [self themeColor];
    _tableView.backgroundColor=[UIColor clearColor];
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bg_default.jpg",self.path ]]];
    
    
}
-(void)createRightNav{
    UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 40, 40) ImageName:nil Target:self Action:@selector(rightNavClick) Title:nil];
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithCustomView:button];
    self.navigationItem.rightBarButtonItem=item;
    [item release];
    //设置右边按钮图片
    UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_icon_single@2x.png",self.path]];
    [button setImage:image forState:UIControlStateNormal];
    

}

-(void)rightNavClick{

    if (lx==nil) {
        lx=[[LXActivity alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"cancel" ShareButtonTitles:@[@"创建",@"加入"] withShareButtonImagesName:@[@"contact_creat_group.png",@"contact_friend.png"]];
        [self.view addSubview:lx];
        [lx release];
    }
    
    
    
}
-(void)didClickOnImageIndex:(NSInteger *)imageIndex{
   
    if ((int)imageIndex==1) {
       //加入
        GroupAddViewController*vc=[[GroupAddViewController alloc]init];
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
        
    }else{
        GroupCreateViewController*vc=[[GroupCreateViewController alloc]init];
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
    }
   
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString*roomJid=nil;
    if (tableView==_tableView) {
        roomJid= [self.dataArray[indexPath.row] objectForKey:@"roomJid"];
    }else{
     roomJid= [self.resultDataArray[indexPath.row] objectForKey:@"roomJid"];
    }
  
    roomJid=[[roomJid componentsSeparatedByString:@"@"]firstObject];
    GroupChatViewController*vc=[[GroupChatViewController alloc]init];
    vc.roomJid=roomJid;
    vc.title=[self.dataArray[indexPath.row]objectForKey:@"roomName"];
    vc.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
}

-(void)loadData{
//发现服务
    //block返回的是一个可变字典
    [[ZCXMPPManager sharedInstance]searchXmppRoomBlock:^(NSMutableArray * roomArray) {
        
        
        self.dataArray=[NSArray arrayWithArray:roomArray];
        [_tableView reloadData];
    }];
    
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    
    [_tableView release];
    
    _searchBar=[[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    _searchBar.delegate=self;
    _searchBar.showsCancelButton=YES;
    _searchBar.searchBarStyle=UISearchBarStyleMinimal;
    UIImage*searchBarImage=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@searchbar_icon_search.png",self.path]];
    [_searchBar setImage:searchBarImage forSearchBarIcon:UISearchBarIconSearch state:UIControlStateNormal];
    _searchBar.placeholder=@"搜索";
    
    if (0) {
        _searchBar.showsBookmarkButton=YES;
        UIImage*searchBarBookImage=[UIImage imageNamed:@"audio_mic_big.png"];
        [_searchBar setImage:searchBarBookImage forSearchBarIcon:UISearchBarIconBookmark state:UIControlStateNormal];
    }
  
    searchDisplayController=[[UISearchDisplayController alloc]initWithSearchBar:_searchBar contentsController:self];
   
    searchDisplayController.searchResultsDataSource=self;
    searchDisplayController.searchResultsDelegate=self;
    _tableView.tableHeaderView=_searchBar;
   
    [[[_tableView subviews]objectAtIndex:0] removeFromSuperview];
    


}
-(void)searchBarBookmarkButtonClicked:(UISearchBar *)searchBar
{

}
-(void)searchDisplayControllerDidBeginSearch:(UISearchDisplayController *)controller
{

    
}
//点击搜索
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{

}
//输入的每一个字符
-(BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    return YES;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    if (tableView== _tableView) {
         return self.dataArray.count;
    }else{
        [self searchModel];
        return  self.resultDataArray.count;
    }
   
}
-(void)searchModel{
    //清空旧的数据
    /*
     {
     roomJid = "11111@room11.1000phone.net";
     roomName = 11111;
     }
     */
    [self.resultDataArray removeAllObjects];
    for (NSDictionary*dic in self.dataArray) {
        NSString*str=[dic objectForKey:@"roomJid"];
        NSString*str1=[dic objectForKey:@"roomName"];
        NSRange range=[str rangeOfString:_searchBar.text];
        NSRange range1=[str1 rangeOfString:_searchBar.text];
        if (range.location!=NSNotFound||range1.location!=NSNotFound) {
            [self.resultDataArray addObject:dic];
        }
    }
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
    }
    if (tableView== _tableView) {
          cell.textLabel.text=[self.dataArray[indexPath.row] objectForKey:@"roomName"];
    }else{
    cell.textLabel.text=[self.resultDataArray[indexPath.row] objectForKey:@"roomName"];
    }
  
    
    
    return cell;

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
