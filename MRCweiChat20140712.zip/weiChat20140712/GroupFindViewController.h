//
//  GroupFindViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"
#import "LXActivity.h"
@interface GroupFindViewController : RootViewController<UIAlertViewDelegate,LXActivityDelegate,UISearchBarDelegate,UISearchDisplayDelegate>
{

    UISearchDisplayController*searchDisplayController;
    UISearchBar*_searchBar;
    LXActivity*lx;
}
@property(nonatomic,retain)NSArray*dataArray;
@property(nonatomic,retain)NSMutableArray*resultDataArray;
@end
