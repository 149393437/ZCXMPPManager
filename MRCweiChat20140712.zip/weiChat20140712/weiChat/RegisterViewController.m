//
//  RegisterViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/11.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()

@end

@implementation RegisterViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.userName.delegate=self;
    self.userName.returnKeyType=UIReturnKeyNext;
    self.passWord.delegate=self;
    self.passWord.returnKeyType=UIReturnKeyNext;
    self.passWord1.delegate=self;
    self.passWord1.returnKeyType=UIReturnKeyGo;
    
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)backClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (IBAction)registerClick:(id)sender {
    
    if (self.userName.text.length!=0&&self.passWord.text.length!=0&&self.passWord1.text.length!=0&&[self.passWord.text isEqualToString:self.passWord1.text]) {
        
        NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
        [defaults setObject:self.userName.text forKey:kXMPPmyJID];
        [defaults setObject:self.passWord.text forKey:kXMPPmyPassword];
        [defaults synchronize];
        ZCXMPPManager*manager=[ZCXMPPManager sharedInstance];
        [manager registerMothod:^(BOOL isFinish) {
            if (isFinish) {
                [self dismissViewControllerAnimated:YES completion:nil];
            }else{
                NSLog(@"用户名重复");
                UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"用户名重复，请重新输入" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                [al show];
                [al release];
            }
        }];
        
    }
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    //收回全部键盘
    [self.view endEditing:YES];
  
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==self.passWord1) {
        [self.view endEditing:YES];
        [self registerClick:nil];
    }
    if (textField==self.passWord) {
        [self.passWord1 becomeFirstResponder];
    }
    if (textField==self.userName) {
        [self.passWord becomeFirstResponder];
    }
   
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [_userName release];
    [_passWord release];
    [_passWord1 release];
    [super dealloc];
}
@end
