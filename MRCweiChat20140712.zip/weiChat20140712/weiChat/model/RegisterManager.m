//
//  RegisterManager.m
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RegisterManager.h"

@implementation RegisterManager
static RegisterManager *manager=nil;
+(id)shareManage{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager=[[RegisterManager alloc]init];
    });
    
    return manager;

}
@end
