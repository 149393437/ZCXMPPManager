//
//  ThemeManager.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThemeManager : NSObject
@property(nonatomic,retain)NSMutableArray*dataArray;
@property(nonatomic,copy)void(^BlockDownload)();
@property(nonatomic,copy)void(^BlockBubbleDownload)();
@property(nonatomic,copy)void(^BlockChatBackGround)();
+(id)shareManager;
-(BOOL)isDownLoadFinish:(NSDictionary*)dic Block:(void(^)())a;
-(BOOL)isBubbleDownLoadFinish:(NSDictionary *)dic Block:(void (^)())a;
-(BOOL)isChatBackGroundFinish:(int)name Block:(void(^)())a;

@end
