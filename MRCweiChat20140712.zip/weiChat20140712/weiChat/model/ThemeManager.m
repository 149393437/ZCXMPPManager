
//
//  ThemeManager.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "ThemeManager.h"
#import "ZipArchive.h"
#define CHATBACKGROUND @"chatBackGround"
@implementation ThemeManager
static ThemeManager *manager=nil;
+(id)shareManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager=[[ThemeManager alloc]init];
        manager.dataArray=[NSMutableArray arrayWithArray:[manager loadPlist]];
    });
    
    return manager;
}
//下载背景
-(BOOL)isChatBackGroundFinish:(int)name Block:(void(^)())a{
    self.BlockChatBackGround=a;
    
    NSString*str=[NSString stringWithFormat:@"%d",name];
    //读取已经下载的
    NSString*path=[NSString stringWithFormat:@"%@/Documents/chatBg.plist",NSHomeDirectory()];
    
    NSArray*array=[NSArray arrayWithContentsOfFile:path];
    NSMutableArray*tempArray;
    if (!array) {
        tempArray=[NSMutableArray arrayWithCapacity:0];
      
        
    }else{
        tempArray=[NSMutableArray arrayWithArray:array];
    }
    
    if ([tempArray containsObject:str]) {
        //更改主题
        NSUserDefaults*user=  [NSUserDefaults standardUserDefaults];
        [user setObject:str forKey:CHATBACKGROUND];
        [user synchronize];
        
        return YES;
    }else{
        
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSData*data=[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://appimg1.3g.qq.com/msoft/mobileQQ_theme/ios_chagBg/chat_bg_%d.jpg",100+name]]];
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if (data) {
                    [data writeToFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_%d.jpg",NSHomeDirectory(),name+100] atomically:YES];
                    //更新记录
                    [tempArray addObject:str];
                    [tempArray writeToFile:path atomically:YES];
                    NSUserDefaults*user=  [NSUserDefaults standardUserDefaults];
                    [user setObject:str forKey:CHATBACKGROUND];
                    [user synchronize];
                }
                self.BlockChatBackGround();
                
            });
        });
        
        return NO;
    }
    
    

}

-(NSArray*)loadPlist{
    NSString*path=[NSString stringWithFormat:@"%@/Documents/downloadTheme.plist",NSHomeDirectory()];
    NSArray*array=[NSArray arrayWithContentsOfFile:path];
    return array;
}
-(BOOL)isBubbleDownLoadFinish:(NSDictionary *)dic Block:(void (^)())a{
    self.BlockBubbleDownload=a;
    NSString*str=[dic objectForKey:@"name"];
    
    if ( [manager.dataArray containsObject:str]) {
        //更改本地主题路径
        NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
        [defaults setValue:str forKey:BUBBLE];
        [defaults synchronize];

        return YES;
    }else {
        //需要注意的：下载完成后，在保存主题，传值需要传整体字典
        [self bubbleDownLoading:dic];
        
        return NO;
    }

    
}
-(void)bubbleDownLoading:(NSDictionary*)dic{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        int a=[[dic objectForKey:@"id"]intValue];
        NSData*data=[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://imgcache.qq.com/club/item/avatar/zip/%d/i%d/all.zip",a%10,a]]];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (data) {
                //写成文件
                NSString*path=[NSString stringWithFormat:@"%@/Documents/bubbleData.zip",NSHomeDirectory()];
                [data writeToFile:path atomically:YES];
                //解压缩
                ZipArchive*zip=[[ZipArchive alloc]init];
                //打开压缩包
                [zip UnzipOpenFile:path];
                //解压缩到哪
                NSString*toPath=[NSString stringWithFormat:@"%@/Documents/%@",NSHomeDirectory(),[dic objectForKey:@"name"]];
                [zip UnzipFileTo:toPath overWrite:YES];
                //关闭解压缩
                [zip UnzipCloseFile];
                [zip release];
                
                
                
                //追加新的完成下载的主题
                [self.dataArray addObject:[dic objectForKey:@"name"]];
                //写入plist
                [self.dataArray writeToFile:[NSString stringWithFormat:@"%@/Documents/downloadTheme.plist",NSHomeDirectory()] atomically:YES];
                
                //更换本地主题
                NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
                [defaults setValue:[dic objectForKey:@"name"] forKey:BUBBLE];
                [defaults synchronize];
                
                //回调blcok
                if (self.BlockBubbleDownload) {
                    self.BlockBubbleDownload();
                }

            }
        });
    });


}
-(BOOL)isDownLoadFinish:(NSDictionary*)dic Block:(void(^)())a{
    
    //记录回调方法
    self.BlockDownload=a;
    //判断文件是否已经下载
    NSString*str=[dic objectForKey:@"name"];
    
    if ( [manager.dataArray containsObject:str]) {
    //更改本地主题路径
        NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
        [defaults setValue:str forKey:THEME];
        [defaults synchronize];
    //发出通知
        [[NSNotificationCenter defaultCenter]postNotificationName:THEME object:nil];
        return YES;
    }else {
    //需要注意的：下载完成后，在保存主题，传值需要传整体字典
        [self downloading:dic];
        
        return NO;
    }
    

}
-(void)downloading:(NSDictionary*)dic{
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSData*data=[NSData dataWithContentsOfURL:[NSURL URLWithString:[dic objectForKey:@"url"]]];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //写成文件
            if (data) {
                NSString*path=[NSString stringWithFormat:@"%@/Documents/data.zip",NSHomeDirectory()];
                [data writeToFile:path atomically:YES];
                //解压缩
                ZipArchive*zip=[[ZipArchive alloc]init];
                //打开压缩包
                [zip UnzipOpenFile:path];
                //解压缩到哪
                NSString*toPath=[NSString stringWithFormat:@"%@/Documents/%@",NSHomeDirectory(),[dic objectForKey:@"name"]];
                [zip UnzipFileTo:toPath overWrite:YES];
                //关闭解压缩
                [zip UnzipCloseFile];
                [zip release];
                
                
                
                //追加新的完成下载的主题
                [self.dataArray addObject:[dic objectForKey:@"name"]];
                //写入plist
                [self.dataArray writeToFile:[NSString stringWithFormat:@"%@/Documents/downloadTheme.plist",NSHomeDirectory()] atomically:YES];
                
                //更换本地主题
                NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
                [defaults setValue:[dic objectForKey:@"name"] forKey:THEME];
                [defaults synchronize];
                
                //发出通知
                [[NSNotificationCenter defaultCenter]postNotificationName:THEME object:nil];
                //回调blcok
                self.BlockDownload();
            }
           
            
            
        });
    });
    

}


@end
