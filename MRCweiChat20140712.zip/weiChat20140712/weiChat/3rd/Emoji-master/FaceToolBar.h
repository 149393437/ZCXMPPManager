//
//  FaceToolBar.h
//  TestKeyboard
//
//  Created by wangjianle on 13-2-26.
//  Copyright (c) 2013年 wangjianle. All rights reserved.
//
/*
功能说明：
主要模仿QQ的语音表情等状态

 
集成说明：
 需要添加系统库
 libz  imageIO quartzCore
 
示例代码
 toolBar=[[FaceToolBar alloc]initWithFrame:CGRectMake(0, 100, 320, 44) voice:button ViewController:self Block:^(NSString *sign, NSString *value) {
 
 NSLog(@"%@~~%@",sign,value);
 }];
 
 [self.view addSubview:toolBar];
 [toolBar release];
 
 */


#define Time  0.25

#define  keyboardHeight 216
#define  toolBarHeight 45
#define  choiceBarHeight 35
#define  facialViewWidth 300
#define facialViewHeight 170
#define  buttonWh 34

#import <UIKit/UIKit.h>

#import "UIExpandingTextView.h"
/****表情SDK***/
#import "StickerInputView.h"
#import "StickerImageView.h"
#import "StickerInfo.h"
#import "EmojiInfo.h"
#import "StickerConfig.h"
#import "LXActivity.h"

@interface FaceToolBar : UIToolbar<UIExpandingTextViewDelegate,UIScrollViewDelegate,StickerInputViewDelegate,LXActivityDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UIExpandingTextView *textView;//文本输入框
    UIButton *faceButton ;
    UIButton *voiceButton;
    UIButton *sendButton;
    BOOL keyboardIsShow;//键盘是否显示
   
    BOOL isOpenVoide;
    
    //表情SDK的输入界面
    StickerInputView * stickerInputView;
    
}
//传值的block 第一个参数是标示[1]  第二个参数是内容
@property(nonatomic,copy)void(^BlockValue)(NSString*,NSString*);
@property(nonatomic,assign)UIViewController*vc;
//记录图片路径
@property(nonatomic,copy)NSString*path;

-(void)dismissKeyBoard;
-(id)initWithFrame:(CGRect)frame voice:(UIButton*)voice ViewController:(UIViewController*)vc Block:(void(^)(NSString*,NSString*))a;

@end
