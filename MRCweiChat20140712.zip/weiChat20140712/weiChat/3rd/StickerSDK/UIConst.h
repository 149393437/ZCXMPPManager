//
//  UIConst.h
//  StickerSDKDemo
//
//  Created by dongmike on 13-11-27.
//  Copyright (c) 2013年 dong mike. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define   STICKER_BACKGROUND_COLOR          [UIColor colorWithRed:0xeb/255.0 green:0xeb/255.0 blue:0xeb/255.0 alpha:1.0]
#define   CONTROLLER_BACKGROUND_COLOR       [UIColor colorWithRed:0xf5/255.0 green:0xf6/255.0 blue:0xf8/255.0 alpha:1.0]