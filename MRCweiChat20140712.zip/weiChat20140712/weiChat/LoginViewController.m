//
//  LoginViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/11.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "LoginViewController.h"

#import "MainTabBarController.h"
#import "RegisterViewController1.h"
@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
    self.userName.text=[defaults objectForKey:kXMPPmyJID];
    self.passWord.text=[defaults objectForKey:kXMPPmyPassword];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyBoardShow) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardHide) name:UIKeyboardDidHideNotification object:nil];
    [self createView];
}
#pragma mark 设置键盘弹出和消失
-(void)keyBoardShow{
    self.view.frame=CGRectMake(0, -64, 320, [UIScreen mainScreen].bounds.size.height);
    
}
-(void)keyboardHide{
    self.view.frame=CGRectMake(0, 0, 320, [UIScreen mainScreen].bounds.size.height);
}
#pragma mark 触摸屏幕时候，收回键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    //全部键盘收回
    [self.view endEditing:YES];

}

#pragma mark 设置xib页面
-(void)createView{
//关于imageView需要设置用户交互打开
    self.bgImageView.userInteractionEnabled=YES;
//textfield左边的图片
    UIImageView*leftImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"userName.png"]];
    self.userName.leftView=leftImageView;
    self.userName.leftViewMode=UITextFieldViewModeAlways;
    self.userName.delegate=self;
    self.userName.returnKeyType=UIReturnKeyNext;
    UIImageView*leftImageView1=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"passWord.png"]];
    self.passWord.leftView=leftImageView1;
    self.passWord.leftViewMode=UITextFieldViewModeAlways;
    self.passWord.delegate=self;
    self.passWord.returnKeyType=UIReturnKeyGo;
    
    
    //    [self.loginButton addTarget:self action:@selector(loginClick) forControlEvents:UIControlEventTouchUpInside];
//    [self.registerButton addTarget:self action:@selector(registerClick) forControlEvents:UIControlEventTouchUpInside];

    
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==self.passWord) {
        [self.view endEditing:YES];
        [self loginClick:nil];
    }else{
        [self.passWord becomeFirstResponder];
    }
   
    return YES;
}
//登录接口
- (IBAction)loginClick:(id)sender {
    
    if (self.userName.text.length!=0&&self.passWord.text.length!=0) {
        //本地储存用户名密码，进行登录
        NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
        [defaults setObject:self.userName.text forKey:kXMPPmyJID];
        [defaults setObject:self.passWord.text forKey:kXMPPmyPassword];
        [defaults synchronize];
        
        //开启xmpp单例
        ZCXMPPManager*manager=[ZCXMPPManager sharedInstance];
        //执行登录
        [manager connectLogoin:^(BOOL isFinish) {
            if (isFinish) {
                //登录成功，进入主界面
                NSLog(@"登录成功~~哈哈哈哈");
                //本地进行记录第一次登录成功
                MainTabBarController *main=[[MainTabBarController alloc]init];
                [self presentViewController:main animated:YES completion:^{
                   //主要解决第一次登录的问题，在MainTabBar执行完ViewDidLoad时候，会在执行这里
                    NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
                    [defaults setValue:ISLOGIN forKey:ISLOGIN];
                    [defaults synchronize];
                }];
                [main release];
                
                
                
                
            }else{
            //失败
                UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"账户或者密码错误，请重试" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                [al show];
                [al release];
            }
        }];
        
        
        
        
        
    }
    
    
    
}
//注册接口
- (IBAction)registerClick:(id)sender {
    
    RegisterViewController1*vc=[[RegisterViewController1    alloc]init];
    UINavigationController*nc=[[UINavigationController alloc]initWithRootViewController:vc];
    [self presentViewController:nc animated:YES completion:nil];
    [nc release];
}
//-(void)loginClick{
//
//}
//-(void)registerClick{
//
//}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_bgImageView release];
    [_userName release];
    [_passWord release];
    [_loginButton release];
    [_registerButton release];
    [super dealloc];
}
@end
