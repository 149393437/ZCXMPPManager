//
//  GroupCheckCell.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/23.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoundImageView.h"
@interface GroupCheckCell : UITableViewCell
{
    RoundImageView*headerImageView;
    UILabel*groupName;
    UILabel*FromName;
 
}
@property(nonatomic,assign)UIButton*agreeButton;
@property(nonatomic,assign)UIButton*rejectButton;
-(void)configUI:(NSDictionary*)dic;
@end
