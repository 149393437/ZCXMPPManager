//
//  PersonTableViewCell.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "PersonTableViewCell.h"
#import "UIImageView+WebCache.h"
@implementation PersonTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    headerImageView=[[RoundImageView alloc]initWithFrame:CGRectMake(10, 10, 44, 44)];
    headerImageView.image=[UIImage imageNamed:@"logo_2@2x.png"];
    [self.contentView addSubview:headerImageView];
    [headerImageView release];
    friendName =[ZCControl createLabelWithFrame:CGRectMake(60, 10, 250, 30) Font:20 Text:nil];
    friendName.numberOfLines=1;
    [self.contentView addSubview:friendName];
    qmdLabel =[ZCControl createLabelWithFrame:CGRectMake(60, 35, 250, 20) Font:12 Text:nil];
    qmdLabel.numberOfLines=1;
    [self.contentView addSubview:qmdLabel];
    UIView*view=[[UIView alloc]initWithFrame:CGRectMake(54, 59, 320-54, 1)];
    view.backgroundColor=[UIColor grayColor];
    [self.contentView addSubview:view];
    
}
-(void)configUI:(NSDictionary*)dic{
    //获得用户vcard
    NSString*useid=[dic objectForKey:@"jid"];
    //进行字符串切割，切割出前面的用户名
    useid=[[useid componentsSeparatedByString:@"@"]firstObject];
    XMPPvCardTemp*vard=[[ZCXMPPManager sharedInstance]friendsVcard:useid];
    if (vard.photo) {
        headerImageView.image=[UIImage imageWithData:vard.photo];
    }else{
        [headerImageView setImageWithURL:[NSURL URLWithString:[dic objectForKey:@"headImageURL"]] placeholderImage:[UIImage imageNamed:@"logo_2@2x.png"]];
    }
    
    if (vard.nickname) {
        friendName.text=vard.nickname;
    }else{
        friendName.text=useid;
    }
    
    
    if ([[vard elementForName:@"QMD"]stringValue]) {
        qmdLabel.text=[[vard elementForName:@"QMD"]stringValue];
    }else{
        qmdLabel.text=@"这家伙很懒，什么也没留下";
    }

}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
