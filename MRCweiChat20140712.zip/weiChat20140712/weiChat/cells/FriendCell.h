//
//  FriendCell.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/24.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoundImageView.h"
@interface FriendCell : UITableViewCell
{
    RoundImageView*headerImageView;
    UILabel*friendName;
    UILabel*qmdLabel;
}
-(void)configUI:(XMPPUserCoreDataStorageObject*)objcet;
@end
