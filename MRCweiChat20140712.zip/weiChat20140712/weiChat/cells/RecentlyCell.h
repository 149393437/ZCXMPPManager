//
//  RecentlyCell.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/24.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoundImageView.h"
@interface RecentlyCell : UITableViewCell
{
    RoundImageView*headerImageView;
    UILabel*friendName;
    UILabel*contentLabel;
}
-(void)configUI:(NSArray*)array;
@end
