//
//  RoundImageView.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/23.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RoundImageView.h"
#import <QuartzCore/QuartzCore.h>
@implementation RoundImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius=20;
        self.layer.masksToBounds=YES;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
