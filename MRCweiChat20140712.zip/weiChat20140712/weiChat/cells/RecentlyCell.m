//
//  RecentlyCell.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/24.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RecentlyCell.h"

@implementation RecentlyCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    headerImageView=[[RoundImageView alloc]initWithFrame:CGRectMake(10, 10, 44, 44)];
    headerImageView.image=[UIImage imageNamed:@"logo_2@2x.png"];
    [self.contentView addSubview:headerImageView];
    [headerImageView release];
    friendName =[ZCControl createLabelWithFrame:CGRectMake(60, 10, 250, 20) Font:20 Text:nil];
    friendName.numberOfLines=1;
    [self.contentView addSubview:friendName];
    contentLabel =[ZCControl createLabelWithFrame:CGRectMake(60, 35, 250, 20) Font:12 Text:nil];
    [self.contentView addSubview:contentLabel];
    UIView*view=[[UIView alloc]initWithFrame:CGRectMake(54, 59, 320-54, 1)];
    view.backgroundColor=[UIColor grayColor];
    [self.contentView addSubview:view];

}
-(void)configUI:(NSArray*)array{
   friendName.text=array[2];
    
    if ([array[0] hasPrefix:MESSAGE_STR]) {
        contentLabel.text=[array[0] length]>=3? [array[0]substringFromIndex:3]:@"未知？？";
    }
    if ([array[0] hasPrefix:MESSAGE_VOICE]) {
        contentLabel.text=@"[语音消息]";
    }
    if ([array[0]hasPrefix:MESSAGE_IMAGESTR]) {
        contentLabel.text=@"[图片]";
    }
    if ([array[0]hasPrefix:MESSAGE_BIGIMAGESTR]) {
        contentLabel.text=@"[表情]";
    }
    
    NSString*str=[array lastObject];
    if ([str isEqualToString:SOLECHAT]) {
        //单人
        XMPPvCardTemp*vcard=  [[ZCXMPPManager sharedInstance]friendsVcard:array[2]];
        
        if (vcard.nickname) {
            friendName.text=vcard.nickname;
        }
        if (vcard.photo) {
            headerImageView.image=[UIImage imageWithData:vcard.photo];
        }else{
          headerImageView.image=[UIImage imageNamed:@"logo_2@2x.png"];
        }
    }else{
        str=[str substringFromIndex:3];
        if (str) {
            friendName.text=str;
        }
    }

    
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
