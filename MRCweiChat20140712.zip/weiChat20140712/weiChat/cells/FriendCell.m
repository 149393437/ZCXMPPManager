//
//  FriendCell.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/24.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "FriendCell.h"

@implementation FriendCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    headerImageView=[[RoundImageView alloc]initWithFrame:CGRectMake(10, 10, 44, 44)];
    headerImageView.image=[UIImage imageNamed:@"logo_2@2x.png"];
    [self.contentView addSubview:headerImageView];
    [headerImageView release];
    friendName =[ZCControl createLabelWithFrame:CGRectMake(60, 10, 250, 30) Font:20 Text:nil];
    friendName.numberOfLines=1;
    [self.contentView addSubview:friendName];
    qmdLabel =[ZCControl createLabelWithFrame:CGRectMake(60, 35, 250, 20) Font:12 Text:nil];
    qmdLabel.numberOfLines=1;
    [self.contentView addSubview:qmdLabel];
    UIView*view=[[UIView alloc]initWithFrame:CGRectMake(54, 59, 320-54, 1)];
    view.backgroundColor=[UIColor grayColor];
    [self.contentView addSubview:view];
    
}
-(void)configUI:(XMPPUserCoreDataStorageObject*)objcet{
    NSString*zhanghao=[[objcet.jidStr componentsSeparatedByString:@"@"]firstObject];
//    
   //获得头像,开辟线程，解决卡顿的问题
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
         UIImage*image=[[ZCXMPPManager sharedInstance]avatarForUser:objcet];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (image) {
                headerImageView.image=image;
            }
        });
    });
   
   
    //获得好友的vcard
     XMPPvCardTemp*vcard=[[ZCXMPPManager sharedInstance]friendsVcard:zhanghao];
    
    
    if (vcard.nickname) {
       friendName.text=vcard.nickname;
    }else{
        friendName.text=objcet.jidStr;
    }
    
    if ([[vcard elementForName:@"QMD"]stringValue]) {
        qmdLabel.text=[[vcard elementForName:@"QMD"]stringValue];
    }else{
        qmdLabel.text=@"这家伙很懒，什么也没留下";
    }


}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
