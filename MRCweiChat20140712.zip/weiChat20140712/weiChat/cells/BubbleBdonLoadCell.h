//
//  BubbleBdonLoadCell.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/20.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BubbleBdonLoadCell : UITableViewCell
{
    UIView*rightView;
    UIView*leftView;
}
@property(nonatomic,assign)UIButton*leftButton;
@property(nonatomic,assign)UIButton*rightButton;
-(void)configUILeftModel:(NSDictionary*)dic rightModel:(NSDictionary*)dic1;
@end
