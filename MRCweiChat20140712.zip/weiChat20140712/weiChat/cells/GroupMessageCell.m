//
//  GroupMessageCell.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "GroupMessageCell.h"
#import "Photo.h"
#import "ZCChatAVAdioPlay.h"
#import "NSData+Base64.h"
@implementation GroupMessageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createMakeUI];
    }
    return self;
}
//创建UI
-(void)createMakeUI{
    //获得图片路径
    self.path=[NSString stringWithFormat:@"%@/Documents/%@/",NSHomeDirectory(),[[NSUserDefaults standardUserDefaults] objectForKey:THEME]];
    
    //左边
    //头像
    leftHeaderImageView=[ZCControl createImageViewWithFrame:CGRectMake(5, 5, 30, 30) ImageName:@"logo_2@2x.png"];
    leftHeaderImageView.layer.cornerRadius=15;
    leftHeaderImageView.layer.masksToBounds=YES;
    

    [self.contentView addSubview:leftHeaderImageView];
    
    
    //    //气泡底图
    UIImage*image=nil;
    NSString*str=[[NSUserDefaults standardUserDefaults]objectForKey:BUBBLE];
    if (str.length>0) {
        image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/%@/static/aio_user_bg_nor@2x.png",NSHomeDirectory(),str]];
        
    }else{
        image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_send_nor_pic@2x.png",self.path]];
    }
    
    image=[UIImage imageWithCGImage:image.CGImage scale:2 orientation:UIImageOrientationUpMirrored];
    
    image=[image stretchableImageWithLeftCapWidth:40 topCapHeight:25];
    
    leftBgImageView=[ZCControl createImageViewWithFrame:CGRectMake(35, 5, 200, 50) ImageName:nil];
    leftBgImageView.image=image;
    [self.contentView addSubview:leftBgImageView];
    //label 文字类型
    leftLabel=[ZCControl createLabelWithFrame:CGRectMake(5, 5, 10, 10) Font:15 Text:nil];
    //注意不要写错！
    [leftBgImageView addSubview:leftLabel];
    //image 显示普通图片
    leftNormalImageView=[ZCControl createImageViewWithFrame:CGRectMake(5, 5, 20, 20) ImageName:@"logo_2@2x.png"];
    [leftBgImageView addSubview:leftNormalImageView];
    //stickerImageView  显示大表情
    leftStickerImageView=[[StickerImageView alloc]initWithFrame:CGRectMake(5, 5, 200, 200)];
    [leftBgImageView addSubview:leftStickerImageView];
    [leftStickerImageView release];
    //button 显示语音预留接口
    leftVoiceButton=[ZCControl createButtonWithFrame:CGRectMake(5, 5, 60, 40) ImageName:nil Target:self Action:@selector(VoiceButtonClick) Title:nil];
    [leftBgImageView addSubview:leftVoiceButton];
    [leftVoiceButton setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/chat_bottom_voice_nor@2x.png",self.path]] forState:UIControlStateNormal];

    //右边
    //头像
    rightHeaderImageView=[ZCControl createImageViewWithFrame:CGRectMake(320-35, 5, 30, 30) ImageName:@"logo_2@2x.png"];
    rightHeaderImageView.layer.cornerRadius=15;
    rightHeaderImageView.layer.masksToBounds=YES;

    [self.contentView addSubview:rightHeaderImageView];
    //气泡底图
    UIImage*image1=nil;
    if (str.length>0) {
        image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/%@/static/aio_user_bg_nor@2x.png",NSHomeDirectory(),str]];
        
        
        
        
    }else{
        image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_send_nor_pic@2x.png",self.path]];
    }
    
    
    
    
    image1=[image1 stretchableImageWithLeftCapWidth:40 topCapHeight:25];
    rightBgImageView=[ZCControl createImageViewWithFrame:CGRectMake(35, 5, 100, 44) ImageName:nil];
    rightBgImageView.image=image1;
    [self.contentView addSubview:rightBgImageView];
    //label 文字类型
    rightLabel=[ZCControl createLabelWithFrame:CGRectZero Font:15 Text:nil];
   // rightLabel.backgroundColor=[UIColor redColor];
    [rightBgImageView addSubview:rightLabel];
    //image 显示普通图片
    rightNormalImageView=[ZCControl createImageViewWithFrame:CGRectZero ImageName:@"logo_2@2x.png"];
    [rightBgImageView addSubview:rightNormalImageView];
    //stickerImageView  显示大表情
    rightStickerImageView=[[StickerImageView alloc]initWithFrame:CGRectZero];
    [rightBgImageView addSubview:rightStickerImageView];
    
    //button 显示语音预留接口
    rightVoiceButton=[ZCControl createButtonWithFrame:CGRectMake(0, 5, 60, 30) ImageName:nil Target:self Action:@selector(VoiceButtonClick) Title:nil];
    [rightBgImageView addSubview:rightVoiceButton];
    [rightVoiceButton setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/chat_bottom_voice_nor@2x.png",self.path]] forState:UIControlStateNormal];
    
    //label 时间居中
    TimeLabel=[ZCControl createLabelWithFrame:CGRectZero Font:8 Text:nil];
    TimeLabel.textColor=[UIColor grayColor];
    TimeLabel.textAlignment=NSTextAlignmentCenter;
    [self.contentView addSubview:TimeLabel];
    
    if (str.length>0) {
        aniImageView=[[UIImageView alloc]initWithFrame:CGRectZero];
        aniArray=[[NSMutableArray alloc]init];
        
        
        NSFileManager * fm = [NSFileManager defaultManager];
        
        NSArray  *arr =   [fm  directoryContentsAtPath:[NSString stringWithFormat:@"%@/Documents/%@/voice/",NSHomeDirectory(),str]];
        for (int i=0; i<arr.count;i++ ) {
            UIImage*  imagex=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/%@/voice/%04d.png",NSHomeDirectory(),str,i+1]];
            
            [aniArray addObject:imagex];
        }
        
        [self.contentView addSubview:aniImageView];
        aniImageView.animationImages=aniArray;
        aniImageView.animationDuration=2;
        [aniImageView startAnimating];
        [aniImageView release];
        
    }
    

    
}
-(void)configUI:(XMPPMessage*)message MyImage:(UIImage*)myImage{
    if (myImage) {
      rightHeaderImageView.image=myImage;
    }
    NSString*myjid=[[NSUserDefaults standardUserDefaults]objectForKey:kXMPPmyJID];
    
    //是谁
   // [message elementID];
    //内容
    //[message body];

    if ([message.elementID isEqualToString:myjid]) {
        //自己
        rightBgImageView.hidden=NO;
        leftBgImageView.hidden=YES;
        rightHeaderImageView.hidden=NO;
        leftHeaderImageView.hidden=YES;
        //文字
        if ([message.body hasPrefix:MESSAGE_STR]) {
            rightLabel.text=[message.body substringFromIndex:3];
            CGSize size=   [message.body sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(200, 1000)];
            rightLabel.frame=CGRectMake(20, 15, size.width, size.height);
            rightBgImageView.frame=CGRectMake(320-size.width-80, 5, size.width+40, size.height+35);
            rightNormalImageView.hidden=YES;
            rightStickerImageView.hidden=YES;
            rightVoiceButton.hidden=YES;
            rightLabel.hidden=NO;
            
            
        }
        //大表情
        if ([message.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
            rightNormalImageView.hidden=YES;
            rightStickerImageView.hidden=NO;
            rightVoiceButton.hidden=YES;
            rightLabel.hidden=YES;
            
            rightStickerImageView.frame=CGRectMake(15, 15, 200, 200);
            rightBgImageView.frame=CGRectMake(320-70-200, 5, 215, 220);
            
            rightStickerImageView.sticker=[StickerInfo stickerWithID:[message.body substringFromIndex:3]];
        }
        //图片
        if ([message.body hasPrefix:MESSAGE_IMAGESTR]) {
            rightNormalImageView.hidden=NO;
            rightStickerImageView.hidden=YES;
            rightVoiceButton.hidden=YES;
            rightLabel.hidden=YES;
            NSString*photoStr=[message.body substringFromIndex:3];
            
            UIImage*image=[Photo string2Image:photoStr];
            rightNormalImageView.image=image;
            rightNormalImageView.frame=CGRectMake(15, 15, image.size.width<200?image.size.width:200, image.size.height<200?image.size.height:200);
            rightBgImageView.frame=CGRectMake(320-70-rightNormalImageView.frame.size.width-10, 5, rightNormalImageView.frame.size.width+35, rightNormalImageView.frame.size.width+35);
            
        }
        //语音
        if ([message.body hasPrefix:MESSAGE_VOICE]) {
            rightNormalImageView.hidden=YES;
            rightStickerImageView.hidden=YES;
            rightVoiceButton.hidden=NO;
            rightLabel.hidden=YES;
            rightBgImageView.frame=CGRectMake(320-100, 5, 60, 40);
            self.voiceStr=[message.body substringFromIndex:3];

        }
//        TimeLabel.frame=CGRectMake(0, rightBgImageView.frame.size.height-20, 320, 20);
//        TimeLabel.text=[ZCControl stringFromDateWithHourAndMinute:object.timestamp];
         aniImageView.frame=CGRectMake(rightBgImageView.frame.origin.x, rightBgImageView.frame.size.height-30, 30, 40);
        
    }else{
        rightBgImageView.hidden=YES;
        leftBgImageView.hidden=NO;
        rightHeaderImageView.hidden=YES;
        leftHeaderImageView.hidden=NO;
        
   XMPPvCardTemp*temp=     [[ZCXMPPManager sharedInstance]friendsVcard:message.elementID];
        if (temp.photo) {
            leftHeaderImageView.image=[UIImage imageWithData:temp.photo];
        }
        
        //文字
        if ([message.body hasPrefix:MESSAGE_STR]) {
            leftLabel.text=[message.body substringFromIndex:3];
            CGSize size=   [message.body sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(200, 1000)];
            leftLabel.frame=CGRectMake(30, 20, size.width, size.height);
            leftBgImageView.frame=CGRectMake(40, 5, size.width+30+25, size.height+25+25);
            
            leftNormalImageView.hidden=YES;
            leftStickerImageView.hidden=YES;
            leftVoiceButton.hidden=YES;
            leftLabel.hidden=NO;
            
        }
        //大表情
        if ([message.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
            leftNormalImageView.hidden=YES;
            leftStickerImageView.hidden=NO;
            leftVoiceButton.hidden=YES;
            leftLabel.hidden=YES;
            
            leftStickerImageView.frame=CGRectMake(15, 15, 200, 200);
            leftBgImageView.frame=CGRectMake(40, 5, 215, 215);
            
            leftStickerImageView.sticker=[StickerInfo stickerWithID:[message.body substringFromIndex:3]];
        }
        //图片
        if ([message.body hasPrefix:MESSAGE_IMAGESTR]) {
            leftNormalImageView.hidden=NO;
            leftStickerImageView.hidden=YES;
            leftVoiceButton.hidden=YES;
            leftLabel.hidden=YES;
            NSString*photoStr=[message.body substringFromIndex:3];
            UIImage*image=[Photo string2Image:photoStr];
            leftNormalImageView.image=image;
            leftNormalImageView.frame=CGRectMake(15, 15, image.size.width<200?image.size.width:200, image.size.height<200?image.size.height:200);
            leftBgImageView.frame=CGRectMake(40, 5, leftNormalImageView.frame.size.width+35, leftNormalImageView.frame.size.width+35);
            
        }
        //语音
        if ([message.body hasPrefix:MESSAGE_VOICE]) {
            leftNormalImageView.hidden=YES;
            leftStickerImageView.hidden=YES;
            leftVoiceButton.hidden=NO;
            leftLabel.hidden=YES;
            leftBgImageView.frame=CGRectMake(40, 5, 60, 40);
            self.voiceStr=[message.body substringFromIndex:3];
        }
        
//        TimeLabel.frame=CGRectMake(0, leftBgImageView.frame.size.height-20, 320, 20);
//        TimeLabel.text=[ZCControl stringFromDateWithHourAndMinute:object.timestamp];
         aniImageView.frame=CGRectMake(leftBgImageView.frame.size.width+leftBgImageView.frame.origin.y+10, leftBgImageView.frame.size.height-40, 30, 40);
        
    }
    
    aniImageView.animationImages=aniArray;
    aniImageView.animationDuration=2;
    [aniImageView startAnimating];
    
}
#pragma mark 播放语音
-(void)VoiceButtonClick{
    if (self.voiceStr) {
        NSData*data=[NSData dataWithBase64EncodedString:self.voiceStr];
        [[ZCChatAVAdioPlay sharedInstance]playSetAvAudio:data];
        
    }
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
