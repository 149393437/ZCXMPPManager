//
//  MessageCell.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StickerImageView.h"
@interface MessageCell : UITableViewCell
{
//左边
    //头像
    UIImageView*leftHeaderImageView;
    //气泡底图
    UIImageView*leftBgImageView;
    //label 文字类型
    UILabel*leftLabel;
    //image 显示普通图片
    UIImageView*leftNormalImageView;
    //stickerImageView  显示大表情
    StickerImageView*leftStickerImageView;
    //button 显示语音预留接口
    UIButton*leftVoiceButton;

    
    
    
    
//右边
    //头像
    UIImageView*rightHeaderImageView;
    //气泡底图
    UIImageView*rightBgImageView;
    //label 文字类型
    UILabel*rightLabel;
    //image 显示普通图片
    UIImageView*rightNormalImageView;
    //stickerImageView  显示大表情
    StickerImageView*rightStickerImageView;
    //button 显示语音预留接口
    UIButton*rightVoiceButton;
    
    
    //label 时间居中
    UILabel*TimeLabel;
    //显示动画的
    UIImageView*aniImageView;
    NSMutableArray*aniArray;

}
-(void)configUI:(XMPPMessageArchiving_Message_CoreDataObject*)object leftImage:(UIImage*)leftImage rightImage:(UIImage*)rightImage;
@property(nonatomic,copy)NSString*path;
@property(nonatomic,copy)NSString*voiceStr;


@end
