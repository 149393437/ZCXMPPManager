//
//  BubbleBdonLoadCell.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/20.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "BubbleBdonLoadCell.h"
#import "UIButton+WebCache.h"
@implementation BubbleBdonLoadCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    leftView=[[UIView alloc]initWithFrame:CGRectMake(10, 10, 145, 80)];
    leftView.backgroundColor=[UIColor whiteColor];
    [self.contentView addSubview:leftView];
    [leftView release];
    rightView=[[UIView alloc]initWithFrame:CGRectMake(165, 10, 145, 80)];
    rightView.backgroundColor=[UIColor whiteColor];
    [self.contentView addSubview:rightView];
    [rightView release];
    _leftButton=[ZCControl createButtonWithFrame:CGRectMake(13, 13, 139, 74) ImageName:nil Target:nil Action:nil Title:nil];
    [self.contentView addSubview:_leftButton];
    
    _rightButton=[ZCControl createButtonWithFrame:CGRectMake(168, 13, 139, 74) ImageName:nil Target:nil Action:nil Title:nil];
    [self.contentView addSubview:_rightButton];
    

}
-(void)configUILeftModel:(NSDictionary*)dic rightModel:(NSDictionary*)dic1{
    rightView.backgroundColor=[UIColor whiteColor];
    leftView.backgroundColor=[UIColor whiteColor];
    NSString*str=[[NSUserDefaults standardUserDefaults]objectForKey:BUBBLE];
    if ([str isEqualToString:[dic objectForKey:@"name"]] ) {
        leftView.backgroundColor=[UIColor blueColor];
        
    }
    if ([str isEqualToString:[dic1 objectForKey:@"name"]]) {
        rightView.backgroundColor=[UIColor blueColor];
    }
    
int a=[[dic objectForKey:@"id"]intValue];
 [_leftButton setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://i.gtimg.cn/club/item/avatar/img/%d/%d/mobile_list.jpg?max_age=31536000&t=0",a%10,a]] placeholderImage:[UIImage imageNamed:@"watermark template@2x.png"]];
    
    if (dic1) {
        int b=[[dic1 objectForKey:@"id"]intValue];
        [_rightButton setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://i.gtimg.cn/club/item/avatar/img/%d/%d/mobile_list.jpg?max_age=31536000&t=0",b%10,b]] placeholderImage:[UIImage imageNamed:@"watermark template@2x.png"]];
        rightView.hidden=NO;
        _rightButton.hidden=NO;
    }else{
        rightView.hidden=YES;
        _rightButton.hidden=YES;
    }


}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
