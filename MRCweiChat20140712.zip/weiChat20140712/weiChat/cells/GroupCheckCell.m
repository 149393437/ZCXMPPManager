//
//  GroupCheckCell.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/23.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "GroupCheckCell.h"
#import "UIImageView+WebCache.h"
@implementation GroupCheckCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    headerImageView=[[RoundImageView alloc]initWithFrame:CGRectMake(10, 10, 44, 44)];
    headerImageView.image=[UIImage imageNamed:@"logo_2@2x.png"];
    [self.contentView addSubview:headerImageView];
    [headerImageView release];
    groupName =[ZCControl createLabelWithFrame:CGRectMake(60, 10, 250, 20) Font:20 Text:nil];
    [self.contentView addSubview:groupName];
    FromName=[ZCControl createLabelWithFrame:CGRectMake(60, 35, 250, 20) Font:12 Text:nil];
    [self.contentView addSubview:FromName];
    _agreeButton=[ZCControl createButtonWithFrame:CGRectMake(320-130, 5, 60, 40) ImageName:nil Target:nil Action: nil Title:@"同意"];
    [self.contentView addSubview:_agreeButton];
    _rejectButton=[ZCControl createButtonWithFrame:CGRectMake(320-70, 5, 60, 40) ImageName:nil Target:nil Action:nil Title:@"拒绝"];
    FromName.textColor=[UIColor grayColor];
    [self.contentView addSubview:_rejectButton];

}
#pragma mark 配置
-(void)configUI:(NSDictionary*)dic{
    // self.GroupCheck(@{@"from":from,@"to":to,@"reason":reason,@"type":type});
 
    //获得群名字群id是from
    XMPPRoom*room=[[XMPPRoom alloc] initWithRoomStorage:[XMPPRoomCoreDataStorage sharedInstance] jid:[XMPPJID jidWithString:[dic objectForKey:@"from"]] dispatchQueue:dispatch_get_main_queue()];
    if (room.roomSubject) {
        groupName.text=room.roomSubject;
    }else{
        groupName.text=[[[dic objectForKey:@"from"]componentsSeparatedByString:@"@"]firstObject];
    }
    [room release];
    

    
    if ([[dic objectForKey:@"type"]intValue]) {
        _agreeButton.hidden=YES;
        _rejectButton.hidden=YES;
        //获得邀请人的名字 to
        XMPPvCardTemp*vCard= [[ZCXMPPManager sharedInstance] friendsVcard:[[[dic objectForKey:@"to"] componentsSeparatedByString:@"@"] firstObject]];
        if (vCard.nickname) {
            FromName.text=[NSString stringWithFormat:@"%@拒绝了你的邀请",vCard.nickname];
        }else{
            FromName.text=[NSString stringWithFormat:@"%@拒绝了你的邀请",[[[dic objectForKey:@"to"] componentsSeparatedByString:@"@"] firstObject]];
            
        }
    }else{
        _agreeButton.hidden=NO;
        _rejectButton.hidden=NO;
        //获得邀请人的名字 to
        XMPPvCardTemp*vCard= [[ZCXMPPManager sharedInstance] friendsVcard:[[[dic objectForKey:@"to"] componentsSeparatedByString:@"@"] firstObject]];
        if (vCard.nickname) {
            FromName.text=[NSString stringWithFormat:@"%@邀请你加入群",vCard.nickname];
        }else{
            FromName.text=[NSString stringWithFormat:@"%@邀请你加入群",[[[dic objectForKey:@"to"] componentsSeparatedByString:@"@"] firstObject]];
            
        }
    }
    
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
