//
//  PersonTableViewCell.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoundImageView.h"

@interface PersonTableViewCell : UITableViewCell
{
    RoundImageView*headerImageView;
    UILabel*friendName;
    UILabel*qmdLabel;

}
-(void)configUI:(NSDictionary*)dic;
@end
