
//
//  ChatBackgroundViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "ChatBackgroundViewController.h"
#import "ThemeManager.h"
#define CHATBACKGROUND @"chatBackGround"
@interface ChatBackgroundViewController ()

@end

@implementation ChatBackgroundViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //一个点击按钮
    
    //滚动视图
    /*
     思路
     把默认图和下载列表压到指定目录
     
     点击图，判断下载列表，如果没下载，进行下载保存在指定目录，更新下载列表  保存图片名称
     点击相册，选中后，保存在本地，更新下载列表
     
     
     //只记录下载完成列表
     */
    
    
    //显示
    self.dataArray=[NSMutableArray arrayWithObjects:@"chat_bg_default_icon_theme.png",@"chat_bg_101_icon.png",@"chat_bg_102_icon.png",@"chat_bg_103_icon.png",@"chat_bg_104_icon.png",@"chat_bg_105_icon.png",@"chat_bg_106_icon.png",@"chat_bg_107_icon.png",@"chat_bg_108_icon.png",@"chat_bg_109_icon.png",@"chat_bg_110_icon.png",@"chat_bg_111_icon.png", nil];
    [self createScrowller];
    [self themeColor];
    
}
-(void)createScrowller{
    sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 100, 320, self.view.frame.size.height-164)];
    int page=self.dataArray.count/3;
    if (self.dataArray.count%3) {
        page++;
    }
    sc.contentSize=CGSizeMake(320, 100*page);
    view=[[UIImageView alloc]init];
    view.backgroundColor=[UIColor blueColor];
    [sc addSubview:view];
    [view release];
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    NSString*str=[user objectForKey:CHATBACKGROUND];
    if (str==nil||[str integerValue]==12) {
        view.frame=CGRectMake(25, 0, 80, 80);
    }else{
        view.frame=CGRectMake(25+[str intValue]%3*((320-40)/3), [str intValue]/3*((320-40)/3),80, 80);
    }
    
    [self.view addSubview:sc];
    for (int i=0; i<self.dataArray.count; i++) {
        UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(30+i%3*((320-40)/3), 5+i/3*((320-40)/3), 70, 70) ImageName:self.dataArray[i] Target:self Action:@selector(buttonClick:) Title:nil];
        button.tag=i;
        if (i==0) {
            
            if ([[NSUserDefaults standardUserDefaults]objectForKey:CHATBACKGROUND]) {
                UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_12.jpg",NSHomeDirectory()]];
                [button setBackgroundImage:image forState:UIControlStateNormal];
                button.tag=1200;
            }else{
            UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/%@/%@",NSHomeDirectory(),[[NSUserDefaults standardUserDefaults] objectForKey:THEME],self.dataArray[i]]];
             
            
            [button setBackgroundImage:image forState:UIControlStateNormal];
            button.tag=1200;
                   }
        }
        
        [sc addSubview:button];
    }
    
    //创建打开相册按钮
    UIButton*photoButton=[ZCControl createButtonWithFrame:CGRectMake(0, 20, 320, 44) ImageName:nil Target:self Action:@selector(photoClick) Title:@"从相册选择"];
    [self.view addSubview:photoButton];
    
    
    
}
-(void)photoClick{
    
    UIImagePickerController*picker=[[UIImagePickerController alloc]init];
    picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate=self;
    [self presentViewController:picker animated:YES completion:nil];
    [picker release];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
//完成 当选择完成，需要保存img到沙河目录下，然后更新本地储存，并且更新相应的button背景色
    UIImage*image=[info objectForKey:UIImagePickerControllerOriginalImage];
    NSData*data=UIImagePNGRepresentation(image);
    [data writeToFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_12.jpg",NSHomeDirectory()] atomically:YES];
    //更新本地存储
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    [user setObject:@"12" forKey:CHATBACKGROUND];
    [user synchronize];
    //更新button背景色
    UIButton*button=(UIButton*)[sc viewWithTag:1200];
    [button setBackgroundImage:image forState:UIControlStateNormal];
    view.center=button.center;
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
//取消
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)buttonClick:(UIButton*)button{
   
    NSUserDefaults*user= [NSUserDefaults standardUserDefaults];
    if (button.tag==1200) {
        [user removeObjectForKey:CHATBACKGROUND];
        [user synchronize];
        UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/%@/%@",NSHomeDirectory(),[[NSUserDefaults standardUserDefaults] objectForKey:THEME],self.dataArray[0]]];
        
        
        [button setBackgroundImage:image forState:UIControlStateNormal];
        
        
    }else{
        [user setObject:[NSString stringWithFormat:@"%d",button.tag] forKey:CHATBACKGROUND];
        [user synchronize];
    }

    //执行下载，先判断是否有，如果没有下载
    ThemeManager*manager=[ThemeManager shareManager];
    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"" message:@"正在下载背景，马上就好😏" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
   BOOL isFinish= [manager isChatBackGroundFinish:button.tag Block:^{
       [al dismissWithClickedButtonIndex:0 animated:YES];
    }];
    if (isFinish) {
        [al release];
    }else{
        [al show];
    }
    
    
     view.center=button.center;
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
