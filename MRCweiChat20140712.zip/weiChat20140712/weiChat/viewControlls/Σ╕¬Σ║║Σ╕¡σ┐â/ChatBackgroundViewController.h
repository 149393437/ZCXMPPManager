//
//  ChatBackgroundViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface ChatBackgroundViewController : RootViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    //背景选中
    UIImageView*view;
    UIScrollView*sc;
}
@property(nonatomic,retain)NSMutableArray*dataArray;

@end
