//
//  AboutViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/20.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface AboutViewController : RootViewController
{

}
@end
