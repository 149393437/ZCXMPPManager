//
//  ShowMyVcardViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/20.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "ShowMyVcardViewController.h"
#import "QRCodeGenerator.h"
@interface ShowMyVcardViewController ()

@end

@implementation ShowMyVcardViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"二维码";
    self.view.backgroundColor=[UIColor grayColor];
    [self createQRView];
}
-(void)createQRView{
    UIImageView*imageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 300, self.view.frame.size.height-[ZCControl isIOS7]-20) ImageName:nil];
    imageView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:imageView];
    
    
    UIImageView*qrImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 250, 250) ImageName:@"QRBgImage.png"];
    [self.view addSubview:qrImageView];
    NSString*user=[[NSUserDefaults standardUserDefaults]objectForKey:kXMPPmyJID];
    
    CGPoint point=imageView.center;
    qrImageView.center=CGPointMake(point.x, point.y);
    
    
    UIImageView*qrImageView1=[ZCControl createImageViewWithFrame:CGRectMake(89, 122, 95, 97) ImageName:nil];
    qrImageView1.image=[QRCodeGenerator qrImageForString:user imageSize:300];
    [qrImageView addSubview:qrImageView1];
    
    
    UILabel*qrlabel=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 20) Font:8 Text:@"扫一扫上面的二维码图案，加我好友"];
    qrlabel.textColor=[UIColor grayColor];
    [imageView addSubview:qrlabel];
    qrlabel.center=CGPointMake(point.x, point.y+150);
    qrlabel.textAlignment=NSTextAlignmentCenter;
    
    
    UIImageView*header=[ZCControl createImageViewWithFrame:CGRectMake(20, 20, 40, 40) ImageName:nil];
    if (self.myVcard.photo) {
        header.image=[UIImage imageWithData:self.myVcard.photo];
    }else{
    UIImage*image=[UIImage imageNamed:@"logo_2@2x.png"];
        header.image=image;
    }
    [imageView addSubview:header];

    
    UILabel*nameLabel=[ZCControl createLabelWithFrame:CGRectMake(70, 20, 200, 20) Font:15 Text:nil];
    [imageView addSubview:nameLabel];
    if (self.myVcard.nickname) {
        nameLabel.text=self.myVcard.nickname;
    }else{
        nameLabel.text=[[NSUserDefaults standardUserDefaults]objectForKey:kXMPPmyJID];
    }
    UILabel*address=[ZCControl createLabelWithFrame:CGRectMake(70, 40, 200, 20) Font:15 Text:nil];
    [imageView addSubview:address];
    if ([[self.myVcard elementForName:@"DQ"]stringValue]) {
        address.text=[[self.myVcard elementForName:@"DQ"]stringValue];
    }else{
        
    }
    
    

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
