//
//  BubbleDownLoadViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/20.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "BubbleDownLoadViewController.h"
#import "BubbleBdonLoadCell.h"
#import "ThemeManager.h"
@interface BubbleDownLoadViewController ()

@end

@implementation BubbleDownLoadViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"气泡设置";
    [self createTableView];
    [self loadData];

}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self themeColor];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count%2+self.dataArray.count/2;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BubbleBdonLoadCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[BubbleBdonLoadCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
        [cell.leftButton addTarget:self action:@selector(leftButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [cell.rightButton addTarget:self action:@selector(rightButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    
    [cell configUILeftModel:self.dataArray[indexPath.row*2] rightModel:indexPath.row*2+1==self.dataArray.count?nil:self.dataArray[indexPath.row*2+1]];
    
    cell.contentView.tag=indexPath.row;
    return cell;
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

-(void)loadData{
    [[HttpDownLoadBlock alloc]initWithUrlStr:@"http://imgcache.qq.com/club/item/avatar/json/data_4.6+_3.json?callback=jsonp2" setBlock:^(HttpDownLoadBlock *http, BOOL isFinish) {
       [self jsonValue:http.data];
    
    }];
}
-(void)jsonValue:(NSMutableData*)data{
    //转换为字符串
    NSString*jsonStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    //获取（的位置
    NSRange range=[jsonStr rangeOfString:@"("];
    //获取）的位置
    NSRange range1=[jsonStr rangeOfString:@")"];
    //进行截取
    jsonStr=[jsonStr substringWithRange:NSMakeRange(range.location+1, range1.location-range.location-1)];
    //解析
    NSDictionary*dic=[NSJSONSerialization JSONObjectWithData:[jsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
    
    self.dataArray=[[dic objectForKey:@"detailList"]allValues];
    
    [_tableView reloadData];
   
}
#pragma mark cell左边的按钮
-(void)leftButtonClick:(UIButton*)button{
//获得数据源
    UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"" message:@"气泡下载中请稍后" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    NSDictionary*dic=[self.dataArray objectAtIndex:button.superview.tag*2];
   BOOL isSucceed= [[ThemeManager shareManager]isBubbleDownLoadFinish:dic Block:^{
       [alert dismissWithClickedButtonIndex:0 animated:YES];

       [_tableView reloadData];
       
    }];
    if (isSucceed) {
        [_tableView reloadData];
    }else{
        [alert show];
    }
    [alert release];
}
#pragma mark cell右边的按钮
-(void)rightButtonClick:(UIButton*)button{
    UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"" message:@"气泡下载中请稍后" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    NSDictionary*dic=[self.dataArray objectAtIndex:button.superview.tag*2+1];
    BOOL isSucceed= [[ThemeManager shareManager]isBubbleDownLoadFinish:dic Block:^{
        [alert dismissWithClickedButtonIndex:0 animated:YES];
        
        [_tableView reloadData];
        
    }];
    if (isSucceed) {
        [_tableView reloadData];
    }else{
        [alert show];
    }
    [alert release];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
