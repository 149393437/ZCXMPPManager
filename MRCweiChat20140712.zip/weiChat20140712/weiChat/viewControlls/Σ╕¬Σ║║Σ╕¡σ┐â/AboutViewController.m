

//
//  AboutViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/20.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "AboutViewController.h"

@interface AboutViewController ()

@end

@implementation AboutViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"关于我们";
    [self createTextView];
    
    
}
-(void)createTextView{
    UIImageView*imageView=[[UIImageView alloc]initWithFrame:self.view.frame];
    imageView.image=[UIImage imageNamed:@"123.png"];
    self.view=imageView;
    UITextView*textView=[[UITextView alloc]initWithFrame:CGRectMake(10, 100, 300, 300)];
    
    
    textView.backgroundColor=[UIColor clearColor];
    textView.font=[UIFont fontWithName:@"Bradley Hand ITC TT" size:15];
    textView.text=@"微聊小圈是开发人员倾力打造，主要开发人员：\n主程序:     张诚\n微空间:     于腾潇\n服务端:     张健\n游戏中心:    金鹏\n\n鸣谢：表情大全开发者中心给予的支持\n我们将努力做到更好，你的使用就是对我们最大的支持";
    textView.textColor=[UIColor whiteColor];
    UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(50, 300, 220, 50) ImageName:nil Target:self Action:@selector(teleClick) Title:@"联系我们:13811928431"];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.view addSubview:textView];
    [textView release];
    [self.view addSubview:button];
}
-(void)teleClick{
    UIWebView*callWebView=[[UIWebView alloc]init];
    [callWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"tel:13811928431"]]];
    [self.view addSubview:callWebView];
    [callWebView release];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
