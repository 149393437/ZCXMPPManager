//
//  NewFriendViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/17.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface NewFriendViewController : RootViewController
@property(nonatomic,retain)NSMutableArray*dataArray;
@end
