
//
//  NewFriendViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/17.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "NewFriendViewController.h"

@interface NewFriendViewController ()

@end

@implementation NewFriendViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self loadData];
    
    // Do any additional setup after loading the view.
}
-(void)loadData{
    self.dataArray=[ZCXMPPManager sharedInstance].subscribeArray;
    [_tableView reloadData];

}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];
    [self themeColor];
}
-(void)themeConfig
{

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
        //同意按钮
        UIButton*agreeButton=[ZCControl createButtonWithFrame:CGRectMake(320-130, 0, 60, 40) ImageName:nil Target:self Action:@selector(agreeButtonClick:) Title:@"同意"];
        [agreeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [cell.contentView addSubview:agreeButton];
        //拒绝按钮
        UIButton*rejectButton=[ZCControl createButtonWithFrame:CGRectMake(320-60, 0, 60, 40) ImageName:nil Target:self Action:@selector(rejectButtonClick:) Title:@"拒绝"];
        [rejectButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [cell.contentView addSubview:rejectButton];
    }
    
    XMPPPresence *presence=self.dataArray[indexPath.row];
    //presence.from.user 获得jid
    cell.textLabel.text=presence.from.user;
    
    cell.contentView.tag=indexPath.row;
    return cell;
}
//同意
-(void)agreeButtonClick:(UIButton*)button{
    XMPPPresence*presence=self.dataArray[button.superview.tag];
    
    [[ZCXMPPManager sharedInstance]agreeRequest:presence.from.user];
    [self loadData];
}
//拒绝
-(void)rejectButtonClick:(UIButton*)button{
    XMPPPresence*presence=self.dataArray[button.superview.tag];
    
    [[ZCXMPPManager sharedInstance]reject:presence.from.user];
    [self loadData];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
