//
//  SettingViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "SettingViewController.h"
#import "ZCAppDelegate.h"
#import "LoginViewController.h"
//主题
#import "ThemeViewController.h"
//个人名片
#import "MyVcardViewController.h"
//关于我们
#import "AboutViewController.h"
//气泡下载
#import "BubbleDownLoadViewController.h"
//反馈
#import "UMFeedback.h"
//聊天背景
#import "ChatBackgroundViewController.h"
@interface SettingViewController ()

@end

@implementation SettingViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self loadData];
    [self createTableView];
    
    
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [self themeColor];
}
-(void)themeConfig
{

}
-(void)loadData{
    self.dataArray=@[@"个人资料",@"主题设置",@"气泡设置",@"聊天背景",@"关于我们",@"反馈"];
    
}
#pragma mark UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
    }
    

    NSArray*array=@[@"buddy_header_icon_circle_small.png",@"found_icons_readcenter.png",@"circle_schoolmate.png",@"file_icon_picture.png",@"buddy_header_icon_troopGroup_small.png",@"buddy_header_icon_discussGroup_small.png"];
    cell.imageView.image=[UIImage imageNamed:array[indexPath.row]];
    cell.textLabel.text=self.dataArray[indexPath.row];
  
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    switch (indexPath.row) {
        case 0:
        {
            MyVcardViewController*vc1=[[MyVcardViewController alloc]init];
            vc1.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc1 animated:YES];
            [vc1 release];
        }
            break;
       
         case 1:
        {
            ThemeViewController*vc=[[ThemeViewController alloc]init];
            //隐藏tabbar
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
            
            
        }
            break;
        case 2:
        {
            BubbleDownLoadViewController*vc=[[BubbleDownLoadViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
            case 3:
        {
            ChatBackgroundViewController*vc=[[ChatBackgroundViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 4:
        {
            AboutViewController*vc=[[AboutViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 5:
            //反馈
            [UMFeedback showFeedback:self withAppkey:@"53ad3a7156240b6a0d0371fb"];
            
            break;
        case 6:
            //退出登录
            [self outLogin];
            
            break;
        default:
            break;
    }
}
-(void)outLogin{
    
    //手动切断连接
    ZCXMPPManager*manager=[ZCXMPPManager sharedInstance];
    [manager disconnect];
    
    //切换window
    ZCAppDelegate*app=[UIApplication sharedApplication].delegate;
    
    //千万不要做以下这件事
    //ZCAppDelegate*app1=[[ZCAppDelegate alloc]init];
    
    LoginViewController*vc=[[LoginViewController alloc]init];
    
    [UIView animateWithDuration:0.5 animations:^{
        app.window.rootViewController=vc;
    }];
    
    //清空用户名  密码  第一次登录
    NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults  ];
    [defaults removeObjectForKey:kXMPPmyJID];
    [defaults removeObjectForKey:kXMPPmyPassword];
    [defaults removeObjectForKey:ISLOGIN];
    [defaults synchronize];
    
    


}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
//common_button_red_nor@2x.png
    UIImage*image=[UIImage imageNamed:@"common_button_red_nor@2x.png"];
    image=[image stretchableImageWithLeftCapWidth:10 topCapHeight:10];
    
    UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(10,5, 300, 44) ImageName:nil Target:self Action:@selector(outLogin) Title:@"退出当前账号"];
    [button setBackgroundImage:image forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIView*view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [view addSubview:button];
    return [view autorelease];
    
}
-(float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 60;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
