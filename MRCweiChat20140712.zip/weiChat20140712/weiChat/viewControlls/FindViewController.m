//
//  FindViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "FindViewController.h"
//二维码
#import "ZCZBarViewController.h"
//附近人
#import "PersonViewController.h"
//群组
#import "GroupFindViewController.h"
//微空间
#import "SmallZoneViewController.h"
//雷达
#import "RadarViewController.h"
//摇一摇
#import "YaoYiYaoViewController.h"
//二维码扫描结果跳转
#import "GroupAddViewController.h"
//游戏中心
#import "NetDualViewController.h"

@interface FindViewController ()

@end

@implementation FindViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadData];
    
    [self createTableView];
}
-(void)loadData{
    //扫一扫需要用到Zbar  摇一摇需要用到重力感应  附近人需要用到地理定位，附近群需要用到XMPP搜索聊天室  雷达需要用到iBeacon
    self.dataArray=@[@"微空间",@"扫一扫",@"摇一摇",@"附近人",@"附近群",@"雷达",@"游戏中心"];
    
    //建立一个数组，放置图片使用
    self.imageArray=@[@"icon_beiguanzhu_1.png",@"icon_code.png",@"icon_phone.png",@"icon_near.png",@"icon_friend_1.png",@"icon_tuijian_1.png",@"appIcon.png"];

}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];
    //父类方法，设置背景色透明
    [self themeColor];
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
        
    }
    cell.textLabel.text=self.dataArray[indexPath.row];
    cell.imageView.image=[UIImage imageNamed:self.imageArray[indexPath.row]];
    return cell;

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    switch (indexPath.row) {
        case 0:
            //微空间 ZoomViewController
        {
            SmallZoneViewController*vc=[[SmallZoneViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 1:
            //扫一扫 ZCZbarViewController
            [self ZbarClick];
            break;
        case 2:
            //摇一摇 MotionViewController
        {
            YaoYiYaoViewController*vc=[[YaoYiYaoViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 3:
            //附近人 PersonViewController
        {
            PersonViewController*vc=[[PersonViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 4:
            //附近群 GroupViewController
        {
            GroupFindViewController*vc=[[GroupFindViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 5:
            //雷达   RadarViewController
        {
            RadarViewController*vc=[[RadarViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            break;
        case 6:
        {
            NetDualViewController*vc=[[NetDualViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];
        }
            
            break;
       
        default:
            break;
    }

}
#pragma mark 二维码扫描
-(void)ZbarClick{
    
ZCZBarViewController*vc=[[ZCZBarViewController alloc]initWithBlock:^(NSString *result, BOOL isFinish) {
    //请求回来的结果
    if (isFinish) {
        //扫描回来有结果 添加好友
        //制定格式[0]好友 [1]无密码群组  [2]有密码群组
        if ([result hasPrefix:@"[0]"]) {
            [[ZCXMPPManager sharedInstance]addSomeBody:[result substringFromIndex:3] Newmessage:nil];
        }else{
            if ([result hasPrefix:@"[1]"]){
                //无密码群组
                GroupAddViewController*vc=[[GroupAddViewController alloc]init];
                vc.resultStr=[result substringFromIndex:3];
                [self.navigationController pushViewController:vc animated:YES];
                [vc release];
                
            }else{
                if ([result hasPrefix:@"[2]"]) {
                    //有密码
                }
            }
        
        }
    }
    
}];
    [self presentViewController:vc animated:YES completion:nil];
    [vc release];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
