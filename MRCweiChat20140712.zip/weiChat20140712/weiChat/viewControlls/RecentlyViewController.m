//
//  RecentlyViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RecentlyViewController.h"
#import "ZCMessageObject.h"
#import "ChatViewController.h"
#import "GroupCheckViewController.h"
#import "GroupChatViewController.h"
#import "RecentlyCell.h"
@interface RecentlyViewController ()
{

    UIButton*groupButton;
}
@end

@implementation RecentlyViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [self loadData];

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults    ];
    //判断是不是第二次登录,如果是第二次登录，先执行登录操作
    if ([[defaults objectForKey:ISLOGIN]isEqualToString:ISLOGIN]) {
        alert=[[UIAlertView alloc]initWithTitle:@"" message:@"连接服务中，请耐心等待" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
        [alert show];
        ZCXMPPManager*manager=[ZCXMPPManager sharedInstance];
        [manager connectLogoin:^(BOOL isFinish) {
            if (isFinish) {
                NSLog(@"登录成功");
                [alert dismissWithClickedButtonIndex:0 animated:YES];
                manager.badgeValue=self.tabBarItem;
            }
        }];
        
    }
    
      [self createTableView];
     [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loadData) name:kXMPPNewMsgNotifaction object:nil];
    [self loadPlist];
}
-(void)loadPlist{
    //读取群验证消息
    NSString*path1=[NSString stringWithFormat:@"%@/Documents/groupCheckPlist.plist",NSHomeDirectory()];
    self.groupCheckPlist=[NSMutableArray arrayWithContentsOfFile:path1];
    if (self.groupCheckPlist==nil) {
        self.groupCheckPlist=[NSMutableArray arrayWithCapacity:0];
    }
    
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];
    
     //群验证消息
    //设计需求 当收到验证消息时候，保存到数组内，更新plist文件
    [ZCXMPPManager sharedInstance].GroupCheck=^(NSDictionary*dic){       
        BOOL isSucceed=NO;
        for (NSDictionary*dic1 in self.groupCheckPlist) {
             isSucceed=[dic1 isEqualToDictionary:dic];
            
        }
        if (!isSucceed) {
             [self.groupCheckPlist addObject:dic];
            //更新本地文件
            NSString*path1=[NSString stringWithFormat:@"%@/Documents/groupCheckPlist.plist",NSHomeDirectory()];
            //数据重新写入
            [self.groupCheckPlist writeToFile:path1 atomically:YES];
            [groupButton setTitle:[NSString stringWithFormat:@"您有%d条群验证消息",self.groupCheckPlist.count] forState:UIControlStateNormal];
        }
       

    };
    
    groupButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 320, 44) ImageName:nil Target:self Action:@selector(groupCheckClick) Title:nil];
    [groupButton setImage:[UIImage imageNamed:@"icon_guanzhu_1.png"] forState:UIControlStateNormal];
    [groupButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _tableView.tableHeaderView=groupButton;
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    NSString*title=nil;
    if (self.groupCheckPlist.count) {
        title=[NSString stringWithFormat:@"您有%d条群验证消息",self.groupCheckPlist.count];
    }else{
        title=@"您目前没有群验证消息";
    }
    [groupButton setTitle:title forState:UIControlStateNormal];
    
    
    //父类的方法
    [self themeColor];
}
#pragma mark 进入群验证消息
-(void)groupCheckClick{
    GroupCheckViewController*vc=[[GroupCheckViewController alloc]init];
    vc.dataArray=self.groupCheckPlist;
    vc.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
}
#pragma mark 该方法是父类的方法，收到主题切换通知后要做的事情
-(void)themeConfig
{

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RecentlyCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[RecentlyCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"]autorelease];
    }
    
    NSArray*array=self.dataArray[indexPath.row];
    [cell configUI:array];
    
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString*str=[self.dataArray[indexPath.row]lastObject];
    
    if ([str isEqualToString:SOLECHAT]) {
        ChatViewController*vc=[[ChatViewController alloc]init];
        vc.friendJid=self.dataArray[indexPath.row][2];
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];

    }else{
        GroupChatViewController*vc=[[GroupChatViewController alloc]init];
        vc.roomJid=self.dataArray[indexPath.row][2];
        
        NSString*str=[self.dataArray[indexPath.row] lastObject];
        //切掉前三位
        str=[str substringFromIndex:3];
        vc.title=str;
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
    
    }
    
    
   }
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(void)loadData{
    //读取数据
    self.dataArray=  [ZCMessageObject fetchRecentChatByPage:20];
    
    [_tableView reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
