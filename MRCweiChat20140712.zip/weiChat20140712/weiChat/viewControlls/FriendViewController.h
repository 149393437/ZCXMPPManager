//
//  FriendViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface FriendViewController : RootViewController<UIAlertViewDelegate>
{
    int isOpen[4];
    //验证消息点击按钮
    UIButton*proving;
    
    //全局的导航右按钮
    UIButton*rightNavButton;
    
    
}
//存储好友列表 每个元素是数组
@property(nonatomic,retain)NSMutableArray*dataArray;

@end
