//
//  MainTabBarController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/11.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "MainTabBarController.h"

//最近联系人
#import "RecentlyViewController.h"
//联系人
#import "FriendViewController.h"
//动态
#import "FindViewController.h"
//设置
#import "SettingViewController.h"


@interface MainTabBarController ()

@end

@implementation MainTabBarController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc
{
    [super dealloc];
    //移除通知中心
    [[NSNotificationCenter defaultCenter]removeObserver:self name:THEME object:nil];

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //创建viewController
    [self createViewController];
    //设置tabBar 在收到通知中心需要重新调用
    [self createTabBar];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(createTabBar) name:THEME object:nil];
    
}

#pragma mark 创建ViewControllers
-(void)createViewController{
    RecentlyViewController*vc=[[RecentlyViewController alloc]init];
    vc.title=@"最近联系人";
    UINavigationController*nc=[[UINavigationController alloc]initWithRootViewController:vc];
    FriendViewController*vc1=[[FriendViewController alloc    ]init];
    vc1.title=@"联系人";
    UINavigationController*nc1=[[UINavigationController alloc]initWithRootViewController:vc1];
    FindViewController*vc2=[[FindViewController alloc]init];
    vc2.title=@"动态";
    UINavigationController*nc2=[[UINavigationController alloc]initWithRootViewController:vc2];
    SettingViewController*vc3=[[SettingViewController alloc]init];
    vc3.title=@"我的";
    UINavigationController*nc3=[[UINavigationController alloc]initWithRootViewController:vc3];
    
    NSArray*vcArray=@[nc,nc1,nc2,nc3];
    self.viewControllers=vcArray;
    [vc release];
    [vc1 release];
    [vc2 release];
    [vc3 release];
    [nc release];
    [nc1 release];
    [nc2 release];
    [nc3 release];

}
#pragma mark 设置tabBar
-(void)createTabBar{
    //存储未点选
    NSArray*unSelectArray=@[@"tab_recent_nor@2x.png",@"tab_buddy_nor@2x.png",@"tab_qworld_nor@2x.png",@"tab_me_nor@2x.png"];
    //存储点选
    NSArray*SelectArray=@[@"tab_recent_press@2x.png",@"tab_buddy_press@2x.png",@"tab_qworld_press@2x.png",@"tab_me_press@2x.png"];
    //存储title
    NSArray*titleArray=@[@"最近联系人",@"联系人",@"动态",@"我的"];
    NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
    //获得主题的文件夹名字
    NSString*theme=[defaults objectForKey:THEME];
    //记录文件的沙盒路径
    theme=[NSString stringWithFormat:@"%@/Documents/%@/",NSHomeDirectory(),theme];
    
    NSLog(@"%@",theme);
    for (int i=0; i<self.tabBar.items.count; i++) {
        UITabBarItem*item=self.tabBar.items[i];
        if (0) {
            UIImage*unSelectImage=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@%@",theme,unSelectArray[i]]];
            //处理图像 使用原始图像数据
            unSelectImage=[unSelectImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            
            
            UIImage*selectImage=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@%@",theme,SelectArray[i]]];
            selectImage=[selectImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            
            
            [item initWithTitle:titleArray[i] image:unSelectImage selectedImage:selectImage];
        }else{
        
            [item setFinishedSelectedImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@%@",theme,SelectArray[i]]] withFinishedUnselectedImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@%@",theme,unSelectArray[i]]]];
            item.title=titleArray[i];
        }
        
    }
    
//修改TabBar背景色
    [[UITabBar appearance] setBackgroundImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@tabbar_bg@2x.png",theme]]];
//消除阴影线
    if ([[[UIDevice currentDevice]systemVersion]floatValue]>=6.0) {
        //设置一张空的图
        [[UITabBar appearance]setShadowImage:[[UIImage alloc]init]];
       
    }
    
//修改选中的颜色为白色
  
    if (IOS7) {
          [[UITabBarItem appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateSelected];
    }else{
      [[UITabBarItem appearance]setTitleTextAttributes:@{UITextAttributeTextColor:[UIColor whiteColor]} forState:UIControlStateSelected];
    }
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
