//
//  MyVcardViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface MyVcardViewController : RootViewController<UIAlertViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
   
    //判断用户是否更新了名片
    BOOL isUpData;

}
//每个数据里面存储的是字典
@property(nonatomic,retain)NSMutableArray*dataArray;
@property(nonatomic,retain)XMPPvCardTemp*myVcard;
-(void)loadMyVcardData;
@end
