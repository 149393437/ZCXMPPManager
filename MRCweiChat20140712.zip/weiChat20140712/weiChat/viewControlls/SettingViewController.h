//
//  SettingViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface SettingViewController : RootViewController
{
   
}
@property(nonatomic,retain)NSArray*dataArray;
@end
