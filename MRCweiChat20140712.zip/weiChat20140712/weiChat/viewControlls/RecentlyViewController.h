//
//  RecentlyViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface RecentlyViewController : RootViewController
{
    UIAlertView*alert;

}
@property(nonatomic,retain)NSMutableArray*dataArray;
//群消息验证的持久化保存
@property(nonatomic,retain)NSMutableArray*groupCheckPlist;
@end
