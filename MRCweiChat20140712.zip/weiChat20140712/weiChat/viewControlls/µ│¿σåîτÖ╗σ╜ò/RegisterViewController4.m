//
//  RegisterViewController4.m
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RegisterViewController4.h"
#import "MainTabBarController.h"
@interface RegisterViewController4 ()

@end

@implementation RegisterViewController4

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    manager=[RegisterManager shareManage];
    [self createBgView];
    [self createTextField];
    
    // Do any additional setup after loading the view.
}
-(void)createBgView{
    UIImageView*bgImageView=[ZCControl createImageViewWithFrame:self.view.frame ImageName:@"logo_bg_2.png"];
    self.view=bgImageView;
    
    self.navigationController.navigationBar.translucent=NO;
    UIButton*finish=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 44) ImageName:nil Target:self Action:@selector(finishNavButton) Title:@"完成"];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc]initWithCustomView:finish]autorelease];
    self.title=@"完善资料（4/4）";
    
}
-(void)finishNavButton{
    [address resignFirstResponder];
    if (qmdTextField.text.length>0&&address.text.length>0) {
        
        
        manager.qmd=qmdTextField.text;
        manager.address=address.text;
        [self login];
    }

}
-(void)createTextField{
    UIImageView*leftImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon_edit.png"]];
    leftImageView.frame=CGRectMake(20, 12, 20, 20);
    UIImageView*view=[[UIImageView  alloc]initWithFrame:CGRectMake(0, 0, 64, 44)];
    [view addSubview:leftImageView];
    [leftImageView release];
    
    qmdTextField=[ZCControl createTextFieldWithFrame:CGRectMake(0,60, 320, 44) placeholder:@"起一个狂拽炫酷掉渣天的签名" passWord:NO leftImageView:view rightImageView:nil Font:12 backgRoundImageName:nil];
    qmdTextField.delegate=self;
    qmdTextField.returnKeyType=UIReturnKeyNext;
    [self.view addSubview:qmdTextField];
    qmdTextField.backgroundColor=[UIColor whiteColor];
    [qmdTextField becomeFirstResponder];
    
    
    
    UIImageView*leftImageView1=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"feed_loc_new.png"]];
    leftImageView1.frame=CGRectMake(20, 12, 20, 20);
    UIImageView*view1=[[UIImageView  alloc]initWithFrame:CGRectMake(0, 0, 64, 44)];
    [view1 addSubview:leftImageView1];
    [leftImageView1 release];
    
    address=[ZCControl createTextFieldWithFrame:CGRectMake(0,105, 320, 44) placeholder:@"地址" passWord:NO leftImageView:view1 rightImageView:nil Font:12 backgRoundImageName:nil];
    address.delegate=self;
    address.returnKeyType=UIReturnKeyDone;
    address.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:address];
    
    
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==qmdTextField) {
        [address becomeFirstResponder];
    }else{
        [address resignFirstResponder];
        if (qmdTextField.text.length>0&&address.text.length>0) {
            
         
            manager.qmd=qmdTextField.text;
            manager.address=address.text;
            [self login];
        }
    
    }
    return YES;
}
-(void)login{
//注册，登录，设置vcard 进入主界面
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    [user setObject:manager.userName forKey:kXMPPmyJID];
    [user setObject:manager.passWord forKey:kXMPPmyPassword];
    [user synchronize];
    xmppManager=[ZCXMPPManager sharedInstance];

    [xmppManager registerMothod:^(BOOL isFinish) {
        if (isFinish) {
            //注册成功后，进入主页面
            [self login1];
        }
    }];
    
    
    
    
    
}
-(void)login1{
    //执行登录
    [xmppManager connectLogoin:^(BOOL isFinish) {
        if (isFinish) {
            //登录成功后获取vcard，更新vcard信息
       [xmppManager getMyVcardBlock:^(BOOL isFinish, XMPPvCardTemp *myVcard) {
           NSLog(@"%d",isFinish);
           
           
            myVcard.photo=UIImageJPEGRepresentation(manager.headerImage, 0.001);
            myVcard.nickname=manager.nickName;
            [xmppManager customVcardXML:manager.birthday name:BYD myVcard:myVcard];
            [xmppManager customVcardXML:manager.sex name:SEX myVcard:myVcard];
            [xmppManager customVcardXML:manager.phoneNum name:PHOTONUM myVcard:myVcard];
            [xmppManager customVcardXML:manager.qmd name:QMD myVcard:myVcard];
            [xmppManager customVcardXML:manager.address name:ADDRESS myVcard:myVcard];
            [xmppManager upData:myVcard];
           xmppManager.myVcardBlock=nil;

           
           
        }];
            
            
            //本地进行记录第一次登录成功
            MainTabBarController *main=[[MainTabBarController alloc]init];
            [self presentViewController:main animated:YES completion:^{
                //主要解决第一次登录的问题，在MainTabBar执行完ViewDidLoad时候，会在执行这里
                NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
                [defaults setValue:ISLOGIN forKey:ISLOGIN];
                [defaults synchronize];
            }];
            [main release];
            
            
            
            
        }else{
            //失败
            UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"账户或者密码错误，请重试" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            [al show];
            [al release];
        }
    }];


}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
