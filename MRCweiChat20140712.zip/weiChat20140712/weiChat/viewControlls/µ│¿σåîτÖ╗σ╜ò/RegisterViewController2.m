//
//  RegisterViewController2.m
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RegisterViewController2.h"
#import "RegisterViewController3.h"
#import <QuartzCore/QuartzCore.h>
@interface RegisterViewController2 ()

@end

@implementation RegisterViewController2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createBgView];
    [self createPhotoView];
    [self createSexOrBirthday];
    
    // Do any additional setup after loading the view.
}
-(void)createBgView{
    UIImageView*bgImageView=[ZCControl createImageViewWithFrame:self.view.frame ImageName:@"logo_bg_2.png"];
    self.view=bgImageView;
    
    self.navigationController.navigationBar.translucent=NO;
    UIButton*nextButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 44) ImageName:nil Target:self Action:@selector(rightNavButton) Title:@"下一步"];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc]initWithCustomView:nextButton]autorelease];
    self.title=@"个人资料（2/4）";
    
}
-(void)createPhotoView{
    //开启相机
    UIImageView*bgPhotoView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 100, 100) ImageName:@"icon_register_camerabg.png"];
    bgPhotoView.center=CGPointMake(320/2, 60);
    [self.view addSubview:bgPhotoView];
    headerButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 100, 100) ImageName:@"icon_register_camera@2x.png" Target:self Action:@selector(photoClick) Title:nil];
    headerButton.layer.cornerRadius=8;
    headerButton.layer.masksToBounds=YES;
    [bgPhotoView addSubview:headerButton];
}
-(void)createSexOrBirthday{
    UIView*birthdayView=[[UIView alloc]initWithFrame:CGRectMake(0, 130, 320, 44)];
    birthdayView.backgroundColor=[UIColor whiteColor];
    UIImageView*birthdayImageView=[ZCControl createImageViewWithFrame:CGRectMake(15, 12, 20, 20) ImageName:@"icon_register_birthday.png"];
    [birthdayView addSubview:birthdayImageView];
    birthdayLabel=[ZCControl createLabelWithFrame:CGRectMake(60, 10, 270, 25) Font:12 Text:@"请选择的你生日"];
    birthdayLabel.textColor=[UIColor grayColor];
    [birthdayView addSubview:birthdayLabel];
    UIControl*birthdayControl=[[UIControl alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [birthdayControl addTarget:self action:@selector(birthdayClick) forControlEvents:UIControlEventTouchUpInside];
    [birthdayView addSubview:birthdayControl];
    
    
    UIImageView*temp=[ZCControl createImageViewWithFrame:CGRectMake(320-50, 10, 25, 25) ImageName:@"btn_forward_disabled.png"];
    [birthdayView addSubview:temp];
    [self.view addSubview:birthdayView];
    
    
    
    UIView*sexView=[[UIView alloc]initWithFrame:CGRectMake(0, 175, 320, 44)];
    sexView.backgroundColor=[UIColor whiteColor];
    sexImageView=[ZCControl createImageViewWithFrame:CGRectMake(15, 12, 20, 20) ImageName:@"icon_register_gender.png"];
    [sexView addSubview:sexImageView];
    sexLabel=[ZCControl createLabelWithFrame:CGRectMake(60, 10, 270, 25) Font:12 Text:@"请选择性别"];
    sexLabel.textColor=[UIColor grayColor];
    [sexView addSubview:sexLabel];
    
    UIImageView*temp1=[ZCControl createImageViewWithFrame:CGRectMake(320-50, 10, 25, 25) ImageName:@"btn_forward_disabled.png"];
    [sexView addSubview:temp1];
    [self.view addSubview:sexView];
    
    UIControl*sexControl=[[UIControl alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [sexControl addTarget:self action:@selector(sexClick) forControlEvents:UIControlEventTouchUpInside];
    [sexView addSubview:sexControl];
    
    UILabel*zhu=[ZCControl createLabelWithFrame:CGRectMake(20, 220, 250, 20) Font:10 Text:@"性别选择后,不允许修改，请谨慎操作"];
    zhu.textColor=[UIColor grayColor];
    [self.view addSubview:zhu];

}
-(void)rightNavButton{
    RegisterManager*manager=[RegisterManager shareManage];
    if (isBirthday==YES&&isSex==YES) {
        
        if (manager.headerImage==nil) {
            manager.headerImage=[UIImage imageNamed:@"logo_2.png"];
        }
        manager.birthday=birthdayLabel.text;
        manager.sex=sexLabel.text;
        RegisterViewController3*vc=[[RegisterViewController3 alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
    }else{
        UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"资料请填写完全" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [al show];
        [al release];
    }
    
    
   
}

-(void)photoClick{
    UIActionSheet*sheet=[[UIActionSheet alloc]initWithTitle:@"添加图片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相册",@"拍照", nil];
    sheet.tag=100;
    [sheet showInView:self.view];
    [sheet release];
}
-(void)sexClick{
    if (datePicker) {
        [UIView animateWithDuration:1 animations:^{
            datePicker.frame=CGRectMake(0, self.view.frame.size.height, 0, 0);
        }completion:^(BOOL finished) {
            [datePicker removeFromSuperview];
        }];
    }
    UIActionSheet*sheet=[[UIActionSheet alloc]initWithTitle:@"选择性别" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"男",@"女", nil];
    [sheet showInView:self.view];
    [sheet release];

}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"%d",buttonIndex);
    //0相册 1相机   //0 男  1 女

    if (actionSheet.tag==100) {
        if (buttonIndex!=2) {
            UIImagePickerController*picker=[[UIImagePickerController alloc]init];
            if (buttonIndex) {
                if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                }
                
            }
            //允许用户进行编辑
            picker.allowsEditing = YES;
            //设置委托对象
            picker.delegate = self;
            //以模视图控制器的形式显示
            [self presentViewController:picker animated:YES completion:nil];
            [picker release];
        }
       
    }else{
        isSex=YES;
        
        if (buttonIndex) {
            //女
            sexImageView.image=[UIImage imageNamed:@"icon_register_woman.png"];
            sexLabel.text=@"女";
        }else{
            sexImageView.image=[UIImage imageNamed:@"icon_register_man.png"];
            sexLabel.text=@"男";
        }
    
    
    }
   
    

}
#pragma 设置头像
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //UIImagePickerControllerOriginalImage
    NSLog(@"%@",info);
UIImage* editedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    [headerButton setImage:editedImage forState:UIControlStateNormal];
    headerButton.frame=CGRectMake(10, 10, 80, 80);
    
    RegisterManager*xx=[RegisterManager shareManage];
    xx.headerImage=editedImage;
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

#pragma make设置生日
-(void)birthdayClick{
    if (datePicker==nil) {
        
  
    datePicker=[[UIDatePicker alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-216, 0, 0)];
    [datePicker setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    //日期模式
    [datePicker setDatePickerMode:UIDatePickerModeDate];
    //定义最小日期
    NSDateFormatter *formatter_minDate = [[NSDateFormatter alloc] init];
    [formatter_minDate setDateFormat:@"yyyy-MM-dd"];
    NSDate *minDate = [formatter_minDate dateFromString:@"1900-01-01"];
    [formatter_minDate release];
    NSDate *maxDate = [NSDate date];
    
    [datePicker setMinimumDate:minDate];
    [datePicker setMaximumDate:maxDate];
    [datePicker addTarget:self action:@selector(dataValueChanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:datePicker];
    
    [UIView animateWithDuration:1 animations:^{
         datePicker.frame=CGRectMake(0, self.view.frame.size.height-216, 0, 0);
    }];
          }
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{

    if (datePicker) {
        [UIView animateWithDuration:1 animations:^{
            datePicker.frame=CGRectMake(0, self.view.frame.size.height, 0, 0);
        }completion:^(BOOL finished) {
            [datePicker removeFromSuperview];
        }];
    }
}
- (void) dataValueChanged:(UIDatePicker *)sender
{
    isBirthday=YES;
    UIDatePicker *dataPicker_one = (UIDatePicker *)sender;
    NSDate *date_one = dataPicker_one.date;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    birthdayLabel.text = [formatter stringFromDate:date_one];
    [formatter release];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
