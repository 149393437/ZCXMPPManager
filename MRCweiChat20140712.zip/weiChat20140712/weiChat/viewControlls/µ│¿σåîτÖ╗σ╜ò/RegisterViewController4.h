//
//  RegisterViewController4.h
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController4 : UIViewController<UITextFieldDelegate>
{
    UITextField*qmdTextField;
    UITextField*address;
    RegisterManager*manager;
    ZCXMPPManager*xmppManager;
}
@end
