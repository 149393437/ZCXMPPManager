//
//  RegisterViewController3.h
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController3 : UIViewController<UITextFieldDelegate>
{
    UITextField*phoneTextField;
    UITextField*passWord;
}
@end
