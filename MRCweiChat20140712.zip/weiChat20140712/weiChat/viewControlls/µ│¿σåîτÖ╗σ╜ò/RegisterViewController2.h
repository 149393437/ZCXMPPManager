//
//  RegisterViewController2.h
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController2 : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>
{
    //设置头像
    UIButton*headerButton;
    //设置生日
    UILabel*birthdayLabel;
    //设置性别
    UILabel*sexLabel;
    //设置性别的图片
    UIImageView*sexImageView;
    //设置生日的选择器
    UIDatePicker*datePicker;
    BOOL isBirthday;
    BOOL isSex;
    
}
@end
