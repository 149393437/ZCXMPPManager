//
//  RegisterViewController1.h
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController1 : UIViewController<UITextFieldDelegate>
{
    //账号
    UILabel*useName;
    //昵称
    UITextField*nikeName;
}
@end
