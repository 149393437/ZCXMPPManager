//
//  RegisterViewController3.m
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RegisterViewController3.h"
#import "RegisterViewController4.h"
@interface RegisterViewController3 ()

@end

@implementation RegisterViewController3

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createBgView];
    [self createTextField];
    // Do any additional setup after loading the view.
}
-(void)createBgView{
    UIImageView*bgImageView=[ZCControl createImageViewWithFrame:self.view.frame ImageName:@"logo_bg_2.png"];
    self.view=bgImageView;
    
    self.navigationController.navigationBar.translucent=NO;
    UIButton*nextButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 44) ImageName:nil Target:self Action:@selector(rightNavButton) Title:@"下一步"];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc]initWithCustomView:nextButton]autorelease];
    self.title=@"登录信息（3/4）";
    
    
}
-(void)createTextField{
    UIImageView*leftImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon_register_mobile.png"]];
    leftImageView.frame=CGRectMake(20, 12, 20, 20);
    UIImageView*view=[[UIImageView  alloc]initWithFrame:CGRectMake(0, 0, 64, 44)];
    [view addSubview:leftImageView];
    [leftImageView release];
    
    phoneTextField=[ZCControl createTextFieldWithFrame:CGRectMake(0,60, 320, 44) placeholder:@"请输入您的手机号" passWord:NO leftImageView:view rightImageView:nil Font:12 backgRoundImageName:nil];
    phoneTextField.delegate=self;
    phoneTextField.returnKeyType=UIReturnKeyNext;
    [self.view addSubview:phoneTextField];
    phoneTextField.backgroundColor=[UIColor whiteColor];
    [phoneTextField becomeFirstResponder];
    
    
    
    UIImageView*leftImageView1=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon_register_mobile.png"]];
    leftImageView1.frame=CGRectMake(20, 12, 20, 20);
    UIImageView*view1=[[UIImageView  alloc]initWithFrame:CGRectMake(0, 0, 64, 44)];
    [view1 addSubview:leftImageView1];
    [leftImageView1 release];
    
    passWord=[ZCControl createTextFieldWithFrame:CGRectMake(0,105, 320, 44) placeholder:@"请输入登录密码" passWord:YES leftImageView:view1 rightImageView:nil Font:12 backgRoundImageName:nil];
    passWord.delegate=self;
    passWord.returnKeyType=UIReturnKeyNext;
      passWord.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:passWord];
  
   

}

-(void)rightNavButton{
    
    if (phoneTextField.text.length==11&&passWord.text>0) {
        RegisterManager*manager=[RegisterManager shareManage];
        manager.phoneNum=phoneTextField.text;
        manager.passWord=passWord.text;
        
    }
    RegisterViewController4*vc=[[RegisterViewController4 alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
