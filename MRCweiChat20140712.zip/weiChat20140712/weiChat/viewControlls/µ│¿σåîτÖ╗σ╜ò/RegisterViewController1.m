//
//  RegisterViewController1.m
//  weiChat
//
//  Created by ZhangCheng on 14/7/1.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RegisterViewController1.h"
#import "RegisterViewController2.h"
@interface RegisterViewController1 ()

@end

@implementation RegisterViewController1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //logo_bg_2.png
    [self createBgView];
    [self createTextField];

}
-(void)createBgView{
    UIImageView*bgImageView=[ZCControl createImageViewWithFrame:self.view.frame ImageName:@"logo_bg_2.png"];
    self.view=bgImageView;
    
    self.navigationController.navigationBar.translucent=NO;
    UIButton*nextButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 44) ImageName:nil Target:self Action:@selector(rightNavButton) Title:@"下一步"];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc]initWithCustomView:nextButton]autorelease];
    self.title=@"请输入昵称（1/4）";
    
    UIButton*back=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 44) ImageName:@"header_leftbtn_black_nor.png" Target:self Action:@selector(back) Title:@"返回"];
    self.navigationItem.leftBarButtonItem=[[[UIBarButtonItem alloc]initWithCustomView:back]autorelease];
    
    
}
-(void)back{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)createTextField{
    UIImageView*leftImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon_register_name.png"]];
    leftImageView.frame=CGRectMake(20, 12, 20, 20);
    UIImageView*view=[[UIImageView  alloc]initWithFrame:CGRectMake(0, 0, 64, 44)];
    [view addSubview:leftImageView];
    [leftImageView release];
    
    nikeName=[ZCControl createTextFieldWithFrame:CGRectMake(0,60, 320, 44) placeholder:@"请输入昵称" passWord:NO leftImageView:view rightImageView:nil Font:12 backgRoundImageName:nil];
    nikeName.delegate=self;
    nikeName.returnKeyType=UIReturnKeyNext;
    [self.view addSubview:nikeName];
    nikeName.backgroundColor=[UIColor whiteColor];
    [nikeName becomeFirstResponder];
    
    
    //创建账号
    useName=[ZCControl createLabelWithFrame:CGRectMake(50, 20, 200, 20) Font:15 Text:[NSString stringWithFormat:@"您的数字账号为:%ld",DTAETIME]];
    [self.view addSubview:useName];
    UILabel*shuoming=[ZCControl createLabelWithFrame:CGRectMake(50, 40, 200, 20) Font:5 Text:@"苍老师为您创建了数字账号,不满意请点击重试来进行创建一个新的数字账号"];
    shuoming.textColor=[UIColor grayColor];
    [self.view addSubview:shuoming];
    
    UIButton*timeButton=[ZCControl createButtonWithFrame:CGRectMake(250, 20, 60, 44) ImageName:nil Target:self Action:@selector(timeButtonClick) Title:@"重试"];
    [self.view addSubview:timeButton];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self rightNavButton];
    return YES;
}

-(void)timeButtonClick{
    

    useName.text=[NSString stringWithFormat:@"您的数字账号为:%ld",DTAETIME];
}
-(void)rightNavButton{
    if (nikeName.text.length>0) {
        RegisterManager*manager=[RegisterManager shareManage];
        manager.nickName=nikeName.text;
        manager.userName=[useName.text substringFromIndex:8];
        RegisterViewController2*vc=[[RegisterViewController2 alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
    }
    
    
   

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
