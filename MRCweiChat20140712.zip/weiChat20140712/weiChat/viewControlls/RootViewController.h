//
//  RootViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/11.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView*_tableView;
}
-(void)themeColor;
-(void)themeConfig;
@property(nonatomic,copy)NSString*path;
@end
