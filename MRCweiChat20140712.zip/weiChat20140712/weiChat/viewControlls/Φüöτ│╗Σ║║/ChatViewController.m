
//
//  ChatViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "ChatViewController.h"
#import "FaceToolBar.h"
#import "MessageCell.h"
#import "Photo.h"
#import "XMPPvCardTemp.h"
#import "FirendDetailViewController.h"
//观察者的key
#define  FACEHIGHTSIGN  @"frame"
@interface ChatViewController ()
{
    FaceToolBar*toolBar;

}
@end

@implementation ChatViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc{
    [toolBar removeObserver:self forKeyPath:FACEHIGHTSIGN];
    [super dealloc];

}
-(void)viewWillDisappear:(BOOL)animated
{
    //当出去时候，设置当前没有人聊天
    [ZCXMPPManager sharedInstance].chatPerson=@"none";
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createBgView];
    [self createRightNav];
    [self createFaceToolBar];
    [self createTablebView];
    
    
    //聊天信息需要先进行设置和谁聊天
    _manager=[ZCXMPPManager sharedInstance];
    [_manager valuationChatPersonName:[NSString stringWithFormat:@"%@@%@",self.friendJid,DOMAIN]IsPush:YES MessageBlock:^(ZCMessageObject *message) {
      //接收到新消息
        [self loadData];
    }];
    [self loadData];
    
  XMPPvCardTemp*friend=  [[ZCXMPPManager sharedInstance]friendsVcard:self.friendJid];
    if (friend.photo) {
        self.friendHeaderImage=[UIImage imageWithData:friend.photo];
    }else{
        self.friendHeaderImage=[UIImage imageNamed:@"logo_2@2x.png"];
        }
    if (friend.nickname) {
        self.title=friend.nickname;
    }else{
        self.title=self.friendJid;
    }
   [[ZCXMPPManager sharedInstance]getMyVcardBlock:^(BOOL isFinish, XMPPvCardTemp *vcard) {
       dispatch_async(dispatch_get_main_queue(), ^{
           if (vcard.photo) {
               self.myHeaderImage=[UIImage imageWithData:vcard.photo];
               
           }else{
               self.myHeaderImage=[UIImage imageNamed:@"logo_2@2x.png"];
               
           }
         
           
           [_tableView reloadData];
        
       });

    }];
    
    
    if (self.myHeaderImage==nil) {
        
        self.myHeaderImage=[UIImage imageNamed:@"logo_2@2x.png"];
    }
    
}
-(void)createRightNav{

    //menu_icon_groupprofile_press@2x.png
    
    UIButton*button=[UIButton buttonWithType:UIButtonTypeCustom];
    button.frame=CGRectMake(0, 0, 44, 44);
    [button setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@tab_buddy_nor.png",self.path]] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(rightNavClick) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithCustomView:button];
    self.navigationItem.rightBarButtonItem=item;
    [item release];

}
-(void)rightNavClick{
//详情
    FirendDetailViewController*vc=[[FirendDetailViewController alloc]init];
    vc.hidesBottomBarWhenPushed=YES;
    vc.usedID=self.friendJid;
    vc.myVcard=[[ZCXMPPManager sharedInstance]friendsVcard:self.friendJid];
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
 
    
    
}

-(void)createBgView{
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    NSString*str=[user objectForKey:@"chatBackGround"];
    if (str) {
        
        if ([str integerValue]!=12) {
            UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_%d.jpg",NSHomeDirectory(),100+[str intValue]]];
            UIImageView*imageview=[[UIImageView alloc]initWithImage:image];
            imageview.frame=self.view.frame;
            imageview.userInteractionEnabled=YES;
            self.view=imageview;
        }else{
            UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_%d.jpg",NSHomeDirectory(),[str intValue]]];
            UIImageView*imageview=[[UIImageView alloc]initWithImage:image];
            imageview.userInteractionEnabled=YES;
            imageview.frame=self.view.frame;
            self.view=imageview;
        }
        
    }else{
   
        UIImageView*imageview=[[UIImageView alloc]initWithImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bg_default.jpg",self.path ]]];
        imageview.frame=self.view.frame;
        imageview.userInteractionEnabled=YES;
        self.view=imageview;
    }
}


-(void)loadData{
    //读取聊天记录和持续聊天
    NSArray*array= [_manager messageRecord];
    self.dataArray=[NSMutableArray arrayWithArray:array];
    [_tableView reloadData];
    //判断数据不为0的时候
    if (self.dataArray.count) {
         [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
   
}
-(void)createTablebView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-44) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [_tableView release];
   
    [self themeColor];
    

    
}
-(void)createFaceToolBar{
   toolBar=[[FaceToolBar alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-44, 320, 44) voice:nil ViewController:self Block:^(NSString *sign, NSString *value) {
      //sign 标示[1]  value 输出的结果
       
       [[ZCXMPPManager sharedInstance]sendMessageWithJID:[NSString stringWithFormat:@"%@@%@",self.friendJid,DOMAIN] Message:value Type:sign];
       [self performSelector:@selector(loadData) withObject:nil afterDelay:0.5];
       
   }];
    [self.view addSubview:toolBar];
    [toolBar release];
    //观察者，观察toolbar的变化
    [toolBar addObserver:self forKeyPath:FACEHIGHTSIGN options:NSKeyValueObservingOptionNew context:nil];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//cell需要定制
    MessageCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=  [[[MessageCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"]autorelease];
         cell.backgroundColor=[UIColor clearColor];
    }
    XMPPMessageArchiving_Message_CoreDataObject*object=self.dataArray[indexPath.row];

    [cell configUI:object leftImage:self.friendHeaderImage rightImage:self.myHeaderImage];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
   
    return cell;

}


#pragma mark 当toolBar的frame有变化时候，调用该方法
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSLog(@"toolBar~~~~~%f",toolBar.frame.origin.y);
    _tableView.frame=CGRectMake(0, 0, 320, toolBar.frame.origin.y);
    if (self.dataArray.count) {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}


//计算行高
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMPPMessageArchiving_Message_CoreDataObject*object=self.dataArray[indexPath.row];
    if ([object.body hasPrefix:MESSAGE_STR]) {
        CGSize size=[[object.body substringFromIndex:3] sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(200, 1000)];
        return size.height+30+20;
        
    }
    if ([object.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
        return 220;
    }
    if ([object.body hasPrefix:MESSAGE_VOICE]) {
        return 44;
    }
    if ([object.body hasPrefix:MESSAGE_IMAGESTR]) {
        UIImage*image=[Photo string2Image:[object.body substringFromIndex:3]];
        return image.size.height<200?image.size.height+20:220;
    }
    return 44;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
