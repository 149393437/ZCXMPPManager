//
//  ChatViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface ChatViewController : RootViewController
{
    ZCXMPPManager*_manager;

}
@property(nonatomic,copy)NSString*friendJid;
@property(nonatomic,retain)NSMutableArray*dataArray;
@property(nonatomic,retain)UIImage*myHeaderImage;
@property(nonatomic,retain)UIImage*friendHeaderImage;
@end
