//
//  GrouoDetailViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/7/5.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "GrouoDetailViewController.h"
#import "QRCodeGenerator.h"
@interface GrouoDetailViewController ()

@end

@implementation GrouoDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"群详情";
    [self themeColor];
    [self cretaeUI];
    // Do any additional setup after loading the view.
}
-(void)cretaeUI{
    succeedImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 54, 320, self.view.frame.size.height-[ZCControl isIOS7]-88) ImageName:nil];
    succeedImageView.backgroundColor=[UIColor colorWithRed:1 green:1 blue:1 alpha:0.7];
    [self.view addSubview:succeedImageView];
    
    UILabel*xx=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 44) Font:15 Text:@"群详情"];
    xx.textAlignment=NSTextAlignmentCenter;
    [succeedImageView addSubview:xx];
    //group1@2x.png
                //主题
                UIImageView*subjcetImageView1=[ZCControl createImageViewWithFrame:CGRectMake(40, 40, 20, 20) ImageName:@"group1.png"];
                [succeedImageView addSubview:subjcetImageView1];
    
                subjectLabel=[ZCControl createLabelWithFrame:CGRectMake(80, 30, 240, 44) Font:12 Text:[NSString stringWithFormat:@"群号：%@",self.groupNum]];
                [succeedImageView addSubview:subjectLabel];
    //描述
    UIImageView*desImageView=[ZCControl createImageViewWithFrame:CGRectMake(40, 74, 20, 20) ImageName:@"group2.png"];
    [succeedImageView addSubview:desImageView];
    desLabel=[ZCControl createLabelWithFrame:CGRectMake(80, 64, 240-44, 44) Font:12 Text:[NSString stringWithFormat:@"描述：%@",[_roomConfigDic objectForKey:@"des"]]];
    desLabel.adjustsFontSizeToFitWidth=YES;
    
    [succeedImageView addSubview:desLabel];
    //当前人数
    UIImageView*numImageView=[ZCControl createImageViewWithFrame:CGRectMake(40,114 , 20, 20) ImageName:@"group3.png"];
    [succeedImageView addSubview:numImageView];
    numLabel=[ZCControl createLabelWithFrame:CGRectMake(80, 104, 240, 44) Font:12 Text:[NSString stringWithFormat:@"当前在线%@人",[_roomConfigDic objectForKey:@"num"]]];
    [succeedImageView addSubview:numLabel];
    //创建日期
    UIImageView*timeImageView=[ZCControl createImageViewWithFrame:CGRectMake(40,154 , 20, 20) ImageName:@"group4.png"];
    [succeedImageView addSubview:timeImageView];
    
    NSString* string =[[[_roomConfigDic objectForKey:@"time"] stringByReplacingOccurrencesOfString:@"T" withString:@""]stringByReplacingOccurrencesOfString:@":" withString:@""];
    NSDateFormatter *inputFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [inputFormatter setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
    [inputFormatter setDateFormat:@"yyyyMMddHHmmss"];
    NSDate* inputDate = [inputFormatter dateFromString:string];
    
    NSDateFormatter *outputFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [outputFormatter setLocale:[NSLocale currentLocale]];
    [outputFormatter setDateFormat:@"yyyy年MM月dd日 HH时mm分ss秒"];
    NSString *str1 = [outputFormatter stringFromDate:inputDate];
    
    
    timeLabel=[ZCControl createLabelWithFrame:CGRectMake(80, 144, 240, 44) Font:12 Text:[NSString stringWithFormat:@"创建时间：%@",str1]];
    [succeedImageView addSubview:timeLabel];
    //进入
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:GROUNDROOMCONFIG]) {
        createButton=[ZCControl createButtonWithFrame:CGRectMake(0, 184, 320, 44) ImageName:nil Target:self Action:@selector(createBUttonClick) Title:@"邀请好友进群"];
        [succeedImageView addSubview:createButton];
        
        UIButton*edit=[ZCControl createButtonWithFrame:CGRectMake(260, 64, 44, 44) ImageName:nil Target:self Action:@selector(editClick) Title:nil];
        [edit setImage:[UIImage imageNamed:@"icon_edit.png"] forState:UIControlStateNormal];
        [edit setImageEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
        [succeedImageView addSubview:edit];
        
        //创建二维码
        UIImageView*qrImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 100, 100) ImageName:nil];
        qrImageView.image=[QRCodeGenerator qrImageForString:[NSString stringWithFormat:@"[1]%@",self.groupNum] imageSize:300];
        qrImageView.center=CGPointMake(self.view.center.x,self.view.center.y+20);
        [succeedImageView addSubview:qrImageView];
        
        UILabel*label1=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 20) Font:8 Text:@"你的好友扫二维码即可加入群组"];
        label1.textAlignment=NSTextAlignmentCenter;
        label1.textColor=[UIColor redColor];
        label1.center=CGPointMake(self.view.center.x, self.view.center.y+70);
        [succeedImageView addSubview:label1];
    }
  

    

}
#pragma mark 邀请好友
-(void)createBUttonClick{
    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"输入好友的账号" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    al.alertViewStyle=UIAlertViewStylePlainTextInput;
    al.tag=100;
    [al show];
    [al release];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex&&alertView.tag==100) {
       UITextField*textField= [alertView textFieldAtIndex:0];
        if (textField.text.length>0) {
             [[ZCXMPPManager sharedInstance]inviteRoom:self.room userName:textField.text];
        }
    }
    if (buttonIndex&&alertView.tag==200) {
        UITextField*textField= [alertView textFieldAtIndex:0];
        if (textField.text.length>0) {
            NSMutableDictionary*dic=[NSMutableDictionary dictionaryWithDictionary:self.roomConfigDic];
            [dic setObject:textField.text forKey:@"desName"];
            NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
            [user setObject:dic forKey:GROUNDNAME];
            [user synchronize];
            [[ZCXMPPManager sharedInstance]configRoom:self.room config:nil];
            desLabel.text=[NSString stringWithFormat:@"描述：%@",textField.text];
        }
    }
    
}
#pragma mark
-(void)editClick{

    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"可以修改群主题" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    al.alertViewStyle=UIAlertViewStylePlainTextInput;
    al.tag=200;
    [al show];
    [al release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
