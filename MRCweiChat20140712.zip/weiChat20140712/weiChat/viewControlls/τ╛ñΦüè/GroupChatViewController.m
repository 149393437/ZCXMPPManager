

//
//  GroupChatViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "GroupChatViewController.h"
#import "FaceToolBar.h"
#import "GroupMessageCell.h"
#import "Photo.h"
#import "GrouoDetailViewController.h"
@interface GroupChatViewController ()
{
    FaceToolBar*toolBar;
    UIButton*rightNavButton;
    UIButton*configNavButton;
    UIButton*leftNavButton;

}
@end

@implementation GroupChatViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc
{
    //移除观察者
    [toolBar removeObserver:self forKeyPath:@"frame"];
    [super dealloc];

}
-(void)viewWillAppear:(BOOL)animated
{
    if (isFirst) {
        [[ZCXMPPManager sharedInstance]fetchRoomName:self.roomJid Block:^(NSDictionary *dic) {
            self.title=[dic objectForKey:@"des"];
            
            self.roomConifgDic=[NSDictionary dictionaryWithDictionary:dic];
        }];
        [toolBar dismissKeyBoard];

    }

}
- (void)viewDidLoad
{
    [super viewDidLoad];

    [self createBgView];
    self.dataArray=[NSMutableArray arrayWithCapacity:0];
    [[ZCXMPPManager sharedInstance]getMyVcardBlock:^(BOOL isFinish, XMPPvCardTemp *my) {
        self.myvCard=my;
    }];
    
    
    [self createTableView];
    [self createFaceTooBar];
    [self loadData];
    [self leftNav];
    
} 
-(void)createBgView{
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    NSString*str=[user objectForKey:@"chatBackGround"];
    if (str) {
        
        if ([str integerValue]!=12) {
            UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_%d.jpg",NSHomeDirectory(),100+[str intValue]]];
            UIImageView*imageview=[[UIImageView alloc]initWithImage:image];
            imageview.frame=self.view.frame;
            imageview.userInteractionEnabled=YES;
            self.view=imageview;
        }else{
            UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/Documents/chatBg1/chat_bg_%d.jpg",NSHomeDirectory(),[str intValue]]];
            UIImageView*imageview=[[UIImageView alloc]initWithImage:image];
            imageview.frame=self.view.frame;
            imageview.userInteractionEnabled=YES;
            self.view=imageview;
        }
        
    }else{
        
        UIImageView*imageview=[[UIImageView alloc]initWithImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bg_default.jpg",self.path ]]];
        imageview.frame=self.view.frame;
        imageview.userInteractionEnabled=YES;
        self.view=imageview;
    }
}


-(void)rightNav{
    rightNavButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 40, 40) ImageName:nil Target:self Action:@selector(rightNavButtonClick) Title:nil];
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithCustomView:rightNavButton];

    UIImage*image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_icon_group@2x.png",self.path]];
    [rightNavButton setImage:image1 forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem=item;
    [item release];
    
    
}

-(void)leftNav
{
    leftNavButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 40) ImageName:nil Target:self Action:@selector(leftNavButtonClick) Title:nil];
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithCustomView:leftNavButton];
    self.navigationItem.leftBarButtonItem=item;
    [item release];
    //设置右边按钮图片
    //header_icon_single@2x.png
    UIImage*image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_leftbtn_nor@2x.png",self.path]];
    [leftNavButton setImage:image1 forState:UIControlStateNormal];
    

}
-(void)leftNavButtonClick{
    //离开房间
    [[ZCXMPPManager sharedInstance]XmppOutRoom:room];
    [self.navigationController popToRootViewControllerAnimated:YES];
    

}

-(void)rightNavButtonClick{
    isFirst=YES;
    GrouoDetailViewController*vc=[[GrouoDetailViewController alloc]init];
    vc.room=room;
    vc.groupNum=_roomJid;
    vc.roomConfigDic=self.roomConifgDic;
    vc.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:vc animated:YES];
    
    
}


-(void)createFaceTooBar{
toolBar=[[FaceToolBar alloc]initWithFrame:CGRectMake(0, 100, 320, 44) voice:nil ViewController:self Block:^(NSString *sign, NSString *value) {
    
    NSString*message=[NSString stringWithFormat:@"%@%@",sign,value];
         [[ZCXMPPManager sharedInstance]sendGroupMessage:message roomName:self.roomJid];
    
}];
    [self.view addSubview:toolBar];
    [toolBar release];
    
    //建立观察者,需要注意dealloc里面移除观察者
    [toolBar addObserver:self forKeyPath:@"frame" options:NSKeyValueObservingOptionNew context:nil];
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    _tableView.frame=CGRectMake(0, 0, 320, toolBar.frame.origin.y);
    if (self.dataArray.count) {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        
    }
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-44) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    //隐藏cell阴影线
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    [_tableView release];
    [self themeColor];
    
}
-(void)loadData{
    //加入房间 扩展一个方法 携带block，随时返回相应的群聊数据
//text001_1pi
    //654323454
  
    
    
room=[[ZCXMPPManager sharedInstance]xmppRoomCreateRoomName:self.roomJid nickName:[[NSUserDefaults standardUserDefaults]objectForKey:kXMPPmyJID]MessageBlock:^(NSDictionary *message) {
    [self.dataArray addObject:message];
    [_tableView reloadData];
    //产生位移
    if (self.dataArray.count) {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }

} presentBlock:^(NSDictionary *present) {
     [self rightNav];
    //进入成功，获取房间配置信息
    [[ZCXMPPManager sharedInstance]fetchRoomName:self.roomJid Block:^(NSDictionary *dic) {
        self.title=[dic objectForKey:@"des"];
        
        self.roomConifgDic=[NSDictionary dictionaryWithDictionary:dic];
    }];
    
   
}];
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;

}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GroupMessageCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[GroupMessageCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
           cell.backgroundColor=[UIColor clearColor];
    }
    NSDictionary*dic=self.dataArray[indexPath.row];
    XMPPMessage*message=[dic objectForKey:@"message"];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    if (self.myvCard.photo) {
        [cell configUI:message MyImage:[UIImage imageWithData:self.myvCard.photo]];

    }else{
     [cell configUI:message MyImage:nil];
    }
 
        return cell;

}

-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary*dic=self.dataArray[indexPath.row];
    XMPPMessage*object=[dic objectForKey:@"message"];
    if ([object.body hasPrefix:MESSAGE_STR]) {
        CGSize size=[[object.body substringFromIndex:3] sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(200, 1000)];
        return size.height+30+20;
        
    }
    if ([object.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
        return 220;
    }
    if ([object.body hasPrefix:MESSAGE_VOICE]) {
        return 44;
    }
    if ([object.body hasPrefix:MESSAGE_IMAGESTR]) {
        UIImage*image=[Photo string2Image:[object.body substringFromIndex:3]];
        return image.size.height<200?image.size.height+20:220;
    }
    return 44;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
