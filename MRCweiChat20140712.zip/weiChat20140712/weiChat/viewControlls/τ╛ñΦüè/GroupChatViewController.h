//
//  GroupChatViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface GroupChatViewController : RootViewController<UIAlertViewDelegate>
{
    XMPPRoom*room;
    BOOL isFirst;
    
}

@property(nonatomic,retain)XMPPvCardTemp*myvCard;
@property(nonatomic,copy)NSString*roomJid;
@property(nonatomic,retain)NSMutableArray*dataArray;
@property(nonatomic,retain)NSDictionary*roomConifgDic;
@end
