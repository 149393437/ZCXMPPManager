//
//  GroupCheckViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "GroupCheckViewController.h"
#import "GroupChatViewController.h"
#import "GroupCheckCell.h"
@interface GroupCheckViewController ()

@end

@implementation GroupCheckViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];
    [self themeColor];
    

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GroupCheckCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[GroupCheckCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"]autorelease];
        cell.backgroundColor=[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.7];
        [cell.agreeButton addTarget:self action:@selector(agreeButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [cell.rejectButton addTarget:self action:@selector(rejectButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        cell.backgroundColor=[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.5];
    }
    NSDictionary*dic=self.dataArray[indexPath.row];
  
    [cell configUI:dic];
    cell.contentView.tag=indexPath.row;
    
    
    return cell;

}

//同意
-(void)agreeButtonClick:(UIButton*)button{

    GroupChatViewController*vc=[[GroupChatViewController alloc]init];

    vc.roomJid=[self.dataArray[button.superview.tag]objectForKey:@"from"];
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
    
}
//拒绝
-(void)rejectButtonClick:(UIButton*)button{
    button.selected=YES;
    //拒绝
    
    
    [[ZCXMPPManager sharedInstance]rejectRoom:[self.dataArray[button.superview.tag] objectForKey:@"from"]];
    NSString*path1=[NSString stringWithFormat:@"%@/Documents/groupCheckPlist.plist",NSHomeDirectory()];
    NSMutableArray*array=[NSMutableArray arrayWithContentsOfFile:path1];
    if (array) {
        [array removeObject:self.dataArray[button.superview.tag]];
        [array writeToFile:path1 atomically:YES];
    }
    
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
