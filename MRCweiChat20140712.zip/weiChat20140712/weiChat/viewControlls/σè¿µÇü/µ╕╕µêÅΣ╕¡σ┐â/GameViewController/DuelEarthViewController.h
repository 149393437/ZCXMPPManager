//
//  DuelEarthViewController.h
//  Crush
//
//  Created by Jinpeng on 14-7-7.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "PlayViewController.h"

@interface DuelEarthViewController : PlayViewController
{
    int p1e;
    int p2e;
}
@end
