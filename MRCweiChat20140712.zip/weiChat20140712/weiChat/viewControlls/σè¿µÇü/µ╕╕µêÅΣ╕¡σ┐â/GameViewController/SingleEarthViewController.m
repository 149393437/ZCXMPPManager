//
//  SingleEarthViewController.m
//  Crush
//
//  Created by qianfeng on 14-7-7.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "SingleEarthViewController.h"

@interface SingleEarthViewController ()

@end

@implementation SingleEarthViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        isSingle=1;
        p1e=0;
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)doEarth:(NSString*)key{
    place0.hidden=NO;
    place1.hidden=NO;
    place1.text=[NSString stringWithFormat:@"盘子:%d/60",p1e];
    place0.text=[NSString stringWithFormat:@"剩余:%d/%d步",25-self.rounds,25];
    NSString*str=key;
    int a=[str intValue];
    for (id key in self.Matrix) {
        if ([key intValue]==a) {
            return;
        }
    }
    if (zflag==YES) {
        return;
    }
    int x=a/10;
    int y=a%10;
    UIView*view=self.xdataArray[x][y];
    if (flag>0) {
        [self.Matrix setObject:@"1" forKey:key];
        view.backgroundColor=[UIColor orangeColor];
        p1e++;
        place1.text=[NSString stringWithFormat:@"盘子:%d/60",p1e];
    }
    
}

- (BOOL)isWin:(int)a{
    if (p1e>59) {
        self.rounds=0;
        return YES;
    }else if(self.rounds>=25){
        self.rounds=10000;
        return YES;
    }
    return NO;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
