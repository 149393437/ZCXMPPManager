//
//  JPMyControl.h
//  JPSns
//
//  Created by student on 14-5-5.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import <Foundation/Foundation.h>


#define IOS7 [[[UIDevice currentDevice] systemVersion]floatValue]>=7.0
@interface JPMyControl : NSObject




//使用＋方法进行创建 是工厂模式中的一种
//工厂模式：传入参数，出来控件

#pragma mark 创建View
+ (UIView*)createViewWithFrame:(CGRect)frame;
#pragma mark 创建Label
+ (UILabel*)createLabelWithFrame:(CGRect)frame Font:(float)font Text:(NSString*)text;
#pragma mark 创建button
+ (UIButton*)createButtonWithFrame:(CGRect)frame Target:(id)target SEL:(SEL)method Title:(NSString*)title ImageName:(NSString*)imageName bgImage:(NSString*)bgimageName Tag:(int)tag;
#pragma mark 创建imageView
+ (UIImageView*)createImageViewWithFrame:(CGRect)frame ImageName:(NSString*)imageName;
#pragma mark 创建textField
+ (UITextField*)createTextFieldWithFrame:(CGRect)frame Font:(float)font TextColor:(UIColor*)color LeftImageName:(NSString*)leftimageName RightImageName:(NSString*)rightImageName BgImageName:(NSString*)bgImageName;

+ (UITextField*)createTextFieldWithFrame:(CGRect)frame Font:(float)font TextColor:(UIColor*)color LeftImageName:(NSString*)leftimageName RightImageName:(NSString*)rightImageName BgImageName:(NSString*)bgImageName PlaceHolder:(NSString*)placeHolder sucureTextEntry:(BOOL)isOpen;

@end
