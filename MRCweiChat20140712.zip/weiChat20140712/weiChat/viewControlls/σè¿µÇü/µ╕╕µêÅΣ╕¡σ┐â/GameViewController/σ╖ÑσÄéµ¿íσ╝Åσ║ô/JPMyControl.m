//
//  JPMyControl.m
//  JPSns
//
//  Created by student on 14-5-5.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "JPMyControl.h"

@implementation JPMyControl
#pragma mark 创建View
+ (UIView*)createViewWithFrame:(CGRect)frame{
    UIView*view=[[UIView alloc]initWithFrame:frame];
    return [view autorelease];
}
#pragma mark 创建Label
+ (UILabel*)createLabelWithFrame:(CGRect)frame Font:(float)font Text:(NSString*)text{
    UILabel*label=[[[UILabel alloc]initWithFrame:frame]autorelease];
    label.font=[UIFont systemFontOfSize:font];
    label.lineBreakMode=NSLineBreakByWordWrapping;
    label.numberOfLines=0;
    label.textAlignment=NSTextAlignmentCenter;
    label.backgroundColor=[UIColor clearColor];
    label.text=text;
//    label.adjustsFontSizeToFitWidth=YES;
    return label;
    
}
#pragma mark 创建button
+ (UIButton*)createButtonWithFrame:(CGRect)frame Target:(id)target SEL:(SEL)method Title:(NSString*)title ImageName:(NSString*)imageName bgImage:(NSString*)bgimageName Tag:(int)tag{
    UIButton*button=[UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:bgimageName] forState:UIControlStateNormal];
    button.frame=frame;
    [button addTarget:target action:method forControlEvents:UIControlEventTouchUpInside];
    button.tag=tag;
    return button;
}
#pragma mark 创建imageView
+ (UIImageView*)createImageViewWithFrame:(CGRect)frame ImageName:(NSString*)imageName{
    UIImageView*imageView=[[[UIImageView alloc]initWithFrame:frame]autorelease];
    imageView.image=[UIImage imageNamed:imageName];
    //用户交互打开
    imageView.userInteractionEnabled=YES;
    
    return imageView;
}

#pragma mark 创建textField
+ (UITextField*)createTextFieldWithFrame:(CGRect)frame Font:(float)font TextColor:(UIColor*)color LeftImageName:(NSString*)leftimageName RightImageName:(NSString*)rightImageName BgImageName:(NSString*)bgImageName{
    UITextField*textField=[[[UITextField alloc]initWithFrame:frame]autorelease];
    textField.font=[UIFont systemFontOfSize:font];
    textField.textColor=color;
//    左侧图片
    UIImage*image=[UIImage imageNamed:leftimageName];
    UIImageView*leftImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    leftImageView.image=image;
    textField.leftView=leftImageView;
    [leftImageView release];
    textField.leftViewMode=UITextFieldViewModeAlways;
//    右侧图片
    UIImage*image1=[UIImage imageNamed:rightImageName];
    UIImageView*rightImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, image1.size.width, image1.size.height)];
    rightImageView.image=image1;
    textField.rightView=rightImageView;
    [rightImageView release];
    textField.rightViewMode=UITextFieldViewModeAlways;
    textField.clearButtonMode=YES;
//    密码遮掩
//    textField.secureTextEntry;
//    提示框
//    textField.placeholder;
    return textField;
}

//   适配器 为了适配以前的版本 和现有已经开发的所有功能模块，在原有功能模块基础上进行扩展的方式
+ (UITextField*)createTextFieldWithFrame:(CGRect)frame Font:(float)font TextColor:(UIColor*)color LeftImageName:(NSString*)leftimageName RightImageName:(NSString*)rightImageName BgImageName:(NSString*)bgImageName PlaceHolder:(NSString*)placeHolder sucureTextEntry:(BOOL)isOpen{    
    UITextField*textField=[JPMyControl createTextFieldWithFrame:frame Font:font TextColor:color LeftImageName:leftimageName RightImageName:rightImageName BgImageName:bgImageName];
    textField.placeholder=placeHolder;
    textField.secureTextEntry=isOpen;
    return textField;
}

    


@end
