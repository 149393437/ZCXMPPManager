//
//  PlayViewController.h
//  Crush
//
//  Created by Jinpeng on 14-6-26.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomButton.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
@class CAEmitterLayer;
@interface PlayViewController : UIViewController<UIAlertViewDelegate>{
    CustomButton*_tempButton;
    UIButton*_flagButton;
    UIButton*_setup;
    UIImageView*bgView;
    UIImageView*winBg;
    UIImageView*winView;
    int boons;
    int flag;
    int isSingle;
    int s;
    BOOL zflag;
    UILabel*user1;
    UILabel*user2;
    UILabel*moving;
    UILabel*place0;
    UILabel*place1;
    UILabel*place2;
    NSTimer*s1Time;
    NSTimer*s2Time;
    NSUInteger xx1;
    NSUInteger xx2;
    AVAudioPlayer *_player;
    NSTimer *_playTimer;
    int earth;
}
@property (nonatomic,retain) NSMutableArray*x0;
@property (nonatomic,retain) NSMutableArray*x1;
@property (nonatomic,retain) NSMutableArray*x2;
@property (nonatomic,retain) NSMutableArray*x3;
@property (nonatomic,retain) NSMutableArray*x4;
@property (nonatomic,retain) NSMutableArray*x5;
@property (nonatomic,retain) NSMutableArray*x6;
@property (nonatomic,retain) NSMutableArray*x7;
@property (nonatomic,retain) NSMutableArray*x8;
@property (nonatomic,retain) NSMutableArray*dataArray;
@property (nonatomic)int mission;
@property (nonatomic,retain)NSMutableArray*cook;
@property (nonatomic) int rounds;
@property (strong) CAEmitterLayer *ringEmitter;

@property (nonatomic,retain) NSMutableArray*xx0;
@property (nonatomic,retain) NSMutableArray*xx1;
@property (nonatomic,retain) NSMutableArray*xx2;
@property (nonatomic,retain) NSMutableArray*xx3;
@property (nonatomic,retain) NSMutableArray*xx4;
@property (nonatomic,retain) NSMutableArray*xx5;
@property (nonatomic,retain) NSMutableArray*xx6;
@property (nonatomic,retain) NSMutableArray*xx7;

@property (nonatomic,retain) NSMutableArray*xdataArray;
@property (nonatomic,retain) NSMutableDictionary*Matrix;

- (void) touchAtPosition:(CGPoint)position;

@end
