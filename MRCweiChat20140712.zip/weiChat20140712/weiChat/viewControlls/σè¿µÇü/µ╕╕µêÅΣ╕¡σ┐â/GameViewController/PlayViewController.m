//
//  PlayViewController.m
//  Crush
//
//  Created by Jinpeng on 14-6-26.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "PlayViewController.h"
#import <QuartzCore/QuartzCore.h>
#import <QuartzCore/CoreAnimation.h>

@implementation PlayViewController
@synthesize ringEmitter;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        isSingle=-1;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.Matrix=[NSMutableDictionary new];
    flag=1;
    self.rounds=0;
    _tempButton=nil;
    _flagButton=[CustomButton new];
    _flagButton.tag=1000;
    [self buildData];
    //    播放音乐
    //    [self playM];
    //    循环播放音乐
    _playTimer=[NSTimer scheduledTimerWithTimeInterval:65 target:self selector:@selector(playM) userInfo:nil repeats:YES];
    [_playTimer setFireDate:[NSDate distantPast]];
    
    bgView=[JPMyControl createImageViewWithFrame:CGRectMake(0, 20, 320, 320) ImageName:@""];
    [self.view addSubview:bgView];
    bgView.backgroundColor=[UIColor grayColor];
    
    [self createMatrix];
    [self createRing];
    [self creatBoom];
    //    [self createWinView:NO];
    
    s1Time=[NSTimer scheduledTimerWithTimeInterval:.01 target:self selector:@selector(refreshsc1) userInfo:nil repeats:YES];
    s2Time=[NSTimer scheduledTimerWithTimeInterval:.01 target:self selector:@selector(refreshsc2) userInfo:nil repeats:YES];
    [s1Time setFireDate:[NSDate distantFuture]];
    [s2Time setFireDate:[NSDate distantFuture]];
    
}

- (void)doEarth:(NSString*)key{
    
}

#pragma mark 创建胜负弹出框
- (void)createWinView:(BOOL)isWin{
    winBg=[JPMyControl createImageViewWithFrame:self.view.frame ImageName:@""];
    winBg.backgroundColor=[UIColor whiteColor];
    winBg.alpha=.6;
    winView=[JPMyControl createImageViewWithFrame:CGRectMake(0, 480, 320, 316) ImageName:@"win.jpg"];
    [self.view addSubview:winBg];
    [self.view addSubview:winView];
    //    UILabel*label=[JPMyControl createLabelWithFrame:CGRectMake(20, 20, 280, 80) Font:40 Text:@"胜 利"];
    if (!isWin) {
        winView.image=[UIImage imageNamed:@"loss.jpg"];
    }
    winView.alpha=.3;
    [UIView animateWithDuration:1 animations:^{
        winView.alpha=1;
        winView.frame=CGRectMake(0, 170, 320, 316);
    }];
    winView.userInteractionEnabled=YES;
    
    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(backToSelect)];
    //需求几个手指进行触发 ,iphone里面默认最多11根手指
    //点击几次进行触发
    tap.numberOfTapsRequired=1;
    //需求触摸的点
    [tap setNumberOfTouchesRequired:1];
    [winView addGestureRecognizer:tap];
    
    
}

#pragma mark 创建对战界面
- (void)createRing{
    int high;
    int high1;
    high=self.view.frame.size.height-420;
    high1=self.view.frame.size.height-370;
    
    _setup=[JPMyControl createButtonWithFrame:CGRectMake(145, high1, 30, 30) Target:self SEL:@selector(setupClick) Title:@"" ImageName:@"" bgImage:@"backarrow.png" Tag:0];
    user1=[JPMyControl createLabelWithFrame:CGRectMake(47, 5, 70, 20) Font:14 Text:@"0"];
    user2=[JPMyControl createLabelWithFrame:CGRectMake(320-70-5, 5, 70, 20) Font:14 Text:@"0"];
    user1.textAlignment=NSTextAlignmentLeft;
    user2.textAlignment=NSTextAlignmentLeft;
    UILabel*sc1=[JPMyControl createLabelWithFrame:CGRectMake(0, 5, 50, 20) Font:14 Text:@"1P:"];
    UILabel*sc2=[JPMyControl createLabelWithFrame:CGRectMake(320-70-47, 5, 50, 20) Font:14 Text:@"2P:"];
    
    UIImageView*ringView=[JPMyControl createImageViewWithFrame:CGRectMake(0, 320+20, 320, self.view.frame.size.height-340) ImageName:@"ring.jpg"];
    ringView.backgroundColor=[UIColor colorWithRed:.2 green:.2 blue:.3 alpha:.9];
    [self.view addSubview:ringView];
    [ringView addSubview:sc1];
    [ringView addSubview:sc2];
    [ringView addSubview:user1];
    [ringView addSubview:user2];
    
    moving=[JPMyControl createLabelWithFrame:CGRectMake(10, 22, 50, 20) Font:14 Text:@"行动中"];
    [ringView addSubview:moving];
    if (flag<0) {
        moving.frame=CGRectMake(320-95-12,22 , 50, 20);
    }
    [moving setTextColor:[UIColor redColor]];
    
    //    UIImageView*leftFighter=[JPMyControl createImageViewWithFrame:CGRectMake(5, 30, 50, 50) ImageName:@"1.jpg"];
    //    UIImageView*rightFigher=[JPMyControl createImageViewWithFrame:CGRectMake(320-5-50, 30, 50, 50) ImageName:@"2.jpg"];
    //    [ringView addSubview:leftFighter];
    //    [ringView addSubview:rightFigher];
    //    UIView*cut=[JPMyControl createViewWithFrame:CGRectMake(159, 0, 2, 140)];
    //    cut.backgroundColor=[UIColor redColor];
    //    [ringView addSubview:cut];
    
    [ringView addSubview:_setup];
    //    for (int i=0; i<self.mission; i++) {
    UIImageView* view=[JPMyControl createImageViewWithFrame:CGRectMake(35, high+5, 120, 20) ImageName:@"shortwood1"];
    [ringView addSubview:view];
    
    UIImageView* view0=[JPMyControl createImageViewWithFrame:CGRectMake(35, high+30, 120, 20) ImageName:@"shortwood1"];
    [ringView addSubview:view0];
    
    place1=[JPMyControl createLabelWithFrame:CGRectMake(0, 0, 120, 18) Font:16 Text:@"盘子:0/29"];
    place1.hidden=YES;
    [view addSubview:place1];
    
    place0=[JPMyControl createLabelWithFrame:CGRectMake(0, 0, 120, 18) Font:16 Text:[NSString stringWithFormat:@"剩余:%d/%d",self.mission*2+5,self.mission*2+5]];
    place0.hidden=YES;
    place1.hidden=YES;
    [view0 addSubview:place0];
    
    UIImageView* view1=[JPMyControl createImageViewWithFrame:CGRectMake(50+120, high+5, 120, 20) ImageName:@"shortwood1"];
    [ringView addSubview:view1];
    
    UIImageView* view2=[JPMyControl createImageViewWithFrame:CGRectMake(50+120, high+30, 120, 20) ImageName:@"shortwood1"];
    [ringView addSubview:view2];
    
    place2=[JPMyControl createLabelWithFrame:CGRectMake(0, 0, 120, 18) Font:16 Text:@"盘子:0/28"];
    place2.hidden=YES;
    [view1 addSubview:place2];
    //
    //    }
    
    
}
- (void)setupClick{
    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"返回选关画面" message:[NSString stringWithFormat:@"您确定返回选关画面吗？\n本关进度将不会被保存。"] delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [al show];
    
    //    [self.navigationController popViewControllerAnimated:YES];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)backToSelect{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark 刷新界面和积分
- (void)scores:(NSNumber*)a{
    if (flag==1) {
        NSUInteger a1=[a integerValue];
        xx1=[user1.text integerValue];
        xx1+=a1;
        [s1Time setFireDate:[NSDate distantPast]];
    }
    if (flag==-1) {
        NSUInteger a2=[a integerValue];
        xx2=[user2.text integerValue];
        xx2+=a2;
        [s2Time setFireDate:[NSDate distantPast]];
    }
    
}

- (void)refreshsc1{
    NSUInteger x=[user1.text integerValue];
    if (x==xx1) {
        [s1Time setFireDate:[NSDate distantFuture]];
        return;
    }
    user1.text=[NSString stringWithFormat:@"%d",x+=10];
}

- (void)refreshsc2{
    NSUInteger x=[user2.text integerValue];
    if (x==xx2) {
        [s2Time setFireDate:[NSDate distantFuture]];
        return;
    }
    user2.text=[NSString stringWithFormat:@"%d",x+=10];
    
}


- (void)buildData{
    self.dataArray=[NSMutableArray new];
    self.x0=[NSMutableArray new];
    [self.dataArray addObject:self.x0];
    self.x1=[NSMutableArray new];
    [self.dataArray addObject:self.x1];
    self.x2=[NSMutableArray new];
    [self.dataArray addObject:self.x2];
    self.x3=[NSMutableArray new];
    [self.dataArray addObject:self.x3];
    self.x4=[NSMutableArray new];
    [self.dataArray addObject:self.x4];
    self.x5=[NSMutableArray new];
    [self.dataArray addObject:self.x5];
    self.x6=[NSMutableArray new];
    [self.dataArray addObject:self.x6];
    self.x7=[NSMutableArray new];
    [self.dataArray addObject:self.x7];
    
    self.xdataArray=[NSMutableArray new];
    self.xx0=[NSMutableArray new];
    [self.xdataArray addObject:self.xx0];
    self.xx1=[NSMutableArray new];
    [self.xdataArray addObject:self.xx1];
    self.xx2=[NSMutableArray new];
    [self.xdataArray addObject:self.xx2];
    self.xx3=[NSMutableArray new];
    [self.xdataArray addObject:self.xx3];
    self.xx4=[NSMutableArray new];
    [self.xdataArray addObject:self.xx4];
    self.xx5=[NSMutableArray new];
    [self.xdataArray addObject:self.xx5];
    self.xx6=[NSMutableArray new];
    [self.xdataArray addObject:self.xx6];
    self.xx7=[NSMutableArray new];
    [self.xdataArray addObject:self.xx7];
    
}

#pragma mark 新构建矩阵
- (void)createMatrix{
    s=KINDS+self.mission/10;
    for (int i=0; i<64; i++) {
        UIView*view=[JPMyControl createViewWithFrame:CGRectMake(4+(i/8)*39,4+((63-i)%8)*39, 39, 39)];
        [self.xdataArray[i/8] addObject:view];
        [bgView addSubview:view];
    }
    
    for (int i=0; i<64; i++) {
        
        int title=arc4random()%s;
        //        UIButton*button=[JPMyControl createButtonWithFrame:CGRectMake(4+(i/8)*39, 320+4+((63-i)%8)*39, 37, 37) Target:self SEL:@selector(buttonMove:) Title:[NSString stringWithFormat:@"%d",title] ImageName:@"" bgImage:[NSString stringWithFormat:@"%d.png",title] Tag:100+i];
        CustomButton*button=[[CustomButton alloc]initWithFrame:CGRectMake(5+(i/8)*39, 320+5+((63-i)%8)*39, 37, 37)];
        
        [button setTitle:[NSString stringWithFormat:@"%d",title] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d.png",title]] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(buttonMove:) forControlEvents:UIControlEventTouchUpInside];
        [button flashoff];
        button.alpha=.8;
        //        [button flashon];
        button.tag=100+i;
        //        button.alpha=.7;
        [button setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        //        [button setBackgroundImage:[UIImage imageNamed:@"Pumpkin.png"] forState:UIControlStateSelected];
        //        NSLog(@"%@",button.titleLabel.text);
        
        //        view.backgroundColor=[UIColor redColor];
        [self.dataArray[i/8] addObject:button];
        
        [bgView addSubview:button];
    }
    [bgView.layer addSublayer:ringEmitter];
    zflag=YES;
    [self dropFood];
    [_tempButton flashoff];
    _tempButton=nil;
    [self performSelector:@selector(crushButton:) withObject:_flagButton afterDelay:1];
    
}

#pragma mark 判断界面内有多少可消除food，并把其坐标作为key存在一个字典中
- (void)crushButton:(CustomButton*)flagButton{
    NSMutableDictionary*temp=[NSMutableDictionary new];
    //    NSMutableArray*temparr=[NSMutableArray new];
    for (int i=0; i<8; i++) {
        for (int j=0; j<8; j++) {
            CustomButton*button=self.dataArray[i][j];
            
            if (j<6) {
                
                CustomButton*buttonj1=self.dataArray[i][j+1];
                CustomButton*buttonj2=self.dataArray[i][j+2];
                
                
                if ([button.titleLabel.text intValue]==[buttonj1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttonj2.titleLabel.text intValue]) {
                    //                [temp addObjectsFromArray:@[self.dataArray[i][j],self.dataArray[i][j+1],self.dataArray[i][j+2]]];
                    [temp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
                    [temp setObject:self.dataArray[i][j+1] forKey:[NSString stringWithFormat:@"%d%d",i,j+1]];
                    [temp setObject:self.dataArray[i][j+2] forKey:[NSString stringWithFormat:@"%d%d",i,j+2]];
                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i][j+1] title]intValue],[[self.dataArray[i][j+2] title]intValue]);
                }}
            if (i<6) {
                
                CustomButton*buttoni1=self.dataArray[i+1][j];
                CustomButton*buttoni2=self.dataArray[i+2][j];
                if ([button.titleLabel.text intValue]==[buttoni1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttoni2.titleLabel.text intValue]) {
                    [temp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
                    [temp setObject:self.dataArray[i+1][j] forKey:[NSString stringWithFormat:@"%d%d",i+1,j]];
                    [temp setObject:self.dataArray[i+2][j] forKey:[NSString stringWithFormat:@"%d%d",i+2,j]];
                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i+1][j] title]intValue],[[self.dataArray[i+2][j] title]intValue]);
                }
            }
        }
        
    }
    //    违规操作时，还原移动并归还操作权
    if (zflag==NO&&temp.count==0&&flagButton!=nil) {
        [self crossButton:flagButton];
        [self performSelector:@selector(buttonOn) withObject:self afterDelay:.5];
        return;
    }
    
    
    //    当消除结束时，计算总分，并计算可消除food点
    
    if (zflag==NO&& temp.count==0&&boons>0) {
        NSLog(@"%d",boons);
        
        NSUInteger a=0;
        for (int i=0; i<boons; i++) {
            a+=i;
        }
        NSNumber*a1=[NSNumber numberWithInteger:a*100];
        [self scores:a1];
        if ([self isWin:a*100]) {
            if (self.rounds<self.mission*2+5) {
                [self finished:YES];
            }else
                [self finished:NO];
            return;
        }
        if (boons<7) {
            flag*=isSingle;
            self.rounds++;
            if (flag<0) {
                moving.frame=CGRectMake(320-95-12, 22, 50, 20);
            }else{
                moving.frame=CGRectMake(10, 22, 50, 20);
            }
            
        }
        
        
        
    }
    //    if (zflag==YES&&temp.count==0) {
    //        [self fixMatrix];
    //        _tempButton=nil;
    //        zflag=NO;
    //        boons=0;
    //    }
    if (temp.count==0) {
        [_tempButton flashoff];
        _tempButton=nil;
        [self performSelector:@selector(fixMatrix) withObject:self afterDelay:.5];
        boons=0;
        zflag=NO;
        if (flag>0) {
            [self performSelector:@selector(buttonOn) withObject:self afterDelay:1];
        }
    }
    
    //    正常计算消除结果后，调用消除动画，并把存储消除foods的字典传递给消除动画函数
    //    _tempButton=nil;
    if (temp.count>0) {
        [self crush:temp];
    }
    
}
#pragma mark 判断胜负
- (BOOL)isWin:(int)a{
    if (flag>0) {
        if ([user1.text intValue]+a>=self.mission*1000) {
            //            [self finished:YES];
            self.rounds=0;
            return YES;
        }
    }
    if (flag<0) {
        if ([user2.text intValue]+a>=self.mission*1000) {
            //            [self finished:NO];
            self.rounds=10000;
            return YES;
        }
    }
    return NO;
}

- (void)ani:(CustomButton*)button{
    [button removeFromSuperview];
}

#pragma mark 从数组中去除消掉的foods，并在视图外重新构建新的foods等待掉落，并调用掉落函数
- (void)crush:(NSMutableDictionary*)temp{
    for (id key in temp) {
        [self doEarth:key];
        CustomButton*button=[temp objectForKey:key];
        int x=button.frame.origin.x/39;
        //        NSLog(@"%d",x);
        //        int y=button.frame.origin.y/39;
        [self.dataArray[x] removeObject:button];
    }
    for (id key in temp) {
        CustomButton*button=[temp objectForKey:key];
        int x=button.frame.origin.x/39;
        int title=arc4random()%s;
        
        [UIView animateWithDuration:.5 animations:^{
            button.alpha=0.3;
            button.frame=CGRectMake(button.frame.origin.x,button.frame.origin.y, 100, 100);
            
        }];
        [self performSelector:@selector(ani:) withObject:button afterDelay:.5];
        [self playShort];
        [self touchAtPosition:CGPointMake(button.frame.origin.x+18, button.frame.origin.y+19)];
        
        //        UIButton*newButton=[JPMyControl createButtonWithFrame:CGRectMake(button.frame.origin.x, button.frame.origin.y-320, 37, 37) Target:self SEL:@selector(buttonMove:) Title:[NSString stringWithFormat:@"%d",title] ImageName:@"" bgImage:[NSString stringWithFormat:@"%d.png",title] Tag:button.tag];
        CustomButton*newButton=[[CustomButton alloc]initWithFrame:CGRectMake(button.frame.origin.x, button.frame.origin.y-320, 37, 37)];
        [newButton setTitle:[NSString stringWithFormat:@"%d",title] forState:UIControlStateNormal];
        [newButton setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d.png",title]] forState:UIControlStateNormal];
        [newButton addTarget:self action:@selector(buttonMove:) forControlEvents:UIControlEventTouchUpInside];
        [newButton flashoff];
        newButton.alpha=.8;
        newButton.tag=button.tag;
        //        [newButton setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        [newButton setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];
        newButton.userInteractionEnabled=NO;
        
        
        
        
        [bgView addSubview:newButton];
        [self.dataArray[x] addObject:newButton];
        button=nil;
    }
    [bgView.layer addSublayer:ringEmitter];
    [self dropFood];
    //    for (int i=0; i<8; i++) {
    //        [self.dataArray[i] removeObjectsInArray:temp];
    //    }
    //    while (temp.count) {
    //        [[temp lastObject]removeFromSuperview];
    //        [temp removeLastObject];
    //    }
    
    //    叠加分数该次消除的分数，并在消除结束后再次调用计算消除函数，检查是否可达成连锁消除
    
    [self performSelector:@selector(crushButton:) withObject:nil afterDelay:1.1];
    boons+=temp.count;
    temp=nil;
    
    
}

#pragma mark 每次消除结束后掉落新的food，填充空白
- (void)dropFood{
    
    [UIView animateWithDuration:1 animations:^{
        for (int i=0;i<8 ;i++) {
            for (int j=0; j<8; j++) {
                CustomButton*button=self.dataArray[i][j];
                button.frame=CGRectMake(button.frame.origin.x, (7-j)*39+5, 37, 37) ;
            }
        }
    }];
    
}

#pragma mark 计算移动后是否有可消除food，如果没有重新构建矩阵
- (void)fixMatrix{
    NSMutableDictionary*uptmp=[NSMutableDictionary new];
    NSMutableDictionary*downtmp=[NSMutableDictionary new];
    NSMutableDictionary*leftmp=[NSMutableDictionary new];
    NSMutableDictionary*rightmp=[NSMutableDictionary new];
    for (int i=0; i<8; i++) {
        for (int j=0; j<8; j++) {
            //             UIButton*button=self.dataArray[i][j];
            //            移动后 由中部引发 消除
            if (j<6&&i<7) {
                CustomButton*buttonM0=self.dataArray[i][j];
                CustomButton*buttonM2=self.dataArray[i][j+2];
                CustomButton*buttonM=self.dataArray[i+1][j+1];
                int m=[buttonM.titleLabel.text intValue];
                int m0=[buttonM0.titleLabel.text intValue];
                int m2=[buttonM2.titleLabel.text intValue];
                if (m0==m2&&m0==m) {
                    [leftmp setObject:buttonM forKey:[NSString stringWithFormat:@"%d%d",i+1,j+1]];
                }
            }
            if (j<7&&i<6) {
                CustomButton*buttonM0=self.dataArray[i][j];
                CustomButton*buttonM2=self.dataArray[i+2][j];
                CustomButton*buttonM=self.dataArray[i+1][j+1];
                int m=[buttonM.titleLabel.text intValue];
                int m0=[buttonM0.titleLabel.text intValue];
                int m2=[buttonM2.titleLabel.text intValue];
                if (m0==m2&&m0==m) {
                    [downtmp setObject:buttonM forKey:[NSString stringWithFormat:@"%d%d",i+1,j+1]];
                }
            }
            if (j>2&&i>1) {
                CustomButton*buttonM0=self.dataArray[i][j];
                CustomButton*buttonM2=self.dataArray[i][j-2];
                CustomButton*buttonM=self.dataArray[i-1][j-1];
                int m=[buttonM.titleLabel.text intValue];
                int m0=[buttonM0.titleLabel.text intValue];
                int m2=[buttonM2.titleLabel.text intValue];
                if (m0==m2&&m0==m) {
                    [rightmp setObject:buttonM forKey:[NSString stringWithFormat:@"%d%d",i-1,j-1]];
                }
            }
            if (j>1&&i>2) {
                CustomButton*buttonM0=self.dataArray[i][j];
                CustomButton*buttonM2=self.dataArray[i-2][j];
                CustomButton*buttonM=self.dataArray[i-1][j-1];
                int m=[buttonM.titleLabel.text intValue];
                int m0=[buttonM0.titleLabel.text intValue];
                int m2=[buttonM2.titleLabel.text intValue];
                if (m0==m2&&m0==m) {
                    [uptmp setObject:buttonM forKey:[NSString stringWithFormat:@"%d%d",i-1,j-1]];
                }
            }
            //            横向的6种消除
            if (i<7) {
                CustomButton*button=self.dataArray[i][j];
                CustomButton*button1=self.dataArray[i+1][j];
                int m=[button.titleLabel.text intValue];
                int m1=[button1.titleLabel.text intValue];
                if (m==m1) {
                    //动点在右侧的三种移动
                    if (i<5) {
                        CustomButton*button2=self.dataArray[i+3][j];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [leftmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i+3,j]];
                        }
                        
                    }
                    if (j<7&&i<6) {
                        CustomButton*button2=self.dataArray[i+2][j+1];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [downtmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i+2,j+1]];
                        }
                    }
                    if (j>0&&i<6) {
                        CustomButton*button2=self.dataArray[i+2][j-1];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [uptmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i+2,j-1]];
                        }
                    }
                    //                    动点在左侧的三种移动
                    if (i>1) {
                        CustomButton*button2=self.dataArray[i-2][j];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [rightmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i-2,j]];
                        }
                        
                    }
                    if (j<7&&i>0) {
                        CustomButton*button2=self.dataArray[i-1][j+1];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [downtmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i-1,j+1]];
                        }
                    }
                    if (j>0&&i>0) {
                        CustomButton*button2=self.dataArray[i-1][j-1];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [uptmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i-1,j-1]];
                        }
                    }
                    
                }
            }
            //        纵向的6种移动
            if (j<7) {
                CustomButton*button=self.dataArray[i][j];
                CustomButton*button1=self.dataArray[i][j+1];
                int m=[button.titleLabel.text intValue];
                int m1=[button1.titleLabel.text intValue];
                if (m==m1) {
                    //动点在上侧的三种移动
                    if (j<5) {
                        CustomButton*button2=self.dataArray[i][j+3];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [downtmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i,j+3]];
                        }
                        
                    }
                    if (i<7&&j<6) {
                        CustomButton*button2=self.dataArray[i+1][j+2];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [leftmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i+1,j+2]];
                        }
                    }
                    if (i>0&&j<6) {
                        CustomButton*button2=self.dataArray[i-1][j+2];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [rightmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i-1,j+2]];
                        }
                    }
                    //                    动点在下侧的三种移动
                    if (j>1) {
                        CustomButton*button2=self.dataArray[i][j-2];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [uptmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i,j-2]];
                        }
                        
                    }
                    if (i<7&&j>0) {
                        CustomButton*button2=self.dataArray[i+1][j-1];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [leftmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i+1,j-1]];
                        }
                    }
                    if (j>0&&i>0) {
                        CustomButton*button2=self.dataArray[i-1][j-1];
                        int m2=[button2.titleLabel.text intValue];
                        if (m==m2) {
                            [rightmp setObject:button2 forKey:[NSString stringWithFormat:@"%d%d",i-1,j-1]];
                        }
                    }
                    
                }
            }
            
            
        }
    }
    //    for (int i=0; i<7; i++) {
    //        for (int j=0; j<7; j++) {
    //            UIButton*button=self.dataArray[i][j];
    //
    //            if (j<6) {
    //
    //                UIButton*buttonj1=self.dataArray[i+1][j+1];
    //                UIButton*buttonj2=self.dataArray[i+1][j+2];
    //
    //
    //                if ([button.titleLabel.text intValue]==[buttonj1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttonj2.titleLabel.text intValue]) {
    //                    //                [temp addObjectsFromArray:@[self.dataArray[i][j],self.dataArray[i][j+1],self.dataArray[i][j+2]]];
    //                    [rightmp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
    ////                    [temp setObject:self.dataArray[i+1][j+1] forKey:[NSString stringWithFormat:@"%d%d",i+1,j+1]];
    ////                    [temp setObject:self.dataArray[i+1][j+2] forKey:[NSString stringWithFormat:@"%d%d",i+1,j+2]];
    //                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i][j+1] title]intValue],[[self.dataArray[i][j+2] title]intValue]);
    //                }
    //            }
    //            if (i<6) {
    //
    //                UIButton*buttoni1=self.dataArray[i+1][j+1];
    //                UIButton*buttoni2=self.dataArray[i+2][j+1];
    //                if ([button.titleLabel.text intValue]==[buttoni1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttoni2.titleLabel.text intValue]) {
    //                    [uptmp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
    ////                    [temp setObject:self.dataArray[i+1][j+1] forKey:[NSString stringWithFormat:@"%d%d",i+1,j+1]];
    ////                    [temp setObject:self.dataArray[i+2][j+1] forKey:[NSString stringWithFormat:@"%d%d",i+2,j+1]];
    //                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i+1][j] title]intValue],[[self.dataArray[i+2][j] title]intValue]);
    //                }
    //            }
    //
    //        }
    //    }
    //
    //    for (int i=7; i>=0; i--) {
    //        for (int j=7; j>=0; j--) {
    //            UIButton*button=self.dataArray[i][j];
    //
    //            if (j>2) {
    //
    //                UIButton*buttonj1=self.dataArray[i][j-2];
    //                UIButton*buttonj2=self.dataArray[i][j-3];
    //
    //
    //                if ([button.titleLabel.text intValue]==[buttonj1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttonj2.titleLabel.text intValue]) {
    //                    //                [temp addObjectsFromArray:@[self.dataArray[i][j],self.dataArray[i][j+1],self.dataArray[i][j+2]]];
    //                    [downtmp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
    ////                    [temp setObject:self.dataArray[i][j-2] forKey:[NSString stringWithFormat:@"%d%d",i,j-2]];
    ////                    [temp setObject:self.dataArray[i][j-3] forKey:[NSString stringWithFormat:@"%d%d",i,j-3]];
    //                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i][j+1] title]intValue],[[self.dataArray[i][j+2] title]intValue]);
    //                }}
    //            if (i>2) {
    //
    //                UIButton*buttoni1=self.dataArray[i-2][j];
    //                UIButton*buttoni2=self.dataArray[i-3][j];
    //                if ([button.titleLabel.text intValue]==[buttoni1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttoni2.titleLabel.text intValue]) {
    //                    [leftmp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
    ////                    [temp setObject:self.dataArray[i-2][j] forKey:[NSString stringWithFormat:@"%d%d",i-2,j]];
    ////                    [temp setObject:self.dataArray[i-3][j] forKey:[NSString stringWithFormat:@"%d%d",i-3,j]];
    //                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i+1][j] title]intValue],[[self.dataArray[i+2][j] title]intValue]);
    //                }
    //            }
    //
    //        }
    //    }
    //    for (int i=7; i>0; i--) {
    //        for (int j=7; j>0; j--) {
    //            UIButton*button=self.dataArray[i][j];
    //
    //            if (j>1) {
    //
    //                UIButton*buttonj1=self.dataArray[i-1][j-1];
    //                UIButton*buttonj2=self.dataArray[i-1][j-2];
    //
    //
    //                if ([button.titleLabel.text intValue]==[buttonj1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttonj2.titleLabel.text intValue]) {
    //                    //                [temp addObjectsFromArray:@[self.dataArray[i][j],self.dataArray[i][j+1],self.dataArray[i][j+2]]];
    //                    [leftmp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
    ////                    [temp setObject:self.dataArray[i-1][j-1] forKey:[NSString stringWithFormat:@"%d%d",i-1,j-1]];
    ////                    [temp setObject:self.dataArray[i-1][j-2] forKey:[NSString stringWithFormat:@"%d%d",i-1,j-2]];
    //                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i][j+1] title]intValue],[[self.dataArray[i][j+2] title]intValue]);
    //                }}
    //            if (i>1) {
    //
    //                UIButton*buttoni1=self.dataArray[i-1][j-1];
    //                UIButton*buttoni2=self.dataArray[i-2][j-1];
    //                if ([button.titleLabel.text intValue]==[buttoni1.titleLabel.text intValue]&&[button.titleLabel.text intValue]==[buttoni2.titleLabel.text intValue]) {
    //                    [downtmp setObject:self.dataArray[i][j] forKey:[NSString stringWithFormat:@"%d%d",i,j]];
    ////                    [temp setObject:self.dataArray[i-1][j-1] forKey:[NSString stringWithFormat:@"%d%d",i-1,j-1]];
    ////                    [temp setObject:self.dataArray[i-2][j-1] forKey:[NSString stringWithFormat:@"%d%d",i-2,j-1]];
    //                    //                NSLog(@"%@,%d,%d",[self.dataArray[i][j] title],[[self.dataArray[i+1][j] title]intValue],[[self.dataArray[i+2][j] title]intValue]);
    //                }
    //            }
    //
    //        }
    //    }
    
    
    NSLog(@"left:%@ right:%@ up:%@ down:%@",[leftmp allKeys],[rightmp allKeys],[uptmp allKeys],[downtmp allKeys]);
    NSLog(@"还有可消除food %d组",leftmp.count+rightmp.count+uptmp.count+downtmp.count);
    int c=leftmp.count+rightmp.count+uptmp.count+downtmp.count;
    if (c==0) {
        
        for (int i=0; i<8; i++) {
            for (int j=0; j<8; j++) {
                [self.dataArray[i][j] removeFromSuperview];
            }
            [self.dataArray[i] removeAllObjects];
        }
        [self createMatrix];
    }
    if (flag<0&&c>0) {
        if (leftmp.count) {
            int xy=[[[leftmp allKeys]lastObject]intValue];
            [self AImove:xy/10 :xy%10 :xy/10-1 :xy%10];
            return;
        }
        if (rightmp.count) {
            int xy=[[[rightmp allKeys]lastObject]intValue];
            [self AImove:xy/10 :xy%10 :xy/10+1 :xy%10];
            return;
        }
        if (uptmp.count) {
            int xy=[[[uptmp allKeys]lastObject]intValue];
            [self AImove:xy/10 :xy%10 :xy/10 :xy%10+1];
            return;
        }
        if (downtmp.count) {
            int xy=[[[downtmp allKeys]lastObject]intValue];
            [self AImove:xy/10 :xy%10 :xy/10 :xy%10-1];
            return;
        }
    }
}

- (void)AImove:(int)x :(int)y :(int)x11 :(int)y11{
    _tempButton=self.dataArray[x][y];
    [_tempButton flashon];
    CustomButton*button=self.dataArray[x11][y11];
    [self performSelector:@selector(buttonMove:) withObject:button afterDelay:1];
    //    [self buttonMove:button];
    
}


#pragma mark 点击foods时调用该函数进行判断
- (void)buttonMove:(CustomButton*)button{
    [self playShort2];
    NSLog(@"%d",button.tag);
    if (_tempButton==nil) {
        [button flashon];
        _tempButton=button;
        
        //        _tempButton.frame=CGRectMake(_tempButton.frame.origin.x, _tempButton.frame.origin.y, 40, 40);
    }else{
        if (_tempButton==button) {
            [_tempButton flashoff];
            _tempButton=nil;
            return;
        }
        [self buttonOff];
        if ([self crossButton:button]) {
            
            //            sleep(1000);
            [self performSelector:@selector(crushButton:) withObject:button afterDelay:.5];
            
        }else {
            [self buttonOn];
        }
        
    }
}
#pragma mark 关闭全部foodbutton交互权限
- (void)buttonOff{
    for (int i=0;i<8 ;i++) {
        for (int j=0; j<8; j++) {
            CustomButton*button=self.dataArray[i][j];
            button.userInteractionEnabled=NO;
        }
    }
}

#pragma mark 打开全部foodbutton交互权限
- (void)buttonOn{
    for (int i=0;i<8 ;i++) {
        for (int j=0; j<8; j++) {
            CustomButton*button=self.dataArray[i][j];
            button.userInteractionEnabled=YES;
        }
    }
}

#pragma mark 交换2个按钮的位置
- (BOOL)crossButton:(CustomButton*)button{
    int x=button.frame.origin.x/39;
    int y=8-button.frame.origin.y/39;
    int tempx=_tempButton.frame.origin.x/39;
    int tempy=8-_tempButton.frame.origin.y/39;
    if (x==tempx&&fabs(tempy-y)==1) {
        [self.dataArray[x] exchangeObjectAtIndex:y withObjectAtIndex:tempy];
        [UIView animateWithDuration:.5 animations:^{
            CGRect cache= _tempButton.frame;
            _tempButton.frame=button.frame;
            button.frame=cache;
        }];
        return YES;
    }
    else if (y==tempy&&fabs(x-tempx)==1) {
        [self.dataArray[x] insertObject:_tempButton atIndex:y];
        [self.dataArray[tempx] insertObject:button atIndex:tempy];
        [self.dataArray[x] removeObjectAtIndex:y+1];
        [self.dataArray[tempx] removeObjectAtIndex:tempy+1];
        [UIView animateWithDuration:.5 animations:^{
            CGRect cache= _tempButton.frame;
            _tempButton.frame=button.frame;
            button.frame=cache;
        }];
        return YES;
    }
    [_tempButton flashoff];
    _tempButton=button;
    [_tempButton flashon];
    return NO;
}

- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden=YES;
}

- (void)viewDidDisappear:(BOOL)animated{
    [_player stop];
    _player =nil;
    [_playTimer setFireDate:[NSDate distantFuture]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)creatBoom{
    CGRect viewBounds = bgView.layer.bounds;
	
	// Create the emitter layer
	self.ringEmitter = [CAEmitterLayer layer];
	
	// Cells spawn in a 50pt circle around the position
	self.ringEmitter.emitterPosition = CGPointMake(viewBounds.size.width/8.0, viewBounds.size.height/8.0);
	self.ringEmitter.emitterSize	= CGSizeMake(10, 0);
	self.ringEmitter.emitterMode	= kCAEmitterLayerOutline;
	self.ringEmitter.emitterShape	= kCAEmitterLayerCircle;
	self.ringEmitter.renderMode		= kCAEmitterLayerBackToFront;
    
    //	// Create the fire emitter cell
	CAEmitterCell* ring = [CAEmitterCell emitterCell];
	[ring setName:@"ring"];
	
	ring.birthRate			= 0;
	ring.velocity			= 250;
	ring.scale				= 0.5;
	ring.scaleSpeed			=-0.2;
	ring.greenSpeed			=-0.2;	// shifting to green
	ring.redSpeed			=-0.5;
	ring.blueSpeed			=-0.5;
	ring.lifetime			= 1;
	
	ring.color = [[UIColor whiteColor] CGColor];
	ring.contents = (id) [[UIImage imageNamed:@""] CGImage];
	
    
	CAEmitterCell* circle = [CAEmitterCell emitterCell];
	[circle setName:@"circle"];
	
	circle.birthRate		= 10;			// every triangle creates 20
	circle.emissionLongitude = M_PI * 0.5;	// sideways to triangle vector
	circle.velocity			= 50;
	circle.scale			= 0.5;
	circle.scaleSpeed		=-0.2;
	circle.greenSpeed		=-0.1;	// shifting to blue
	circle.redSpeed			=0.5;
	circle.blueSpeed		= 0.1;
	circle.alphaSpeed		=-0.2;
	circle.lifetime			= .5;
	
	circle.color = [[UIColor whiteColor] CGColor];
	circle.contents = (id) [[UIImage imageNamed:@"DazRing"] CGImage];
    
    
	CAEmitterCell* star = [CAEmitterCell emitterCell];
	[star setName:@"star"];
	
	star.birthRate		= 10;	// every triangle creates 20
	star.velocity		= 100;
	star.zAcceleration  = -1;
	star.emissionLongitude = -M_PI;	// back from triangle vector
	star.scale			= 0.5;
	star.scaleSpeed		=-0.2;
	star.greenSpeed		=-0.1;
	star.redSpeed		= 0.4;	// shifting to red
	star.blueSpeed		=-0.1;
	star.alphaSpeed		=-0.2;
	star.lifetime		= .3;
	
	star.color = [[UIColor whiteColor] CGColor];
	star.contents = (id) [[UIImage imageNamed:@"DazStarOutline"] CGImage];
	
	// First traigles are emitted, which then spawn circles and star along their path
	self.ringEmitter.emitterCells = [NSArray arrayWithObject:ring];
	ring.emitterCells = [NSArray arrayWithObjects:circle, star, nil];
	//	circle.emitterCells = [NSArray arrayWithObject:star];	// this is SLOW!
	[bgView.layer addSublayer:self.ringEmitter];
    //    [self touchAtPosition:CGPointMake(100, 100)];
}


- (void) viewWillUnload
{
	[super viewWillUnload];
	[self.ringEmitter removeFromSuperlayer];
	self.ringEmitter = nil;
}


- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


// ---------------------------------------------------------------------------------------------------------------
#pragma mark -
#pragma mark Interaction
// ---------------------------------------------------------------------------------------------------------------

//- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//	UITouch *touch = [[event allTouches] anyObject];
//	CGPoint touchPoint = [touch locationInView:self.view];
//	[self touchAtPosition:touchPoint];
//}


//- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
//{
//	UITouch *touch = [[event allTouches] anyObject];
//	CGPoint touchPoint = [touch locationInView:self.view];
//	[self touchAtPosition:touchPoint];
//}


- (void) touchAtPosition:(CGPoint)position
{
	// Bling bling..
	CABasicAnimation *burst = [CABasicAnimation animationWithKeyPath:@"emitterCells.ring.birthRate"];
	burst.fromValue			= [NSNumber numberWithFloat: 125.0];	// short but intense burst
	burst.toValue			= [NSNumber numberWithFloat: 0.0];		// each birth creates 20 aditional cells!
	burst.duration			= 0.5;
	burst.timingFunction	= [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
	
	[self.ringEmitter addAnimation:burst forKey:@"burst"];
    
	// Move to touch point
	[CATransaction begin];
	[CATransaction setDisableActions: YES];
	self.ringEmitter.emitterPosition	= position;
	[CATransaction commit];
}


- (void)playM{
    if (_player!=nil) {
        _player=nil;
    }
    
    _player=[[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"26" ofType:@"mp3"]] error:nil];
    
    
    //    _player=[[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"task_f" ofType:@"ogg"]] error:nil];
    
    // NSString*path=[[NSBundle mainBundle]pathForResource:@"像梦一样自由" ofType:@"mp3"];
    //    NSURL*url=[NSURL fileURLWithPath:path];
    //    _player=[[AVAudioPlayer alloc]initWithContentsOfURL:url error:nil];
    //    //进行缓冲播放
    [_player prepareToPlay];
    //    //进行播放
    [_player play];
    //    [self performSelector:@selector(playM) withObject:self afterDelay:75];
    //    [self performSelector:@selector(playM) withObject:self afterDelay:65];
}

- (void)playShort{
    NSString*path=[[NSBundle mainBundle]pathForResource:@"dis" ofType:@"wav"];
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((CFURLRef)CFBridgingRetain([NSURL fileURLWithPath:path]), &soundID);
    //需要进行播放
    AudioServicesPlaySystemSound(soundID);
    
    //短期震动
    //    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
    
}

- (void)playShort2{
    NSString*path=[[NSBundle mainBundle]pathForResource:@"3887" ofType:@"wav"];
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((CFURLRef)CFBridgingRetain([NSURL fileURLWithPath:path]), &soundID);
    //需要进行播放
    AudioServicesPlaySystemSound(soundID);
    
    //短期震动
    //    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
    
}

- (void)playWin{
    NSString*path=[[NSBundle mainBundle]pathForResource:@"task_v" ofType:@"wav"];
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((CFURLRef)CFBridgingRetain([NSURL fileURLWithPath:path]), &soundID);
    //需要进行播放
    AudioServicesPlaySystemSound(soundID);
    
    //短期震动
    //    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
    
}

- (void)finished:(BOOL)isWin{
    
    [_player stop];
    _player =nil;
    [_playTimer setFireDate:[NSDate distantFuture]];
    
    if (isWin) {
        [self playWin];
        [self saveMisson];
    }else [self playLost];
    
    [self createWinView:isWin];
}


- (void)playLost{
    NSString*path=[[NSBundle mainBundle]pathForResource:@"task_f" ofType:@"wav"];
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((CFURLRef)CFBridgingRetain([NSURL fileURLWithPath:path]), &soundID);
    //需要进行播放
    AudioServicesPlaySystemSound(soundID);
    
    //短期震动
    //    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
    
}

- (void)saveMisson{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults setObject:@"1" forKey:[NSString stringWithFormat:@"d%d",self.mission]];
    [defaults synchronize];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
