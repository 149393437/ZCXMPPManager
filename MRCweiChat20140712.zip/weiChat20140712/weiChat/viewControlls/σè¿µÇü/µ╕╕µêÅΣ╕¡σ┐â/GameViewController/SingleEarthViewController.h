//
//  SingleEarthViewController.h
//  Crush
//
//  Created by qianfeng on 14-7-7.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "PlayViewController.h"

@interface SingleEarthViewController : PlayViewController
{
    int p1e;
}
@end
