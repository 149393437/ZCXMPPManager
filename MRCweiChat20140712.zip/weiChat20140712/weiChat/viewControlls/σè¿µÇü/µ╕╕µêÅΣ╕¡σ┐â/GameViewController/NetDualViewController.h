//
//  NetDualViewController.h
//  Crush
//
//  Created by Jinpeng on 14-7-2.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NetDualViewController : UIViewController
{
    UIImageView* bg;
}
@property (nonatomic) BOOL isDuel;

@end
