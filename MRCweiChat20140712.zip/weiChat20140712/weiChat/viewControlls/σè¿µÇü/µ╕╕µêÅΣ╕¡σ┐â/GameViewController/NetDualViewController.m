//
//  NetDualViewController.m
//  Crush
//
//  Created by Jinpeng on 14-7-2.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "NetDualViewController.h"
#import "DuelEarthViewController.h"
#import "SingleEarthViewController.h"
@interface NetDualViewController ()

@end

@implementation NetDualViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    [self createBG];
//    self.navigationController.navigationBar.translucent=NO;
//    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"ti.png"] forBarMetrics:UIBarMetricsDefault];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;
}
- (void)createBG{
    NSArray*arr=@[@"单人抢盘",@"电脑对战"];
   bg=[JPMyControl createImageViewWithFrame:self.view.frame ImageName:@"b5.jpg"];
    [self.view addSubview:bg];
    for (int i=0; i<2; i++) {
        UIButton*button=[JPMyControl createButtonWithFrame:CGRectMake(100, i*100+50, 120, 40) Target:self SEL:@selector(buttonClick:) Title:arr[i] ImageName:@"" bgImage:@"stonelong4" Tag:300+i];
        [bg addSubview:button];
    }
    
}

- (void)buttonClick:(UIButton*)button{
    if (button.tag==300) {
        SingleEarthViewController*vc=[SingleEarthViewController new];
        vc.hidesBottomBarWhenPushed=YES;
//        vc.mission=10;
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (button.tag==301) {
        DuelEarthViewController*vc=[DuelEarthViewController new];
        vc.hidesBottomBarWhenPushed=YES;
//        vc.mission=10;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
