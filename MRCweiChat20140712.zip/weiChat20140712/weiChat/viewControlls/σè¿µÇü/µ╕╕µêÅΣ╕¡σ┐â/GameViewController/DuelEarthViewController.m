//
//  DuelEarthViewController.m
//  Crush
//
//  Created by Jinpeng on 14-7-7.
//  Copyright (c) 2014年 金鹏. All rights reserved.
//

#import "DuelEarthViewController.h"

@interface DuelEarthViewController ()

@end

@implementation DuelEarthViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        p1e=0;
        p2e=0;
        // Custom initialization
    }
    return self;
}

- (void)doEarth:(NSString*)key{
    place1.hidden=NO;
    place2.hidden=NO;
    NSString*str=key;
    int a=[str intValue];
    for (id key in self.Matrix) {
        if ([key intValue]==a) {
            return;
        }
    }
    if (zflag==YES) {
        return;
    }
    int x=a/10;
    int y=a%10;
    UIView*view=self.xdataArray[x][y];
    if (flag>0) {
        [self.Matrix setObject:@"1" forKey:key];
        view.backgroundColor=[UIColor orangeColor];
        p1e++;
        place1.text=[NSString stringWithFormat:@"盘子:%d/29",p1e];
    }
    if (flag<0) {
        [self.Matrix setObject:@"2" forKey:key];
        view.backgroundColor=[UIColor colorWithRed:.3 green:0.1 blue:.6 alpha:1];
        p2e++;
        place2.text=[NSString stringWithFormat:@"盘子:%d/28",p2e];
    }
    
}

- (BOOL)isWin:(int)a{
    if (flag>0) {
        if (p1e-1>=28) {
            //            [self finished:YES];
            self.rounds=0;
            return YES;
        }
    }
    if (flag<0) {
        if (p2e>=28) {
            //            [self finished:NO];
            self.rounds=10000;
            return YES;
        }
    }
    return NO;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
