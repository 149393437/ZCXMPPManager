#define KINDS 6;
#define MAINPAGEBG @"tbg.jpg"
#define DUELSELECTMBG @""
#define SINGLESELECTMBG @""
#define DUELBG @""
#define SINGLEBG @""
#define HELPBG @""
#define ABOUTUSBG @""

//主菜单按钮名称
#define BUTTONSTITLE @[@"单人游戏",@"电脑对战",@"小游戏",@"帮 助",@"关于我们"]
//主菜单按钮图片
#define BUTTONSBG @[@"shortwood1",@"shortwood2",@"shortwood3",@"shortwood2",@"shortwood1"];

//tabBar 未点选 图片组
#define UNSELECT @[@"a",@"b",@"c",@"d",@"e"]
#define SELECT @[@"aa",@"bb",@"cc",@"dd",@"ee"]

//菜谱
#define COOK @[@"1234",@"2345",@"3456",@"0123",@"4567",@"5678",@"6789",@"2257",@"3348",@"4444"];

//成菜图片
#define COOKIMA @[@"11.png",@"22.png",@"33.png",@"44.png",@"55.png",@"66.png",@"77.png",@"88.png",@"99.png",@"00.png"];

#import "JPMyControl.h"



