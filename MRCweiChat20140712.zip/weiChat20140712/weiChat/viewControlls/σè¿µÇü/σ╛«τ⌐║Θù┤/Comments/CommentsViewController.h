//
//  CommentsViewController.h
//  UI_1
//
//  Created by yu on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommentsViewController : UIViewController

@property (nonatomic, copy) NSString *commentsUrl;

@end
