//
//  CommentData.h
//  UI_1
//
//  Created by yu on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 "author_avatar" : "http://tp1.sinaimg.cn/3428758500/180/5665040805/1",
 "author_name" : "爱钓鱼的天天",
 "cid" : "221346",
 "content" : "应该是塞住她的嘴吧？",
 "created_time" : "1402330384",
 "dislikes" : "0",
 "is_exported" : "0",
 "likes" : "1"
 
 "author_avatar" : "http://tp3.sinaimg.cn/2200103602/180/5646807283/1",
 "author_name" : "八九悲劇一代",
 "cid" : "549508",
 "content" : "番号BBI-148，请赞好吗？",
 "created_time" : "1402319552",
 "dislikes" : "0",
 "is_exported" : "0",
 "likes" : "141"
 */

@interface CommentData : NSObject

@property (nonatomic, copy) NSString *author_avatar;
@property (nonatomic, copy) NSString *author_name;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *created_time;
@property (nonatomic, copy) NSString *likes;

@end
