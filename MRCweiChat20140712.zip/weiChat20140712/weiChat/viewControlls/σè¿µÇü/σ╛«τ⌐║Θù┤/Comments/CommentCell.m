//
//  CommentCell.m
//  UI_1
//
//  Created by yu on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "CommentCell.h"

@implementation CommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_imageview release];
    [_userLabel release];
    [_timeLabel release];
    [_contentLabel release];
    [_zanButton release];
    [super dealloc];
}
@end
