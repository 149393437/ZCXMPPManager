//
//  CommentsViewController.m
//  UI_1
//
//  Created by yu on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "CommentsViewController.h"
#import "CommentData.h"
#import "CommentCell.h"
#import "UIImageView+WebCache.h"

@interface CommentsViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *_tableView;
    NSMutableArray *_dataArray;
}

@end

@implementation CommentsViewController

- (void)dealloc
{
    self.commentsUrl = nil;
    [_tableView release], _tableView = nil;
    [_dataArray release], _dataArray = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)createTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 480) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    _dataArray = [[NSMutableArray alloc] init];
}

- (void)createHttpConnection
{
//    _httpConnection = [[QFHttpRequest alloc] init];
//    _httpConnection.delegate = self;
//    // 根据传过来的网址，下载评论
//    [_httpConnection downloadFromUrl:_commentsUrl];
    [[HttpDownLoadBlock alloc]initWithUrlStr:_commentsUrl setBlock:^(HttpDownLoadBlock *http, BOOL isFinish) {
        [self jsonValue:http];
    }];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self createTableView];
    [self createHttpConnection];
}
#pragma mark 父类解析结果重写
-(void)jsonValue:(HttpDownLoadBlock*)http{
    if (http.dataDict) {
        NSArray *array = [http.dataDict objectForKey:@"items"];
        for (NSDictionary *subDict in array) {
            CommentData *item = [[CommentData alloc] init];
            [item setValuesForKeysWithDictionary:subDict];
            [_dataArray addObject:item];
            [item release];
        }
        [_tableView reloadData];
    }


}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userCell = @"commentsCell";
    CommentCell *cell = [tableView dequeueReusableCellWithIdentifier:userCell];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CommentCell" owner:self options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    CommentData *item = [_dataArray objectAtIndex:indexPath.row];
    [cell.imageview setImageWithURL:[NSURL URLWithString:item.author_avatar] placeholderImage:[UIImage imageNamed:@"watermark template@2x.png"]];
    cell.imageview.layer.masksToBounds = YES;
    cell.imageview.layer.cornerRadius = 20;
    cell.userLabel.text = item.author_name;
    cell.timeLabel.text = [ZCControl stringDateWithTimeInterval:item.created_time];
    [cell.zanButton setTitle:[NSString stringWithFormat:@"赞:%d",[item.likes integerValue]] forState:UIControlStateNormal];
    cell.contentLabel.text = item.content;
    cell.contentLabel.numberOfLines = 0;
    cell.contentLabel.lineBreakMode = NSLineBreakByWordWrapping;
    CGRect frame = cell.contentLabel.frame;
    frame.size.height = [ZCControl textHeightWithString:item.content width:280 fontSize:14];
    cell.contentLabel.frame = frame;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentData *item = [_dataArray objectAtIndex:indexPath.row];
    CGFloat height = 53 + [ZCControl textHeightWithString:item.content width:280 fontSize:14];
    return height+5;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
