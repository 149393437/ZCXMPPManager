//
//  CommentData.m
//  UI_1
//
//  Created by yu on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "CommentData.h"

@implementation CommentData

- (void)dealloc
{
    self.author_avatar = nil;
    self.author_name = nil;
    self.content = nil;
    self.created_time = nil;
    self.likes = nil;
    [super dealloc];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
@end
