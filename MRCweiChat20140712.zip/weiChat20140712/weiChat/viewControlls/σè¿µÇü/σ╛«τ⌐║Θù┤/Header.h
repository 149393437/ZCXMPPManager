// 段子 趣图 视频 美女 接口
#define CONTENTS_URL @"http://223.6.252.214/weibofun/weibo_list.php?apiver=10500&category=%@&page=%d&page_size=%d&max_timestamp=%@"
// 页面从第0页开始30条开始，然后是第1页15条，第2页15条...
// max_timestamp 第0页，或者下拉刷新，值为-1，否则，为最后一个条目的update_time字段的值!(特别注意)

// category对应的字符串为:
#define JOKES @"weibo_jokes"  // 段子
#define PICS @"weibo_pics"    // 趣图
#define VIDEOS @"weibo_videos"// 视频
#define GIRLS @"weibo_girls"  // 美女

// 评论接口
// fid为对应的wid，category同上
#define COMMENTS_URL @"http://223.6.252.214/weibofun/comments_list.php?apiver=10600&fid=%d&&category=%@&page=0&page_size=15&max_timestamp=-1"

// 点赞接口，post请求
// fid为对应的wid，category同上
#define ZAN_URL @"http://223.6.252.214/weibofun/add_count.php?apiver=10500"
// type=like&category=weibo_girls&fid=30310


