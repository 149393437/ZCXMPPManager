//
//  JokesViewController.m
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "JokesViewController.h"
#import "JokeData.h"
#import "JokeCell.h"

@interface JokesViewController ()

@end

@implementation JokesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
#pragma mark 父类解析结果重写
-(void)jsonValue:(HttpDownLoadBlock*)http
{
//    // 如果是点赞请求，不要下载的数据，直接更改请求类型
//    // request.requestType,实际为wid值
//    if (request.requestType) {
//        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
//        [ud setObject:@"YES" forKey:[NSString stringWithFormat:@"%d",request.requestType]];
//        [ud synchronize];
//        request.requestType = 0;
//        return;
//    }
    
    if (http.dataDict) {
        if (_currentPage == 0) {
            [_dataArray removeAllObjects];
        }
        
        // 更新总页数
        NSInteger totalCount = [[http.dataDict objectForKey:@"total"] integerValue];
        _totalPage = (totalCount-30)/15+(totalCount-30)%15!=0;
        
        NSArray *array = [http.dataDict objectForKey:@"items"];
        for (NSDictionary *subDict in array) {
            // 解析!
            JokeData *item = [[JokeData alloc] init];
            [item setValuesForKeysWithDictionary:subDict];
            [_dataArray addObject:item];
            [item release];
        }
        // 更新最后一条信息的更新时间，构建上拉加载网址的时候用
        self.max_timestamp = [[array lastObject] objectForKey:@"update_time"];
        // 通知结束刷新
        [self endRefresh];
        [_tableView reloadData];
    }

}

// 重写tableView的协议方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userCell = @"jokesCell";
    JokeCell *cell = [tableView dequeueReusableCellWithIdentifier:userCell];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"JokeCell" owner:self options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    // 布局
    // 设置日期
    JokeData *item = [_dataArray objectAtIndex:indexPath   .row];
    cell.timeLabel.text = [ZCControl stringDateWithTimeInterval:item.update_time];
    // 设置文本内容
    cell.contentLabel.numberOfLines = 0;
    cell.contentLabel.lineBreakMode = NSLineBreakByCharWrapping;
    cell.contentLabel.text = item.wbody;
    CGRect frame = cell.contentLabel.frame;
    frame.size.height = [ZCControl textHeightWithString:item.wbody width:280 fontSize:14];
    cell.contentLabel.frame = frame;
    // 设置按钮的位置及内容
    CGRect likeFrame = cell.zanButton.frame;
    likeFrame.origin.y = cell.contentLabel.frame.origin.y + cell.contentLabel.frame.size.height+5;
    cell.zanButton.frame = likeFrame;
    // cell.zanButton.tag = [item.likes integerValue];
    cell.zanButton.tag = indexPath.row;
    [cell.zanButton setTitle:[NSString stringWithFormat:@"赞:%d",[item.likes integerValue]] forState:UIControlStateNormal];
    // 如果能找到item.wid的key对应的值，则说明，已经点过赞了!
    if ([[NSUserDefaults standardUserDefaults] objectForKey:item.wid]) {
        cell.zanButton.enabled = NO;
    } else {
        cell.zanButton.enabled = YES;
    }
    [cell.zanButton addTarget:self action:@selector(zanButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    // 设置评论按钮的位置及内容
    CGRect commentsFrame = cell.commentsButton.frame;
    commentsFrame.origin.y = likeFrame.origin.y;
    cell.commentsButton.frame = commentsFrame;
    cell.commentsButton.tag = [item.wid integerValue];
    [cell.commentsButton setTitle:[NSString stringWithFormat:@"评:%d",[item.comments integerValue]] forState:UIControlStateNormal];
    [cell.commentsButton addTarget:self action:@selector(commentsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

// 从网络抓包来看，从服务器下载的数据没有因点赞而有所区别，估计应用程序也是用代码来控制是否点赞，这里，我们用NSUserDefaults来记录。
- (void)zanButtonClick:(UIButton *)button
{
    JokeData *item = [_dataArray objectAtIndex:button.tag];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:item.wid]) {
        // MMProgress
    } else {
        item.likes = [ZCControl addOneByIntegerString:item.likes];
        [button setTitle:[NSString stringWithFormat:@"赞:%@",item.likes] forState:UIControlStateNormal];
        button.enabled = NO;
        // 通知服务器，点赞了
        [self changeLikesWithFid:item.wid];
    }
}

- (void)commentsButtonClick:(UIButton *)button
{
    [self pushCommentsViewControllerWithClickedButton:button];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JokeData *item = [_dataArray objectAtIndex:indexPath.row];
    CGFloat height = 34.0f;
    height += [ZCControl textHeightWithString:item.wbody width:280 fontSize:14];
    height += 30+5+5;
    return height;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
