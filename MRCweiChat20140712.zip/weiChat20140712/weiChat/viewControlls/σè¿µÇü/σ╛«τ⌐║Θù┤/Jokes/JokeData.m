//
//  JokeData.m
//  UI_1
//
//  Created by apple on 14-6-9.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "JokeData.h"

@implementation JokeData

- (void)dealloc
{
    self.comments = nil;
    self.wid = nil;
    self.update_time = nil;
    self.likes = nil;
    self.wbody = nil;
    [super dealloc];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
@end
