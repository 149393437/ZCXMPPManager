//
//  JokeCell.h
//  UI_1
//
//  Created by apple on 14-6-9.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JokeCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UILabel *timeLabel;
@property (retain, nonatomic) IBOutlet UILabel *contentLabel;
@property (retain, nonatomic) IBOutlet UIButton *zanButton;
@property (retain, nonatomic) IBOutlet UIButton *commentsButton;

@end
