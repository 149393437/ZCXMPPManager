//
//  CommonViewController.m
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "CommonViewController.h"
#import "MJRefresh.h"
#import "CommentsViewController.h"

@interface CommonViewController () <MJRefreshBaseViewDelegate> {
    // 上拉加载和下拉刷新
    MJRefreshHeaderView *_headerView;
    MJRefreshFooterView *_footerView;
}

@end

@implementation CommonViewController

- (void)dealloc
{
    [_tableView release], _tableView = nil;
    [_dataArray release], _dataArray = nil;
    self.categoryType = nil;
    self.max_timestamp = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)createTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    _dataArray = [[NSMutableArray alloc] init];
}

- (void)createRefreshView
{
    _headerView = [MJRefreshHeaderView header];
    _headerView.scrollView = _tableView;
    _headerView.delegate = self;
    
    _footerView = [MJRefreshFooterView footer];
    _footerView.scrollView = _tableView;
    _footerView.delegate = self;
}

- (void)createHttpRequest
{

    // 预设一个总数，下载后更新
    _totalPage = 99999;
    // 从第0页开始,要下载30条数据
    _currentPage = 0;
    // 记录最后一条数据的更新时间，初始值为@"-1"
    self.max_timestamp = @"-1";
    // 创建，就要执行一次下载数据
    [self downloadWithPage:0 count:30];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    // 创建tableView，初始化数据源数组
    [self createTableView];
    // 创建上拉下拉刷新的视图
    [self createRefreshView];
    // 创建下载类对象
    [self createHttpRequest];
}

// 下载数据的方法
- (void)downloadWithPage:(NSInteger)page count:(NSInteger)count
{
    NSString *string = [NSString stringWithFormat:CONTENTS_URL,_categoryType,page,count,_max_timestamp];
    
    [[HttpDownLoadBlock alloc]initWithUrlStr:string setBlock:^(HttpDownLoadBlock *http, BOOL isFinish) {
        [self jsonValue:http];
        [http release];
    }];
    
}
#pragma mark 子类中重载该解析结果
-(void)jsonValue:(HttpDownLoadBlock*)http{

}

#pragma mark - 子类点击评论按钮的时候调用的方法
- (void)pushCommentsViewControllerWithClickedButton:(UIButton *)button
{
    NSString *string = [NSString stringWithFormat:COMMENTS_URL,button.tag,self.categoryType];
    CommentsViewController *vc = [[[CommentsViewController alloc] init] autorelease];
    vc.commentsUrl = string;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 子类点赞按钮的时候调用的方法
- (void)changeLikesWithFid:(NSString *)fid
{
    NSLog(@"点赞未完成");
}

#pragma mark - TableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userCell = @"userCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:userCell];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:userCell] autorelease];
    }
    return cell;
}
#pragma mark - refreshDelegate
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (refreshView == _headerView) {
        _currentPage = 0;
        self.max_timestamp = @"-1";
        [self downloadWithPage:_currentPage count:30];
    } else if (refreshView == _footerView) {
        _currentPage++;
        if (_currentPage > _totalPage) {
            _currentPage = _totalPage;
        }
        [self downloadWithPage:_currentPage count:15];
    }
}
// 结束刷新的方法
- (void)endRefresh
{
    [_headerView endRefreshing];
    [_footerView endRefreshing];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
