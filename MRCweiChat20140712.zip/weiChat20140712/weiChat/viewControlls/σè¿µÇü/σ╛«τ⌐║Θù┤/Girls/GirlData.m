//
//  GirlData.m
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "GirlData.h"

@implementation GirlData

- (void)dealloc
{
    self.comments = nil;
    self.likes = nil;
    self.update_time = nil;
    self.wbody = nil;
    self.wid = nil;
    self.wpic_m_height = nil;
    self.wpic_m_width = nil;
    self.wpic_middle = nil;
    [super dealloc];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
/*
- (CGFloat)wbodyHeight
{
    NSDictionary *dict = @{NSFontAttributeName: [UIFont systemFontOfSize:14]};
    // 根据第一个参数的文本内容，使用280*float最大值的大小，使用系统14号字，返回一个真实的frame size : (280*xxx)!!
    CGRect frame = [self.wbody boundingRectWithSize:CGSizeMake(280, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil];
    return frame.size.height;
}
 */

@end
