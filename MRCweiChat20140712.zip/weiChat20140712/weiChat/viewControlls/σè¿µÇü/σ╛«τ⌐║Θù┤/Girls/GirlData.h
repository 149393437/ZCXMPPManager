//
//  GirlData.h
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

/*
 comments = 1;
 "is_gif" = 0;
 likes = "41.60";
 "update_time" = 1402110000;
 wbody = "\U201c\U4f60\U7c97\U6765\U4e00\U4e0b\Uff0c\U6211\U6709\U4e8b\U60f3\U8ddf\U4f60\U8c08\U8c08\U3002\U201d \U201c\U8c08\U4ec0\U4e48\Uff1f\U201d \U201c\U604b\U7231\U3002\U201d ";
 wid = 30343;
 "wpic_large" = "http://ww3.sinaimg.cn/large/7006593djw1eh3q1i71lfj20lh0w8tc2.jpg";
 "wpic_m_height" = 660;
 "wpic_m_width" = 440;
 "wpic_middle" = "http://ww3.sinaimg.cn/bmiddle/7006593djw1eh3q1i71lfj20lh0w8tc2.jpg";
 */

#import <Foundation/Foundation.h>

@interface GirlData : NSObject
// 评论
@property (nonatomic, copy) NSString *comments;
// 赞
@property (nonatomic, copy) NSString *likes;
// 更新时间
@property (nonatomic, copy) NSString *update_time;
// 文本内容
@property (nonatomic, copy) NSString *wbody;
// id号
@property (nonatomic, copy) NSString *wid;
// 中图的高度
@property (nonatomic, copy) NSString *wpic_m_height;
// 中图的宽度
@property (nonatomic, copy) NSString *wpic_m_width;
// 中图的图片地址
@property (nonatomic, copy) NSString *wpic_middle;

// - (CGFloat)wbodyHeight;

@end
