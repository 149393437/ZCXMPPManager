//
//  CommonViewController.h
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIImageView+WebCache.h"

@interface CommonViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    UITableView *_tableView;
    // 数据源
    NSMutableArray *_dataArray;
    // 当前页
    NSInteger _currentPage;
    // 总页数
    NSInteger _totalPage;
    // 下载类
}

@property (nonatomic, copy) NSString *categoryType;
// 记录最后一条数据的更新时间，对应update_time键的值
// 初始值为@"-1";
@property (nonatomic, copy) NSString *max_timestamp;

- (void)downloadWithPage:(NSInteger)page count:(NSInteger)count;
// 推出评论视图的方法
- (void)pushCommentsViewControllerWithClickedButton:(UIButton *)button;
// 点赞按钮时post服务器的方法
- (void)changeLikesWithFid:(NSString *)fid;

// 结束刷新的方法
- (void)endRefresh;

@end
