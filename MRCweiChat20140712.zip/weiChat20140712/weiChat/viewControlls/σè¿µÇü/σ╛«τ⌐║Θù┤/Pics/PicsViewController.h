//
//  PicsViewController.h
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "CommonViewController.h"

@interface PicsViewController : CommonViewController

@end
