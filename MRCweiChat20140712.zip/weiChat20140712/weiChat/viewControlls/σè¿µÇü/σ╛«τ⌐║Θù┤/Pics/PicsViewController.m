//
//  PicsViewController.m
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "PicsViewController.h"
#import "PicData.h"
#import "PicCell.h"
// 第三方库，UIImage类别，支持gif
#import "UIImage+GIF.h"

@interface PicsViewController ()

@end

@implementation PicsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
#pragma mark 父类解析结果重写
-(void)jsonValue:(HttpDownLoadBlock*)http
{
//    // 如果是点赞请求，不要下载的数据，直接更改请求类型
//    // request.requestType,实际为wid值
//    if (request.requestType) {
//        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
//        [ud setObject:@"YES" forKey:[NSString stringWithFormat:@"%d",request.requestType]];
//        [ud synchronize];
//        request.requestType = 0;
//        return;
//    }
    if (http.dataDict) {
        if (_currentPage == 0) {
            [_dataArray removeAllObjects];
        }
        
        // 更新总页数
        NSInteger totalCount = [[http.dataDict objectForKey:@"total"] integerValue];
        _totalPage = (totalCount-30)/15+(totalCount-30)%15!=0;
        
        NSArray *array = [http.dataDict objectForKey:@"items"];
        for (NSDictionary *subDict in array) {
            // 解析!
            PicData *data = [[PicData alloc] init];
            [data setValuesForKeysWithDictionary:subDict];
            [_dataArray addObject:data];
            [data release];
        }
        // 更新最后一条信息的更新时间，构建上拉加载网址的时候用
        self.max_timestamp = [[array lastObject] objectForKey:@"update_time"];
        // 通知结束刷新
        [self endRefresh];
        [_tableView reloadData];
    }

}

// 重写tableView的协议方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userCell = @"picsCell";
    PicCell *cell = [tableView dequeueReusableCellWithIdentifier:userCell];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"PicCell" owner:self options:nil] lastObject];
    }
    // 布局
    PicData *item = [_dataArray objectAtIndex:indexPath.row];
    // 设置日期
    cell.timeLabel.text = [ZCControl stringDateWithTimeInterval:item.update_time];
    // 设置文本内容
    cell.contentLabel.numberOfLines = 0;
    cell.contentLabel.lineBreakMode = NSLineBreakByCharWrapping;
    cell.contentLabel.text = item.wbody;
    CGRect frame = cell.contentLabel.frame;
    frame.size.height = [ZCControl textHeightWithString:item.wbody width:280 fontSize:14];
    cell.contentLabel.frame = frame;
    // 设置图片内容
    frame.origin.y += frame.size.height+5;
    CGFloat width = [item.wpic_m_width floatValue];
    CGFloat height = [item.wpic_m_height floatValue];
    frame.size.height = 280*height/width;
    if (item.wbody.length == 0) {
        cell.imageview.frame = CGRectMake(20, 34, 280, frame.size.height);
    } else {
        cell.imageview.frame = frame;
    }
    
    NSURL *url = [NSURL URLWithString:item.wpic_middle];
    if ([item.is_gif isEqualToString:@"1"]) {
        // 开启一个异步线程 GCD编程
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSData *data = [NSData dataWithContentsOfURL:url];
            // 通知主线程刷新
            dispatch_async(dispatch_get_main_queue(), ^{
                UIImage *image = [UIImage sd_animatedGIFWithData:data];
                cell.imageview.image = image;
            });
        });
    } else {
        [cell.imageview setImageWithURL:url placeholderImage:[UIImage imageNamed:@"watermark template@2x.png"]];
    }
    // 设置按钮的位置及内容
    CGRect likeFrame = cell.zanButton.frame;
    likeFrame.origin.y = cell.imageview.frame.origin.y+cell.imageview.frame.size.height+5;
    cell.zanButton.frame = likeFrame;
    cell.zanButton.tag = indexPath.row;
    [cell.zanButton setTitle:[NSString stringWithFormat:@"赞:%d",[item.likes integerValue]] forState:UIControlStateNormal];
    // 如果能找到item.wid的key对应的值，则说明，已经点过赞了!
    if ([[NSUserDefaults standardUserDefaults] objectForKey:item.wid]) {
        cell.zanButton.enabled = NO;
    } else {
        cell.zanButton.enabled = YES;
    }
    [cell.zanButton addTarget:self action:@selector(zanButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    // 设置评论按钮的位置及内容
    CGRect commentsFrame = cell.commentsButton.frame;
    commentsFrame.origin.y = likeFrame.origin.y;
    cell.commentsButton.frame = commentsFrame;
    cell.commentsButton.tag = [item.wid integerValue];
    [cell.commentsButton setTitle:[NSString stringWithFormat:@"评:%d",[item.comments integerValue]] forState:UIControlStateNormal];
    [cell.commentsButton addTarget:self action:@selector(commentsButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

- (void)zanButtonClick:(UIButton *)button
{
    PicData *item = [_dataArray objectAtIndex:button.tag];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if ([ud objectForKey:item.wid]) {
        // MMProgress
    } else {
        item.likes = [ZCControl addOneByIntegerString:item.likes];
        [button setTitle:[NSString stringWithFormat:@"赞:%@",item.likes] forState:UIControlStateNormal];
        button.enabled = NO;
        // 通知服务器，点赞了
        [self changeLikesWithFid:item.wid];
    }
}

- (void)commentsButtonClick:(UIButton *)button
{
    [self pushCommentsViewControllerWithClickedButton:button];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PicData *item = [_dataArray objectAtIndex:indexPath.row];
    CGFloat height = 34.0f;
    if (item.wbody.length != 0) {
        height += [ZCControl textHeightWithString:item.wbody width:280 fontSize:14];
    }
    CGFloat w = [item.wpic_m_width floatValue];
    CGFloat h = [item.wpic_m_height floatValue];
    height += 5+280*h/w;
    height += 30+5;
    return height;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
