//
//  VideoCell.m
//  UI_1
//
//  Created by apple on 14-6-9.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "VideoCell.h"

@implementation VideoCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_imageview release];
    [_contentLabel release];
    [_timeLabel release];
    [_zanLabel release];
    [super dealloc];
}
@end
