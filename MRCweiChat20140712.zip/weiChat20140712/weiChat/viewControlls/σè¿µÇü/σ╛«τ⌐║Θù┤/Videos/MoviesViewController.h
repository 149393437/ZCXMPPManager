//
//  MoviesViewController.h
//  UI_1
//
//  Created by apple on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoData.h"

@interface MoviesViewController : UIViewController

@property (nonatomic, retain) VideoData *item;

@end
