//
//  MoviesViewController.m
//  UI_1
//
//  Created by apple on 14-6-10.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "MoviesViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import "CommentData.h"
#import "CommentCell.h"
#import "UIImageView+WebCache.h"

@interface MoviesViewController () <UITableViewDataSource, UITableViewDelegate> {
    MPMoviePlayerViewController *_player;
    UITableView *_tableView;
    NSMutableArray *_dataArray;
}

@end

@implementation MoviesViewController

- (void)dealloc
{
    self.item = nil;
    [_player release], _player = nil;
    [_tableView release], _tableView = nil;
    [_dataArray release], _dataArray = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)createViewPlayer
{
    UIView *view = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 240)] autorelease];
    _player = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:_item.vplay_url]];
    _player.view.frame = CGRectMake(0, 0, 320, 240);
    [_player.moviePlayer play];
    _player.moviePlayer.controlStyle = MPMovieControlStyleFullscreen;
    [view addSubview:_player.view];
    [self.view addSubview:view];
    // 注册一个播放完成的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(downButtonClick:) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
}

- (void)downButtonClick:(NSNotification *)noti
{
    NSDictionary *dict = [noti userInfo];
    NSLog(@"dict = %@",dict);
    NSInteger type = [[dict objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey] integerValue];
    if (type == 2) {
        // 点击done按钮
        [_player.moviePlayer stop];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
       // [self.navigationController popViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
    } else if (type == 1) {
        // 无法播放
    } else if (type == 0) {
        // 播放结束
    }
}

- (void)createTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 240, 320, 240) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    _dataArray = [[NSMutableArray alloc] init];
}

- (void)createHttpConnection
{
    
    NSString *url = [NSString stringWithFormat:COMMENTS_URL,[_item.wid integerValue], VIDEOS];
    
    [[HttpDownLoadBlock alloc]initWithUrlStr:url setBlock:^(HttpDownLoadBlock *http, BOOL isFinish) {
        [self jsonValue:http];
    }];
  
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self createViewPlayer];
    [self createTableView];
    [self createHttpConnection];
}

// 显示和消失时隐藏导航条
- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}
#pragma mark 父类解析结果重写
-(void)jsonValue:(HttpDownLoadBlock*)http{
    if (http.dataDict) {
        NSArray *array = [http.dataDict objectForKey:@"items"];
        for (NSDictionary *subDict in array) {
            CommentData *item = [[CommentData alloc] init];
            [item setValuesForKeysWithDictionary:subDict];
            [_dataArray addObject:item];
            [item release];
        }
        [_tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userCell = @"commentsCell";
    CommentCell *cell = [tableView dequeueReusableCellWithIdentifier:userCell];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CommentCell" owner:self options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    CommentData *item = [_dataArray objectAtIndex:indexPath.row];
    [cell.imageview setImageWithURL:[NSURL URLWithString:item.author_avatar] placeholderImage:[UIImage imageNamed:@"watermark template@2x.png"]];
    cell.imageview.layer.masksToBounds = YES;
    cell.imageview.layer.cornerRadius = 20;
    cell.userLabel.text = item.author_name;
    cell.timeLabel.text = [ZCControl stringDateWithTimeInterval:item.created_time];
    [cell.zanButton setTitle:[NSString stringWithFormat:@"赞:%d",[item.likes integerValue]] forState:UIControlStateNormal];
    cell.contentLabel.text = item.content;
    cell.contentLabel.numberOfLines = 0;
    cell.contentLabel.lineBreakMode = NSLineBreakByWordWrapping;
    CGRect frame = cell.contentLabel.frame;
    frame.size.height = [ZCControl textHeightWithString:item.content width:280 fontSize:14];
    cell.contentLabel.frame = frame;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentData *item = [_dataArray objectAtIndex:indexPath.row];
    CGFloat height = 53 + [ZCControl textHeightWithString:item.content width:280 fontSize:14];
    return height+5;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 10)] autorelease];
    // 创建label
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 300, 21)];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.text = _item.wbody;
    label.font = [UIFont systemFontOfSize:14];
    CGRect frame = label.frame;
    frame.size.height = [ZCControl textHeightWithString:label.text width:300 fontSize:14];
    label.frame = frame;
    [view addSubview:label];
    [label release];
    // 创建zan标签 (应该是按钮)
    UILabel *zan = [[[UILabel alloc] initWithFrame:CGRectMake(240, label.frame.origin.y+label.frame.size.height, 60, 21)] autorelease];
    zan.text = [NSString stringWithFormat:@"赞:%d",[_item.likes integerValue]];
    zan.font = [UIFont systemFontOfSize:14];
    [view addSubview:zan];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    CGFloat height = 5;
    if (_item.wbody.length != 0) {
        height += [ZCControl textHeightWithString:_item.wbody width:300 fontSize:14];
    }
    height += 5+21+5;
    return height;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
