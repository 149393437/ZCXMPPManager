//
//  VideosViewController.m
//  UI_1
//
//  Created by apple on 14-6-7.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "VideosViewController.h"
#import "VideoData.h"
#import "VideoCell.h"
#import "MoviesViewController.h"

@interface VideosViewController ()

@end

@implementation VideosViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
#pragma mark 父类解析结果重写
-(void)jsonValue:(HttpDownLoadBlock*)http
{
    if (http.dataDict) {
        if (_currentPage == 0) {
            [_dataArray removeAllObjects];
        }
        
        // 更新总页数
        NSInteger totalCount = [[http.dataDict objectForKey:@"total"] integerValue];
        _totalPage = (totalCount-30)/15+(totalCount-30)%15!=0;
        
        NSArray *array = [http.dataDict objectForKey:@"items"];
        for (NSDictionary *subDict in array) {
            // 解析!
            VideoData *item = [[VideoData alloc] init];
            [item setValuesForKeysWithDictionary:subDict];
            [_dataArray addObject:item];
            [item release];
        }
        // 更新最后一条信息的更新时间，构建上拉加载网址的时候用
        self.max_timestamp = [[array lastObject] objectForKey:@"update_time"];
        // 通知结束刷新
        [self endRefresh];
        [_tableView reloadData];
    }

}


// 重写tableView的协议方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *userCell = @"videosCell";
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:userCell];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"VideoCell" owner:self options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    // 布局 (此页面不用考虑位置大小)
    VideoData *item = [_dataArray objectAtIndex:indexPath.row];
    [cell.imageview setImageWithURL:[NSURL URLWithString:item.vpic_small] placeholderImage:[UIImage imageNamed:@"watermark template@2x.png"]];
    cell.contentLabel.text = item.wbody;
    cell.contentLabel.numberOfLines = 3;
    // 尾巴部分为省略号
    cell.contentLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    cell.timeLabel.text = [ZCControl stringDateWithTimeInterval:item.update_time];
    cell.zanLabel.text = [NSString stringWithFormat:@"赞:%d",[item.likes integerValue]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 98.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    VideoData *item = [_dataArray objectAtIndex:indexPath.row];
    MoviesViewController *mvc = [[MoviesViewController alloc] init];
    mvc.item = item;

    [self presentViewController:mvc animated:YES completion:nil];
    [mvc release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
