//
//  VideoData.m
//  UI_1
//
//  Created by apple on 14-6-9.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "VideoData.h"

@implementation VideoData

- (void)dealloc
{
    self.comments = nil;
    self.likes = nil;
    self.update_time = nil;
    self.vpic_small = nil;
    self.vplay_url = nil;
    self.wbody = nil;
    self.wid = nil;
    [super dealloc];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
@end
