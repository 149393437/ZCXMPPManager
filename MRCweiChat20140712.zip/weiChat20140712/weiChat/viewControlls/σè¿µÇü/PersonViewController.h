//
//  PersonViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"
//使用autolink 自动添加库的功能，无需手动添加系统库
#import <CoreLocation/CoreLocation.h>
@interface PersonViewController : RootViewController<CLLocationManagerDelegate>
{
    CLLocationManager*_manager;
}
@property(nonatomic,retain)NSArray*dataArray;
@end
