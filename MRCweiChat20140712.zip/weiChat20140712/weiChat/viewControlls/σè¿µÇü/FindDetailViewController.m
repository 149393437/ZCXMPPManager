
//
//  FindDetailViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "FindDetailViewController.h"
#import "QRCodeGenerator.h"
#import  "ChatViewController.h"
@interface FindDetailViewController ()

@end

@implementation FindDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title=self.myVcard.nickname;
    //判断是否是好友
    isFriend=[[ZCXMPPManager sharedInstance]isFriend:self.usedID];
    [self leftNav];
    
    UILabel*label=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 44) Font:15 Text:[NSString stringWithFormat:@"数字账号:%@",[[self.usedID componentsSeparatedByString:@"@"]firstObject]]];
    label.textAlignment=NSTextAlignmentCenter;
    label.backgroundColor=[UIColor colorWithRed:1 green:1 blue:1 alpha:0.7];
    _tableView.tableHeaderView=label;
    
    // Do any additional setup after loading the view.
}
-(void)leftNav{
   UIButton* leftNavButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 40) ImageName:nil Target:self Action:@selector(leftNavButtonClick) Title:nil];
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithCustomView:leftNavButton];
    self.navigationItem.leftBarButtonItem=item;
    [item release];
    //设置右边按钮图片
    //header_icon_single@2x.png
    UIImage*image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_leftbtn_nor@2x.png",self.path]];
    [leftNavButton setImage:image1 forState:UIControlStateNormal];

}
-(void)leftNavButtonClick{

    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    NSString*title=nil;
    if (isFriend) {
        title=@"发送消息";
    }else{
        title=@"打个招呼";
    }
    
    UIButton*tmpButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 320, 44) ImageName:nil Target:self Action:@selector(sendButtonClick) Title:title];
    [tmpButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    tmpButton.backgroundColor=[UIColor colorWithRed:1 green:1 blue:1 alpha:0.7];
    return tmpButton;

}
-(float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 60;
}
#pragma mark 段尾触发方法
-(void)sendButtonClick{
    if (isFriend) {
        //chatViewController直接进行聊天
        ChatViewController*vc=[[ChatViewController alloc]init];
        vc.friendJid=[[self.usedID componentsSeparatedByString:@"@"]firstObject];
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
    }else{
        //添加好友
        [[ZCXMPPManager sharedInstance]addSomeBody:[[self.usedID componentsSeparatedByString:@"@"]firstObject] Newmessage:nil];
        UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"已发送好友请求" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}
#pragma mark 重写下列方法
-(void)loadData{

     [self loadMyVcardData];
}
-(void)loadMyVcardData{
    NSDictionary*dic;
    if (self.myVcard.photo) {
        dic=@{@"头像":self.myVcard.photo};
    }else{
        
        UIImage*image=[UIImage imageNamed:@"logo_2@2x.png"];
        dic=@{@"头像":UIImagePNGRepresentation(image)};
    }
    NSDictionary*dic1;
    if (self.myVcard.nickname) {
        dic1=@{@"昵称":self.myVcard.nickname};
    }else{
        dic1=@{@"昵称":@"还没有设置昵称"};
    }
    NSDictionary*dic2;
    //自定义节点
    if ([[self.myVcard elementForName:QMD]stringValue]) {
        dic2=@{@"签名": [[self.myVcard elementForName:QMD]stringValue]};
    }else{
        dic2=@{@"签名": @"这家伙很懒没留下什么"};
    }
    NSDictionary*dic3;
    if ([[self.myVcard elementForName:SEX]stringValue]) {
        dic3=@{@"性别":[[self.myVcard elementForName:SEX]stringValue]};
    }else{
        dic3=@{@"性别":@"还没有进行设置"};
        
    }
    NSDictionary*dic4;
    if ([[self.myVcard elementForName:ADDRESS]stringValue]) {
        dic4=@{@"地区":[[self.myVcard elementForName:ADDRESS]stringValue]};
    }else {
        dic4=@{@"地区":@""};
    }
    NSDictionary*dic6;
    if ([[self.myVcard elementForName:PHOTONUM]stringValue]) {
        dic6=@{@"手机号":[[self.myVcard elementForName:PHOTONUM]stringValue]};
    }else{
        dic6=@{@"手机号":@"" };
    }
    
    
    
    
    //处理二维码
    NSString*userName=[[self.usedID componentsSeparatedByString:@"@"]firstObject];
    UIImage*image=[QRCodeGenerator qrImageForString:userName imageSize:300];
    NSData*data=UIImagePNGRepresentation(image);
    
    NSDictionary*dic5=@{@"二维码":data};
    self.dataArray=[NSMutableArray arrayWithObjects:dic,dic1,dic2,dic3,dic4,dic5,dic6, nil];
    
    [_tableView reloadData];
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
