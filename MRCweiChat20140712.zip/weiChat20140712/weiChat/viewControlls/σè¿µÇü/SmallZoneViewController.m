//
//  SmallZoneViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/19.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "SmallZoneViewController.h"
#import "Header.h"
#import "CommonViewController.h"
@interface SmallZoneViewController ()

@end

@implementation SmallZoneViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent=NO;
    [self createScrollView];
    [self themeColor];
    // Do any additional setup after loading the view.
}
-(void)createScrollView
{
    NSArray *controllers = @[@"JokesViewController", @"PicsViewController", @"VideosViewController", @"GirlsViewController"];
    NSArray *categorys = @[JOKES, PICS, VIDEOS, GIRLS];
    NSMutableArray *viewControllers = [[NSMutableArray alloc] initWithCapacity:4];
    for (int i=0; i<4; i++) {
        //    NSString *title = [titles objectAtIndex:i];
        Class cls = NSClassFromString([controllers objectAtIndex:i]);
        CommonViewController *vc = [[cls alloc] init];
        vc.categoryType = [categorys objectAtIndex:i];
        [viewControllers addObject:vc];
    }
 
    UIScrollView*sc=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7])];
    
    sc.contentSize=CGSizeMake(320*4, self.view.frame.size.height-[ZCControl isIOS7]);
    sc.pagingEnabled=YES;
    
    for (int i=0; i<viewControllers.count; i++) {
        CommonViewController*vc=viewControllers[i];
        vc.view.frame=CGRectMake(i*320, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]);
        [sc addSubview:vc.view];
        [vc release];
    }
    [self.view addSubview:sc];
    [sc release];
    [self.view addSubview:sc];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
