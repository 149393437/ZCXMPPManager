//
//  FindDetailViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "MyVcardViewController.h"

@interface FindDetailViewController : MyVcardViewController
{
    BOOL isFriend;

}
@property(nonatomic,copy)NSString*usedID;
//父类中myVcard需要在上一个界面传递过来
@end
