//
//  PersonViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/18.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "PersonViewController.h"
#import "XMPPvCardTemp.h"
#import "FindDetailViewController.h"
#import "PersonTableViewCell.h"
@interface PersonViewController ()

@end

@implementation PersonViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"附近的人";
    //建立UI
    [self createTableView];
    //开始定位，定位后开启请求数据
    [self myLocation];
    
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    [_tableView release];
    [self themeColor];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PersonTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[PersonTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
    }
    //获得用户vcard
    [cell configUI:self.dataArray[indexPath.row]];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//获得vard  还有用户账号
    FindDetailViewController*vc=[[FindDetailViewController alloc]init];
    
    
    //获得用户vcard
    NSString*useid=[self.dataArray[indexPath.row] objectForKey:@"jid"];
    
    //注意在这里添加，不要在切割后添加
    vc.usedID=useid;
    //进行字符串切割，切割出前面的用户名
    useid=[[useid componentsSeparatedByString:@"@"]firstObject];
    XMPPvCardTemp*vard=[[ZCXMPPManager sharedInstance]friendsVcard:useid];
    vc.myVcard=vard;
    vc.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];

    
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
#pragma 定位初始化，并开始定位
-(void)myLocation{
    
    _manager=[[CLLocationManager alloc]init];
    //设置精度
    _manager.distanceFilter=1000;
    //设置代理
    _manager.delegate=self;
    //开始定位
    [_manager startUpdatingLocation];

}
#pragma mark CLLocationManagerDelegate
//-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
//{
//
//}
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
   
    [manager stopUpdatingLocation];
    //如果成功，读取经纬°
    CLLocation*newlocation=[locations firstObject];
    CLLocationCoordinate2D coord=newlocation.coordinate;
    
    NSString*urlStr=[NSString stringWithFormat:@"http://1000phone.net:8088/app/openfire/api/user/near.php?latitude=%lf&longitude=%lf&radius=100",coord.latitude,coord.longitude];
    
    //http://1000phone.net:8088/app/openfire/api/user/near.php?latitude=40.034370342847403&longitude=116.34462364921809&radius=100
 
  
    //请求
   [[HttpDownLoadBlock alloc]initWithUrlStr:@"http://1000phone.net:8088/app/openfire/api/user/near.php?latitude=40.034370342847403&longitude=116.34462364921809&radius=100" setBlock:^(HttpDownLoadBlock *http, BOOL isFinish) {
        
        self.dataArray=[http.dataDict  objectForKey:@"users"];
        [_tableView reloadData];
        [http release];
    }];
    
    
    
}
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    //如果失败，经纬度给一个固定值
    
    [manager stopUpdatingLocation];
    //请求
    HttpDownLoadBlock*request=[[HttpDownLoadBlock alloc]initWithUrlStr:@"http://1000phone.net:8088/app/openfire/api/user/near.php?latitude=40.02212&longitude=116.4343&radius=100" setBlock:^(HttpDownLoadBlock *http, BOOL isFinish) {
        self.dataArray=[http.dataDict  objectForKey:@"users"];
        [_tableView reloadData];
        [http release];
    }];
    
    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
