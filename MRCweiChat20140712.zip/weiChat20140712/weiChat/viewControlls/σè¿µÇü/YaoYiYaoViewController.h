//
//  YaoYiYaoViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface YaoYiYaoViewController : RootViewController
{
    UIImageView*bgImageView1;
    UIImageView*bgImageView2;
    
    BOOL isFinish;

}
@property(nonatomic,retain)NSArray*dataArray;

@end
