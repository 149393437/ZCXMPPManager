//
//  FriendButton.h
//  weiChat
//
//  Created by ZhangCheng on 14/7/6.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendButton : UIButton
@property(nonatomic,retain)XMPPvCardTemp*friendVcard;
@end
