//
//  RadarViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RadarViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "FindDetailViewController.h"
@interface RadarViewController ()

@end

@implementation RadarViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"发现";
    [self themeColor];
    [self createView];
    [self leftNav];
    self.dataArray=[NSMutableArray arrayWithCapacity:0];
    
    //创建iBeacon发现服务
  
    server=[[IBeaconServer alloc]init];
    client=[[IBeaconClient alloc]initWithBlock:^(int type, NSDictionary *dic) {
        
        switch (type) {
            case 0:
                NSLog(@"开启失败");
                break;
            case 1:
                NSLog(@"发现一个新的好友");
                int tag=[[dic objectForKey:@"useName"]intValue];
               
                [[ZCXMPPManager sharedInstance] friendsVcard:[NSString stringWithFormat:@"%d",tag] Block:^(BOOL isSucceed, XMPPvCardTemp *vcard) {
                    UIButton*createButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 44, 44) ImageName:nil Target:self Action:@selector(friendClick:) Title:nil];
                    createButton.center=radarImageView.center;
                    createButton.backgroundColor=[UIColor greenColor];
                    createButton.layer.cornerRadius=23;
                    createButton.layer.masksToBounds=YES;
                    createButton.tag=tag;
                    if (vcard.photo) {
                        [createButton setImage:[UIImage imageWithData:vcard.photo] forState:UIControlStateNormal];
                    }else{
                        [createButton setTitle:vcard.nickname forState:UIControlStateNormal];
                    }
                    [self.dataArray addObject:vcard];
                    [radarImageView addSubview:createButton];
                    [UIView animateWithDuration:2 animations:^{
                        createButton.frame=CGRectMake(arc4random()%320, arc4random()%320, 44, 44);
                    }];
                }];
                break;
            case 2:
                NSLog(@"好友离开了");
                int tag1=[[dic objectForKey:@"useName"]intValue];
                
             UIButton*deleteButton=   (UIButton*)[radarImageView viewWithTag:tag1];
            [UIView animateWithDuration:0.5 animations:^{
                deleteButton.alpha=0;
            }completion:^(BOOL finished) {
                for (XMPPvCardTemp*temp in self.dataArray) {
                   
                    if ( [temp.jid.user isEqualToString:[NSString stringWithFormat:@"%d",tag1]]) {
                        [self.dataArray removeObject:temp];
                    }
                    
                    
                }
                [deleteButton removeFromSuperview];
            }];
                
                break;
            default:
            
                break;
        }
        
      
        
    }];
    
    
}
-(void)leftNav{
    UIButton* leftNavButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 40) ImageName:nil Target:self Action:@selector(leftNavButtonClick) Title:nil];
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithCustomView:leftNavButton];
    self.navigationItem.leftBarButtonItem=item;
    [item release];
    //设置右边按钮图片
    //header_icon_single@2x.png
    UIImage*image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_leftbtn_nor@2x.png",self.path]];
    [leftNavButton setImage:image1 forState:UIControlStateNormal];
    
}
-(void)leftNavButtonClick{
    
    //停止动画
    [radarDisCoverImageView.layer removeAnimationForKey:@"rotationAnimation"];
    //停止发现
    [client release];
    [server release];
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark 创建界面
-(void)createView{
    //radarDisCoverImageView  radarImageView
    radarDisCoverImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 320)];
    radarDisCoverImageView.userInteractionEnabled=YES;
    radarDisCoverImageView.image=[UIImage imageNamed:@"radarDiscoverLayer.png"];
    [self.view addSubview:radarDisCoverImageView];
    [radarDisCoverImageView release];
    radarDisCoverImageView.center=CGPointMake(self.view.center.x, self.view.center.y-64);
    
    radarImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 320)];
    radarImageView.center=CGPointMake(self.view.center.x, self.view.center.y-64);
    radarImageView.userInteractionEnabled=YES;
    radarImageView.image=[UIImage imageNamed:@"radarBg.png"];
    
    [self.view addSubview:radarImageView];
    [radarImageView release];
    CABasicAnimation* rotationAnimation;
    rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat: M_PI * 2.0 ];
    rotationAnimation.duration = 2;
    rotationAnimation.cumulative = YES;
    rotationAnimation.repeatCount = 10000;
    
    [radarDisCoverImageView.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)friendClick:(UIButton*)button{
    //停止动画
    [radarDisCoverImageView.layer removeAnimationForKey:@"rotationAnimation"];
    //停止发现
    [client release];
    [server release];
    
    
    //获得vard  还有用户账号
    
    [[ZCXMPPManager sharedInstance]friendsVcard:[NSString stringWithFormat:@"%d",button.tag] Block:^(BOOL isSucceed, XMPPvCardTemp *vcard) {
        FindDetailViewController*vc=[[FindDetailViewController alloc]init];
        vc.usedID=[NSString stringWithFormat:@"%d",button.tag];
        vc.myVcard=vcard;
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        [vc release];
    }];
    
   
 
   

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
