//
//  YaoYiYaoViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/27.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "YaoYiYaoViewController.h"
#import "FindDetailViewController.h"
#import "PersonTableViewCell.h"
@interface YaoYiYaoViewController ()

@end

@implementation YaoYiYaoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
       [self createTableView];
    bgImageView1=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) ImageName:[NSString stringWithFormat:@"YaoYiYao%d.jpg",arc4random()%2]];
    [self.view addSubview:bgImageView1];

}



-(void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
    NSLog(@"开始摇动");
    
}

-(void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
    NSLog(@"结束摇动");
    if (!isFinish) {
        CATransition*ani=[CATransition animation];
        ani.duration=2.0f;
        ani.subtype = kCATransitionFromRight;
        NSArray*array=@[@"cube", @"moveIn", @"reveal",@"pageCurl",@"pageUnCurl", @"suckEffect",@"rippleEffect",@"oglFlip"];
        ani.type=array[arc4random()%array.count];
        [self.view.layer addAnimation:ani forKey:@""];
        [self.view bringSubviewToFront:bgImageView1];
        
        isFinish=YES;
        [[HttpDownLoadBlock alloc]initWithUrlStr:@"http://1000phone.net:8088/app/openfire/api/user/near.php?latitude=39.896304&longitude=116.410103&radius=100" setBlock:^(HttpDownLoadBlock *http, BOOL succeed) {
            self.dataArray=[http.dataDict  objectForKey:@"users"];
            [_tableView reloadData];
            [http release];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                isFinish=NO;
                CATransition*ani=[CATransition animation];
                ani.duration=2.0f;
                ani.subtype = kCATransitionFromRight;
                NSArray*array=@[@"cube", @"moveIn", @"reveal",@"pageCurl",@"pageUnCurl", @"suckEffect",@"rippleEffect",@"oglFlip"];
                ani.type=array[arc4random()%array.count];
                [self.view.layer addAnimation:ani forKey:@""];
                [self.view bringSubviewToFront:_tableView];
                
            });
        }];
        
        
    }

}

-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    [_tableView release];
    [self themeColor];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PersonTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[PersonTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"]autorelease];
    }
    //获得用户vcard
    [cell configUI:self.dataArray[indexPath.row]];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //获得vard  还有用户账号
    FindDetailViewController*vc=[[FindDetailViewController alloc]init];
    
    
    //获得用户vcard
    NSString*useid=[self.dataArray[indexPath.row] objectForKey:@"jid"];
    
    //注意在这里添加，不要在切割后添加
    vc.usedID=useid;
    //进行字符串切割，切割出前面的用户名
    useid=[[useid componentsSeparatedByString:@"@"]firstObject];
    XMPPvCardTemp*vard=[[ZCXMPPManager sharedInstance]friendsVcard:useid];
    vc.myVcard=vard;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
    
    
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
