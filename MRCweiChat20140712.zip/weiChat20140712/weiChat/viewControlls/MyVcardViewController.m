//
//  MyVcardViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "MyVcardViewController.h"
#import "XMPPvCardTemp.h"
#import "QRCodeGenerator.h"
#import "ShowMyVcardViewController.h"
#import "RoundImageView.h"
@interface MyVcardViewController ()

@end

@implementation MyVcardViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"个人资料";
    [self createTableView];
    [self loadData];
    [self createLeftNav];
    
    

    
}
-(void)createLeftNav{
    UIButton*button=[UIButton buttonWithType:UIButtonTypeCustom ];
    button.frame=CGRectMake(0, 0, 60, 40);
    [button addTarget:self action:@selector(leftBarButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
     UIImage*image1=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_leftbtn_nor@2x.png",self.path]];
    [button setImage:image1 forState:UIControlStateNormal];
   
    UIBarButtonItem*leftBarButton=[[UIBarButtonItem alloc]initWithCustomView:button];
    self.navigationItem.leftBarButtonItem=leftBarButton;
    [leftBarButton release];

}
#pragma mark 提交Vcard，更新服务器数据
-(void)leftBarButtonClick{
    if (isUpData) {
        [[ZCXMPPManager sharedInstance]upData:self.myVcard];
    }
        //返回上一界面
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    [_tableView release];

    UILabel*label=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 44) Font:15 Text:[NSString stringWithFormat:@"您的数字账号:%@",[[NSUserDefaults standardUserDefaults] objectForKey:kXMPPmyJID]]];
    label.textAlignment=NSTextAlignmentCenter;
    label.backgroundColor=[UIColor colorWithRed:1 green:1 blue:1 alpha:0.7];
    _tableView.tableHeaderView=label;
    
    [self themeColor];
    
}
-(void)themeConfig
{

}
-(float)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 7;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"]autorelease];
        RoundImageView*header=[[RoundImageView alloc]initWithFrame:CGRectMake(320-64, 2, 40, 40)];
        [cell.contentView addSubview:header];
        header.tag=300;
    }
    
    NSDictionary*dic=self.dataArray[indexPath.row];
    cell.textLabel.text=[[dic allKeys]firstObject];
    
    if (indexPath.row!=0&&indexPath.row!=5) {
        UIView*view=[cell.contentView viewWithTag:300];
        view.hidden=YES;
        cell.detailTextLabel.text=[[dic allValues]firstObject];
        
    }else {
    
        UIImageView*imageView=(UIImageView*)[cell.contentView viewWithTag:300];
        imageView.hidden=NO;
        imageView.image=[UIImage imageWithData:[[dic allValues] firstObject]];
        
        cell.detailTextLabel.text=nil;
    }
    
    return cell;


}

-(void)loadData{
    //获得自己的名片
    
    ZCXMPPManager*manager=[ZCXMPPManager sharedInstance];
    [manager getMyVcardBlock:^(BOOL isFinish, XMPPvCardTemp * myVcardTemp) {
        self.myVcard=myVcardTemp;
        [self loadMyVcardData];
    }];

}
-(void)loadMyVcardData{
    NSDictionary*dic;
    if (self.myVcard.photo) {
         dic=@{@"头像":self.myVcard.photo};
    }else{
    
        UIImage*image=[UIImage imageNamed:@"logo_2@2x.png"];
       dic=@{@"头像":UIImagePNGRepresentation(image)};
    }
    NSDictionary*dic1;
    if (self.myVcard.nickname) {
         dic1=@{@"昵称":self.myVcard.nickname};
    }else{
    dic1=@{@"昵称":@"还没有设置昵称"};
    }
    NSDictionary*dic2;
    //自定义节点
    if ([[self.myVcard elementForName:QMD]stringValue]) {
           dic2=@{@"签名": [[self.myVcard elementForName:QMD]stringValue]};
    }else{
    dic2=@{@"签名": @"这家伙很懒没留下什么"};
    }
    NSDictionary*dic3;
    if ([[self.myVcard elementForName:SEX]stringValue]) {
          dic3=@{@"性别":[[self.myVcard elementForName:SEX]stringValue]};
    }else{
     dic3=@{@"性别":@"还没有进行设置"};
    
    }
    NSDictionary*dic4;
    if ([[self.myVcard elementForName:ADDRESS]stringValue]) {
        dic4=@{@"地区":[[self.myVcard elementForName:ADDRESS]stringValue]};
    }else {
     dic4=@{@"地区":@""};
    }
    NSDictionary*dic6;
    if ([[self.myVcard elementForName:PHOTONUM]stringValue]) {
        dic6=@{@"手机号":[[self.myVcard elementForName:PHOTONUM]stringValue]};
    }else{
        dic6=@{@"手机号":@"" };
    }
   
   
    
    
    //处理二维码
    NSString*userName=[[NSUserDefaults standardUserDefaults  ]objectForKey:kXMPPmyJID];
    UIImage*image=[QRCodeGenerator qrImageForString:userName imageSize:300];
    NSData*data=UIImagePNGRepresentation(image);
    
    NSDictionary*dic5=@{@"二维码":data};
    self.dataArray=[NSMutableArray arrayWithObjects:dic,dic1,dic2,dic3,dic4,dic5,dic6, nil];
    
    [_tableView reloadData];
}


-(void)customAlertView:(NSString*)title tag:(int)a{
    UIAlertView*alert=[[UIAlertView alloc]initWithTitle:title message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alert.tag=a;
    alert.alertViewStyle=UIAlertViewStylePlainTextInput;
    [alert show];
    [alert release];



}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex) {
        isUpData=YES;
        UITextField*textField;
        NSString*strValue=nil;
        if (alertView.alertViewStyle==UIAlertViewStylePlainTextInput) {
         textField=[alertView textFieldAtIndex:0];
        }
        if (textField) {
            if (textField.text.length>0) {
                strValue=textField.text;
            }else{
            strValue=@" ";
            }
            
        }
        
        
        switch (alertView.tag) {
            case 1:
                NSLog(@"修改昵称");
                self.myVcard.nickname=strValue;
                break;
                
            case 2:
                NSLog(@"修改签名");
            
                [[ZCXMPPManager sharedInstance]customVcardXML:strValue name:QMD myVcard:self.myVcard];
                break;
            case 3:
//                NSLog(@"修改性别");
//                [[ZCXMPPManager sharedInstance]customVcardXML:strValue name:@"SEX" myVcard:self.myVcard];
                break;
            case 4:
                NSLog(@"地区");
                [[ZCXMPPManager sharedInstance]customVcardXML:strValue name:ADDRESS myVcard:self.myVcard];
                break;
             case 6:
                NSLog(@"手机号");
                [[ZCXMPPManager sharedInstance]customVcardXML:strValue name:PHOTONUM myVcard:self.myVcard];
                
            default:
                break;
        }
        //注意！这里是本地操作
        [self loadMyVcardData];
        
    }

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row==0) {
        UIImagePickerController*picker=[[UIImagePickerController alloc]init];
        picker.delegate=self;
        //开启相册
        [self presentViewController:picker animated:YES completion:nil];
        [picker release];
    }
    
    
    switch (indexPath.row) {
        case 1:
            [self customAlertView:@"修改昵称" tag:indexPath.row];
            break;
        case 2:
             [self customAlertView:@"修改签名" tag:indexPath.row];
            break;
        case 3:
            // [self customAlertView:@"修改性别" tag:indexPath.row];
            break;
        case 4:
             [self customAlertView:@"修改地区" tag:indexPath.row];
            break;
        case 5:
        {
            ShowMyVcardViewController*vc=[[ShowMyVcardViewController alloc]init];
            vc.myVcard=self.myVcard;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 6:
            [self customAlertView:@"修改手机号" tag:indexPath.row];
            break;
            
            
        default:
            break;
    }

}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //读取图片
    UIImage*image=[info objectForKey:UIImagePickerControllerOriginalImage];
    //设置头像
    self.myVcard.photo=UIImagePNGRepresentation(image);
    //重新刷新界面
    [self loadMyVcardData];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
