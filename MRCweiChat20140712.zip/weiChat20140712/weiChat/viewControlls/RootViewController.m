
//
//  RootViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/11.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc{
    [super dealloc];
    //移除通知中心
    [[NSNotificationCenter defaultCenter]removeObserver:self name:THEME object:nil];
    

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //设置导航条不透明
    self.navigationController.navigationBar.translucent=NO;

    //设置导航
    [self createNav];
   
    //设置通知中心
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeClick) name:THEME object:nil];
}
#pragma mark 该方法需要在子类tableView创建时候调用一次
-(void)themeColor{
    //子类中执行以下方法
    _tableView.backgroundColor=[UIColor clearColor];
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bg_default.jpg",self.path ]]];

}


//通知中心方法 该方法需要在子类中重载
-(void)themeClick{
//在子类必须要重载有
    [self createNav];
//设置self.view的背景色或者tableView的背景色
    [self themeColor];
//设置cell的背景色
    [_tableView reloadData];
//其他收到切换主题的方法
    
//切换字体颜色
    NSDictionary*dic=[NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@ThemeConfig.plist",self.path]];
    NSDictionary*dic1=[ dic objectForKey:@"ColorTable"];
    NSString*str=[dic1 objectForKey:@"kNavigationBarTitleColor"];
    NSArray*array=[str componentsSeparatedByString:@","];
    UIColor *textColor=[UIColor colorWithRed:strtol( [array[0] UTF8String], NULL, 16)/255.0 green:strtol( [array[1] UTF8String], NULL, 16)/255.0 blue:strtol( [array[2] UTF8String], NULL, 16)/255.0 alpha:1];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:textColor}];
    
    NSString*str1=[dic1 objectForKey:@"kUrlTextColorNormal"];
    NSArray*array1=[str1 componentsSeparatedByString:@","];
    UIColor *textColor1=[UIColor colorWithRed:strtol( [array1[0] UTF8String], NULL, 16)/255.0 green:strtol( [array1[1] UTF8String], NULL, 16)/255.0 blue:strtol( [array1[2] UTF8String], NULL, 16)/255.0 alpha:1];
    [[UITextView appearance]setTextColor:textColor1];
    [self themeConfig];
    
}
#pragma mark 子类重载这个方法进行收到通知以后的相关调用
-(void)themeConfig{

}
-(void)createNav{
    //设置路径
    NSUserDefaults*defaults=[NSUserDefaults standardUserDefaults];
    NSString*name= [defaults objectForKey:THEME];
    self.path=[NSString stringWithFormat:@"%@/Documents/%@/",NSHomeDirectory(),name];
    
    
    //设置导航背景色
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_bg@2x.png",self.path]] forBarMetrics:UIBarMetricsDefault];
    
    NSDictionary*dic=[NSDictionary dictionaryWithContentsOfFile:[NSString stringWithFormat:@"%@ThemeConfig.plist",self.path]];
    NSDictionary*dic1=[ dic objectForKey:@"ColorTable"];
    NSString*str=[dic1 objectForKey:@"kNavigationBarTitleColor"];
    NSArray*array=[str componentsSeparatedByString:@","];
    UIColor *textColor=[UIColor colorWithRed:strtol( [array[0] UTF8String], NULL, 16)/255.0 green:strtol( [array[1] UTF8String], NULL, 16)/255.0 blue:strtol( [array[2] UTF8String], NULL, 16)/255.0 alpha:1];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:textColor}];
  
     NSString*str1=[dic1 objectForKey:@"kUrlTextColorNormal"];
    NSArray*array1=[str1 componentsSeparatedByString:@","];
    UIColor *textColor1=[UIColor colorWithRed:strtol( [array1[0] UTF8String], NULL, 16)/255.0 green:strtol( [array1[1] UTF8String], NULL, 16)/255.0 blue:strtol( [array1[2] UTF8String], NULL, 16)/255.0 alpha:1];
    [[UITextView appearance]setTextColor:textColor1];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
