
//
//  FriendViewController.m
//  weiChat
//
//  Created by ZhangCheng on 14/6/13.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "FriendViewController.h"
#import "NewFriendViewController.h"
#import "XMPPvCardTemp.h"
#import "ChatViewController.h"
#import "FriendCell.h"
@interface FriendViewController ()

@end

@implementation FriendViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    int page=[ZCXMPPManager sharedInstance].subscribeArray.count;
    if (page>0) {
        [proving setTitle:[NSString stringWithFormat:@"您有%d个请求加您为好友",page] forState:UIControlStateNormal];
        
    }else{
    [proving setTitle:@"没有新好友请求" forState:UIControlStateNormal];
       
    }


}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createRightNav];
   //建立UI
    [self createTableView];
    //读取数据
    [self loadData];
}
//创建右边按钮
-(void)createRightNav{
//header_icon_add@2x.png
   
    rightNavButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 44, 44) ImageName:nil Target:self Action:@selector(rightNavButtonClick) Title:nil];
    UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_icon_add@2x.png",self.path]];
    
    [rightNavButton setImage:image forState:UIControlStateNormal];
    UIBarButtonItem*rightItem=[[UIBarButtonItem alloc]initWithCustomView:rightNavButton];
    self.navigationItem.rightBarButtonItem=rightItem;
    [rightItem release];
    

}
#pragma mark 添加好友
-(void)rightNavButtonClick{
    UIAlertView*alertView=[[UIAlertView alloc]initWithTitle:@"请输入要添加的账号" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alertView.alertViewStyle=UIAlertViewStylePlainTextInput;
    [alertView show];
    [alertView release];

}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex) {
        UITextField*textField=[alertView textFieldAtIndex:0];
        if (textField.text.length>0) {
            //发送添加好友
            [[ZCXMPPManager sharedInstance]addSomeBody:textField.text Newmessage:@"验证消息"];
        }
        
        
    }

}

-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.separatorStyle =UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    [_tableView release];
    
    //还需要添加段头，验证消息
    
    proving=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 320, 44) ImageName:nil Target:self Action:@selector(provingClick) Title:nil];
    [proving setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    proving.backgroundColor=[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.7];
    _tableView.tableHeaderView=proving;
     [proving setTitle:@"没有新好友请求" forState:UIControlStateNormal];
    
    [self themeColor];

}
-(void)themeConfig
{
  
    UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_icon_add@2x.png",self.path]];
    
    [rightNavButton setImage:image forState:UIControlStateNormal];
}
#pragma mark 查看验证消息
-(void)provingClick{
    NewFriendViewController*vc=[[NewFriendViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
}
//分段 设定多少段
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    NSArray*array=@[@"好友",@"关注",@"被关注",@"陌生人"];

    UIView*view=[[UIView alloc]initWithFrame:CGRectZero];
    UIImageView*spin=[[UIImageView alloc]initWithFrame:CGRectMake(20,20 , 10, 10)];
    spin.image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@buddy_header_arrow@2x.png",self.path]];
    [view addSubview:spin];
    [spin release];
    if (!isOpen[section]) {
        spin.transform=CGAffineTransformMakeRotation(M_PI_2);
    }
    
    UILabel*label=[ZCControl createLabelWithFrame:CGRectMake(50, 15, 200, 20) Font:15 Text:[NSString stringWithFormat:@"%@ (%d 人)",array[section],[self.dataArray[section] count]]];
    [view addSubview:label];
    UIControl*control=[[UIControl alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    control.tag=section;
    [control addTarget:self action:@selector(headerButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    view.backgroundColor=[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.7];
    [view addSubview:control];
    
    
    return [view autorelease];

}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 44;
    
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

//判断收缩
-(void)headerButtonClick:(UIControl*)button{
    
    isOpen[button.tag]=!isOpen[button.tag];
    //刷新某一段
    [_tableView reloadSections:[NSIndexSet indexSetWithIndex:button.tag] withRowAnimation:UITableViewRowAnimationLeft];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return isOpen[section]?0:[self.dataArray[section] count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FriendCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell==nil) {
        cell=[[[FriendCell  alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"]autorelease];
    }
    XMPPUserCoreDataStorageObject*object=[self.dataArray[indexPath.section] objectAtIndex:indexPath.row];
    
    [cell configUI:object];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMPPUserCoreDataStorageObject*objcet=[self.dataArray[indexPath.section]objectAtIndex:indexPath.row];
    ChatViewController*vc=[[ChatViewController alloc]init];
    vc.friendJid=[[objcet.jidStr componentsSeparatedByString:@"@"]firstObject];
    vc.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];

}


-(void)loadData{
    
    NSLog(@"%@",NSHomeDirectory());

    //获得好友列表 直接返回的是好友列表
  NSArray*array=[[ZCXMPPManager sharedInstance]friendsList:^(BOOL upData) {
        //通知我处理好友消息,我的好友关系发生变化，通知我重新获得数据
      [self loadData];
    }];
    
    self.dataArray=[NSMutableArray arrayWithArray:array];
    
    int page=[ZCXMPPManager sharedInstance].subscribeArray.count;
    if (page>0) {
        [proving setTitle:[NSString stringWithFormat:@"您有%d个请求加您为好友",page] forState:UIControlStateNormal];
    }else{
    [proving setTitle:@"没有新消息" forState:UIControlStateNormal];
    }
    [_tableView reloadData];
    
}

-(float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.0001;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
