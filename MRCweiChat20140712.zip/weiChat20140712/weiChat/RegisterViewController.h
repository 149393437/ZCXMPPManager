//
//  RegisterViewController.h
//  weiChat
//
//  Created by ZhangCheng on 14/6/11.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>
@property (retain, nonatomic) IBOutlet UITextField *userName;
@property (retain, nonatomic) IBOutlet UITextField *passWord;
@property (retain, nonatomic) IBOutlet UITextField *passWord1;

@end
