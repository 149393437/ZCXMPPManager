//
//  RootViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()
{
   

}

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc
{
    //注销本类中观察的通知
    [[NSNotificationCenter defaultCenter]removeObserver:self name:THEME object:nil];

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createNav];
    self.automaticallyAdjustsScrollViewInsets=NO;
    
    //通过观察我发出的通知，来进行相应的改变 THEME是我在主题界面下载完成后发出的通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(createNav) name:THEME object:nil];
    
    
}
-(void)createNav{
//读取当前主题
    NSString*str=[[NSUserDefaults standardUserDefaults]objectForKey:THEME];
//拼接路径
    self.path=[NSString stringWithFormat:@"%@%@/",LIBPATH,str];
    //设置导航图片
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_bg.png",self.path]] forBarMetrics:UIBarMetricsDefault];
    
    //设置字体颜色
    if (iOS7) {
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:[UIColor whiteColor]}];
    }else{
        [self.navigationController.navigationBar setTitleTextAttributes:@{UITextAttributeFont:[UIFont systemFontOfSize:15],UITextAttributeTextColor:[UIColor whiteColor]}];

    }
    
    //设置背景颜色
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bg_default.jpg",self.path]]];

    [self themeMothod];
    
}

-(void)themeMothod{

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
