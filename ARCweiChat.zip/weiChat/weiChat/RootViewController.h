//
//  RootViewController.h
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    UITableView*_tableView;
}
@property(nonatomic,strong)NSMutableArray*dataArray;
@property(nonatomic,copy)NSString*path;
-(void)themeMothod;

@end




