//
//  ZCAppDelegate.m
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "ZCAppDelegate.h"
#import "LoginViewController.h"
#import "MainTabViewController.h"
#import "ZipArchive.h"
@implementation ZCAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    /*
     工程默认控件的配置
     */
    //设置所有button字体颜色默认为黑色
    [[UIButton appearance]setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    //设置tableView的背景色为透明色
    [[UITableView appearance]setBackgroundColor:[UIColor clearColor]];
    //设置cell的颜色为半透明色
    [[UITableViewCell appearance]setBackgroundColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:0.5]];
    
    /*当程序第一次启动时候执行移动com.zip到沙盒目录下，进行解压缩*/
     NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    //appfirst是自定义的，用于记录是否是第一次进入程序，如果appfirst为nil则是第一次进入
    NSString*appfirst=[user objectForKey:@"appfirst"];
    if (appfirst==nil) {
        //执行com.zip到沙盒目录
        NSString*path=[[NSBundle mainBundle]pathForResource:@"com" ofType:@"zip"];
        //移动到哪
        NSString*toPath=[NSString stringWithFormat:@"%@data.zip",LIBPATH];
        //读取数据
        NSData*data=[NSData dataWithContentsOfFile:path];
        //写入沙盒
        [data writeToFile:toPath atomically:YES];
        //解压缩路径 为什么是绿色简约，我自己规定主题包名称
        NSString*UnZipPath=[NSString stringWithFormat:@"%@绿色简约",LIBPATH];
        //实例化解压缩工具
        ZipArchive*zip=[[ZipArchive alloc]init];
        //打开压缩包
        [zip UnzipOpenFile:toPath];
        //解压缩
        [zip UnzipFileTo:UnZipPath overWrite:YES];
        //关闭解压缩工具
        [zip UnzipCloseFile];
        
        //记住第一次进入，下次启动不在执行
        [user setObject:@"appfirst" forKey:@"appfirst"];
        [user setObject:@"绿色简约" forKey:THEME];
        [user synchronize];
   
    }

    NSString*islogin1=[user objectForKey:isLogin];
    
    if (islogin1.length>0) {
        MainTabViewController*tbc=[[MainTabViewController alloc]init];
        
        self.window.rootViewController=tbc;
        
    }else{
        LoginViewController*vc=[[LoginViewController alloc]init];
        self.window.rootViewController=vc;
    
    }
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
