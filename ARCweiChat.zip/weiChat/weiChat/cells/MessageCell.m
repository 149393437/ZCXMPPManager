//
//  MessageCell.m
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "MessageCell.h"
#import "Photo.h"
#import "ZCChatAVAdioPlay.h"
//转换
#import "VoiceConverter.h"
#import "NSString+Base64.h"

@implementation MessageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    float y=[UIScreen mainScreen].bounds.size.width;
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    self.path=[NSString stringWithFormat:@"%@%@/",LIBPATH,[user objectForKey:THEME]];
    
    
    leftHeaderImageView=[ZCControl createImageViewWithFrame:CGRectMake(5,5, 30, 30) ImageName:nil];
    //圆
    leftHeaderImageView.layer.cornerRadius=15;
    //裁剪
    leftHeaderImageView.layer.masksToBounds=YES;
    [self.contentView addSubview:leftHeaderImageView];
    
    //气泡,气泡的大小要根据内容来制定
    leftBubbleImageView=[ZCControl createImageViewWithFrame:CGRectZero ImageName:nil];
    //图片 图片来源于主题的气泡图片
    //chat_send_nor@2x.png图片是朝向右边的
    UIImage*image=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_send_nor@2x.png",self.path]];
    //我们需要把图像翻转180°，注意不是旋转
    image=[UIImage imageWithCGImage:image.CGImage scale:2 orientation:UIImageOrientationUpMirrored];
    //翻转以后，设置图片拉伸规则,按照x为40像素点，y为28像素点进行拉伸
   image= [image stretchableImageWithLeftCapWidth:40 topCapHeight:28];
    leftBubbleImageView.image=image;
    
    //语音~文字~图片~大表情都加载在leftBubbleImageView上
    //照片
    leftPhotoImageView=[ZCControl createImageViewWithFrame:CGRectZero ImageName:nil];
    [leftBubbleImageView addSubview:leftPhotoImageView];
    //语音
    leftVoiceButton=[ZCControl createButtonWithFrame:CGRectMake(10, 5, 30, 30) ImageName:nil Target:self Action:@selector(voiceButton) Title:nil];
    //语音设置图片
    [leftVoiceButton setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bottom_voice_nor.png",self.path]] forState:UIControlStateNormal];
    [leftBubbleImageView addSubview:leftVoiceButton];
    
    //大表情
    leftBigImageView=[[StickerImageView alloc]initWithFrame:CGRectMake(5, 5, 200, 200)];
    [leftBubbleImageView addSubview:leftBigImageView];
    //文字
    leftTitle=[ZCControl createLabelWithFrame:CGRectZero Font:10 Text:nil];
    [leftBubbleImageView addSubview:leftTitle];
    [self.contentView addSubview:leftBubbleImageView];
    
  //右边的
    rightHeaderImageView=[ZCControl createImageViewWithFrame:CGRectMake(y-35, 5, 30, 30) ImageName:nil];
    [self.contentView addSubview:rightHeaderImageView];
    rightBubbleImageView=[ZCControl createImageViewWithFrame:CGRectZero ImageName:nil];
    UIImage*rightImage=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_send_nor@2x.png",self.path]];
    //设置拉伸规则
    rightImage=[rightImage stretchableImageWithLeftCapWidth:40 topCapHeight:28];
    rightBubbleImageView.image=rightImage;
    [self.contentView addSubview:rightBubbleImageView];
    
    //文字 语音 图片 大表情加载rightBubbleImageView上
    
    rightTitle=[ZCControl createLabelWithFrame:CGRectZero Font:10 Text:nil];
    [rightBubbleImageView addSubview:rightTitle];
    
    rightVoiceButton=[ZCControl createButtonWithFrame:CGRectMake(10, 5, 30, 30) ImageName:nil Target:self Action:@selector(voiceButton) Title:nil];
    [rightVoiceButton setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@chat_bottom_voice_nor@2x.png",self.path]] forState:UIControlStateNormal];
    [rightBubbleImageView addSubview:rightVoiceButton];
    rightPhotoImageView=[ZCControl createImageViewWithFrame:CGRectZero ImageName:nil];
    [rightBubbleImageView addSubview:rightPhotoImageView];
    rightBigImageView=[[StickerImageView alloc]initWithFrame:CGRectMake(5, 5, 200, 200)];
    [rightBubbleImageView addSubview:rightBigImageView];

}
-(void)configleftImage:(UIImage *)leftImage rightImage:(UIImage *)rightImage Message:(XMPPMessageArchiving_Message_CoreDataObject *)object
{
    leftHeaderImageView.image=leftImage;
    rightHeaderImageView.image=rightImage;
    //获取文字信息
    NSString*message=[object.body substringFromIndex:3];
    
    //计算y值
    int x=[UIScreen mainScreen].bounds.size.width;

    if (!object.isOutgoing) {
        //对方
        leftHeaderImageView.hidden=NO;
        leftBubbleImageView.hidden=NO;
        rightHeaderImageView.hidden=YES;
        rightBubbleImageView.hidden=YES;
        
        if ([object.body hasPrefix:MESSAGE_STR]) {
            leftPhotoImageView.hidden=YES;
            leftBigImageView.hidden=YES;
            leftVoiceButton.hidden=YES;
            leftTitle.hidden=NO;
            //计算文字大小
            CGSize size=[message sizeWithFont:[UIFont systemFontOfSize:10] constrainedToSize:CGSizeMake(200, 1000)];
            leftTitle.frame=CGRectMake(10, 10, size.width, size.height);
            //设置气泡大小
            leftBubbleImageView.frame=CGRectMake(40, 5, size.width+20, size.height+20);
            leftTitle.text=message;
            
            
            
        }else{
            if ([object.body hasPrefix:MESSAGE_VOICE]) {
                leftPhotoImageView.hidden=YES;
                leftBigImageView.hidden=YES;
                leftVoiceButton.hidden=NO;
                leftTitle.hidden=YES;
                leftBubbleImageView.frame=CGRectMake(40, 5, 40, 40);
                
                
            }else{
                if ([object.body hasPrefix:MESSAGE_IMAGESTR]) {
                    leftPhotoImageView.hidden=NO;
                    leftBigImageView.hidden=YES;
                    leftVoiceButton.hidden=YES;
                    leftTitle.hidden=YES;
                    
                    UIImage*photoImage=[Photo string2Image:message];
                    //计算photo大小
                    leftPhotoImageView.frame=CGRectMake(5, 5, photoImage.size.width>200?200:photoImage.size.width, photoImage.size.height>200?200:photoImage.size.height);
                    leftBubbleImageView.frame=CGRectMake(40, 5, leftPhotoImageView.frame.size.width+10, leftPhotoImageView.frame.size.height+10);
                    leftPhotoImageView.image=photoImage;
                    
                    
                    
                }else{
                    if ([object.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
                        leftPhotoImageView.hidden=YES;
                        leftBigImageView.hidden=NO;
                        leftVoiceButton.hidden=YES;
                        leftTitle.hidden=YES;
                        
                        leftBigImageView.frame=CGRectMake(5, 5, 200, 200);
                        leftBigImageView.sticker=[StickerInfo stickerWithID:message];
                        leftBubbleImageView.frame=CGRectMake(40, 5, 210, 210);
                        
                        
                    }
                
                
                
                }
            
            }
            
        
        }
        
        
    }else {
    //自己
        rightHeaderImageView.hidden=NO;
        rightBubbleImageView.hidden=NO;
        leftBubbleImageView.hidden=YES;
        leftHeaderImageView.hidden=YES;
        
        if ([object.body hasPrefix:MESSAGE_STR]) {
            rightBigImageView.hidden=YES;
            rightPhotoImageView.hidden=YES;
            rightTitle.hidden=NO;
            rightVoiceButton.hidden=YES;
            //文字
            CGSize size1=[object.body sizeWithFont:[UIFont systemFontOfSize:10] constrainedToSize:CGSizeMake(200, 1000)];
            rightTitle.frame=CGRectMake(10, 10, size1.width, size1.height);
            rightTitle.text=message;
            rightBubbleImageView.frame=CGRectMake(x-40-size1.width-20, 5, size1.width+20, size1.height+20);

        }else{
            //图片
            if ([object.body hasPrefix:MESSAGE_IMAGESTR]) {
                
                rightBigImageView.hidden=YES;
                rightPhotoImageView.hidden=NO;
                rightTitle.hidden=YES;
                rightVoiceButton.hidden=YES;

                UIImage*image=[Photo string2Image:message];
                rightPhotoImageView.frame=CGRectMake(5, 5, image.size.width>200?200:image.size.width, image.size.height>200?200:image.size.height);
                rightPhotoImageView.image=image;
                
                rightBubbleImageView.frame=CGRectMake(x-40-rightPhotoImageView.frame.size.width-10, 5, rightPhotoImageView.frame.size.width+10, rightPhotoImageView.frame.size.height+10);
            }else{
            //语音
                if ([object.body hasPrefix:MESSAGE_VOICE]) {
                    rightBigImageView.hidden=YES;
                    rightPhotoImageView.hidden=YES;
                    rightTitle.hidden=YES;
                    rightVoiceButton.hidden=NO;
                    
                    rightBubbleImageView.frame=CGRectMake(x-40-50, 5, 50, 50);
                }else{
                    if ([object.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
                        rightBigImageView.hidden=NO;
                        rightPhotoImageView.hidden=YES;
                        rightTitle.hidden=YES;
                        rightVoiceButton.hidden=YES;
                        
                        rightBubbleImageView.frame=CGRectMake(x-40-210, 5, 210, 210);
                        rightBigImageView.sticker=[StickerInfo stickerWithID:message];
                    
                    }
                
                
                }
                
            
            }
  
        }
    }
    
    
    //保存信息
    
    self.messageStr=message;
    
    
    

}


-(void)voiceButton{
    NSLog(@"语音");
    
//录制声音，默认的格式是WAV的，转换为AMR格式，AMR格式比较小，大约只有WAV的1/10,方便传输，所以我们接受到的文件也是AMR格式，需要进行转换才可以播放
    
    //先把文件通过base64转换为data，写入文件下，在进行转换
    
  NSData*data=[self.messageStr base64DecodedData];
    //设置保存路径
    NSString*str=[NSString stringWithFormat:@"%@/Documents/%ld.amr",NSHomeDirectory(),DTAETIME];
    
    NSString*savePath=[NSString stringWithFormat:@"%@/Documents/%ld.WAV",NSHomeDirectory(),DTAETIME];
    //写入路径
    [data writeToFile:str atomically:YES];
    //进行转换
    [VoiceConverter amrToWav:str wavSavePath:savePath];
    
    //播放声音
    [[ZCChatAVAdioPlay sharedInstance]playSetAvAudio:[NSData dataWithContentsOfFile:savePath]];
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
