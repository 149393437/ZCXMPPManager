//
//  MessageCell.h
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
//用于显示大表情~也就是动态表情
#import "StickerImageView.h"
@interface MessageCell : UITableViewCell
{
//左边
    //头像
    UIImageView*leftHeaderImageView;
    //左边气泡
    UIImageView*leftBubbleImageView;
    //左边语音
    UIButton*leftVoiceButton;
    //左边大表情
    StickerImageView*leftBigImageView;
    //左边文字
    UILabel*leftTitle;
    //左边图片
    UIImageView*leftPhotoImageView;
    
//右边
    //头像
    UIImageView*rightHeaderImageView;
    //右边的气泡
    UIImageView*rightBubbleImageView;
    //右边的语音
    UIButton*rightVoiceButton;
    //右边的大表情
    StickerImageView*rightBigImageView;
    //右边的文字
    UILabel*rightTitle;
    //右边图片
    UIImageView*rightPhotoImageView;
    

}
//气泡图片的路径
@property(nonatomic,copy)NSString*path;
//保存消息
@property(nonatomic,copy)NSString*messageStr;
-(void)configleftImage:(UIImage*)leftImage rightImage:(UIImage*)rightImage Message:(XMPPMessageArchiving_Message_CoreDataObject*)object;

@end








