//
//  MainTabViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "MainTabViewController.h"
//最近联系人
#import "RecentlyViewController.h"
//联系人
#import "FirendViewController.h"
//动态
#import "NewsViewController.h"
//设置
#import "SettingViewController.h"
@interface MainTabViewController ()
@property(nonatomic,copy)NSString*path;
@end

@implementation MainTabViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:THEME object:nil];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createViewControllers];
    [self createTabBarItem];
    //以上2个方法顺序不可改变
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(createTabBarItem) name:THEME object:nil];
    
    
    
    
    
    // Do any additional setup after loading the view.
}
-(void)createTabBarItem{
//建立3个数组
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    NSString*theme=[user objectForKey:THEME];
    //拼接图片路径
    self.path=[NSString stringWithFormat:@"%@%@/",LIBPATH,theme];
    
    
    NSArray*selectImageNameArray=@[@"tab_recent_press.png",@"tab_buddy_press.png",@"tab_qworld_press.png",@"tab_me_press.png"];
    NSArray*unSelectImageNameArray=@[@"tab_recent_nor.png",@"tab_buddy_nor.png",@"tab_qworld_nor.png",@"tab_me_nor.png"];
    NSArray*title=@[@"最近联系人",@"联系人",@"动态",@"我的"];
    
    for (int i=0; i<self.tabBar.items.count; i++) {
        UITabBarItem*item=self.tabBar.items[i];
        
        //选中图片
        UIImage*selectImage=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@%@",self.path,selectImageNameArray[i]]];
        
        //未选中图片
        UIImage*unSelectImage=[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@%@",self.path,unSelectImageNameArray[i]]];
        
        if (iOS7) {
            item=[item initWithTitle:title[i] image:[unSelectImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[selectImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        }else{
            [item setFinishedSelectedImage:selectImage withFinishedUnselectedImage:unSelectImage];
            item.title=title[i];

        }

    }
    
    //设置背景图
    [self.tabBar setBackgroundImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@tabbar_bg.png",self.path]]];
    //修改文字颜色
    if (iOS7) {
        [[UITabBarItem appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}forState:UIControlStateSelected];
    }else{
        [[UITabBarItem appearance]setTitleTextAttributes:@{UITextAttributeTextColor:[UIColor whiteColor]} forState:UIControlStateSelected];
    
    }
    
    [self.tabBar setShadowImage:[[UIImage alloc]init]];
    
}

-(void)createViewControllers{
    //最近联系人
    RecentlyViewController*vc1=[[RecentlyViewController alloc]init];
    vc1.navigationItem.title=@"最近联系人";
    UINavigationController*nc1=[[UINavigationController alloc]initWithRootViewController:vc1];
    //联系人
    FirendViewController*vc2=[[FirendViewController alloc]init];
    vc2.navigationItem.title=@"联系人";
    UINavigationController*nc2=[[UINavigationController alloc]initWithRootViewController:vc2];
    //动态
    NewsViewController*vc3=[[NewsViewController alloc]init];
    vc3.navigationItem.title=@"动态";
    UINavigationController*nc3=[[UINavigationController alloc]initWithRootViewController:vc3];
    //设置
    SettingViewController*vc4=[[SettingViewController alloc]init];
    vc4.navigationItem.title=@"我的";
    UINavigationController*nc4=[[UINavigationController alloc]initWithRootViewController:vc4];
    
    
    self.viewControllers=@[nc1,nc2,nc3,nc4];
 
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
