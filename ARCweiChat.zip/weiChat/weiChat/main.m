//
//  main.m
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZCAppDelegate class]));
    }
}
