//
//  MyVcardViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-6.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "MyVcardViewController.h"
#import "QRCodeGenerator.h"
@interface MyVcardViewController ()<UIAlertViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    //用于判断用户是否更新数据
    BOOL isUpDate;

}
@property(nonatomic,assign)XMPPvCardTemp*myVcard;
@property(nonatomic,strong)NSDictionary*dataDic;
@end

@implementation MyVcardViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self loadData];
    [self createLeftNav];
    
}
-(void)createLeftNav{
    UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 44, 30) ImageName:nil Target:self Action:@selector(backClick) Title:@"返回"];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:button];



}
-(void)backClick{
//执行更新数据
    if (isUpDate) {
    [[ZCXMPPManager sharedInstance]upData:_myVcard];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
-(void)loadData{
//读取名片
    [[ZCXMPPManager sharedInstance]getMyVcardBlock:^(BOOL isFinish, XMPPvCardTemp *myVcard) {
        if (isFinish) {
            //保存myVcard
            self.myVcard=myVcard;
            //组装数据
            [self refresh];
            [_tableView reloadData];
        }
    }];
    
    self.dataArray=[NSMutableArray arrayWithObjects:@"头像",@"昵称",@"签名",@"性别",@"地区",@"二维码",@"手机号", nil];
    [_tableView reloadData];


}
-(void)refresh{
    //组装数据
    
    //对于自定义的节点，我们采用正常的xml解析即可读取
    //[[myVcard elementForName:QMD]stringValue];
    
    //判断是否是空值

    NSString*qmd=[[_myVcard elementForName:QMD]stringValue];
    
    if (qmd==nil) {
        qmd=@"";
    }
    NSString*address=[[_myVcard elementForName:ADDRESS]stringValue];
    if (address==nil) {
        address=@"";
    }
    NSString*sex=[[_myVcard elementForName:SEX]stringValue];
    if (sex==nil) {
        sex=@"";
    }
    NSString*phoneNum=[[_myVcard elementForName:PHONENUM]stringValue];
    if (phoneNum==nil) {
        phoneNum=@"";
    }
    self.dataDic=@{@"头像":_myVcard.photo,@"昵称":UNCODE(_myVcard.nickname),@"签名":UNCODE(qmd),@"性别": UNCODE(sex),@"地区": UNCODE(address),@"二维码": [[NSUserDefaults standardUserDefaults]objectForKey:kXMPPmyJID],@"手机号": UNCODE(phoneNum)};
    


}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStyleGrouped];
    _tableView.delegate =self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"];
        
        UIImageView*imageView=[ZCControl createImageViewWithFrame:CGRectMake(self.view.frame.size.width-60, 0, 44, 44) ImageName:nil];
        imageView.tag=100;
        [cell.contentView addSubview:imageView];
        
    }
    cell.textLabel.text=self.dataArray[indexPath.row];
    
    UIImageView*imageView=(UIImageView*)[cell.contentView viewWithTag:100];
    
    if (indexPath.row==0) {
        //头像
        imageView.hidden=NO;
        imageView.layer.cornerRadius=22;
        imageView.layer.masksToBounds=YES;
        imageView.image=[UIImage imageWithData:self.dataDic[self.dataArray[indexPath.row]]];
        cell.detailTextLabel.text=nil;
        
    }else{
        if (indexPath.row==5) {
            //二维码
            imageView.hidden=NO;
            imageView.layer.cornerRadius=8;
            imageView.layer.masksToBounds=YES;
            //添加第三方库
            NSString*user=self.dataDic[self.dataArray[indexPath.row]];
            //imageSize数值越高越清晰
            UIImage*image=[QRCodeGenerator qrImageForString:user imageSize:300];
            imageView.image=image;
            cell.detailTextLabel.text=nil;

        }else{
            cell.detailTextLabel.text=self.dataDic[self.dataArray[indexPath.row]];
            imageView.hidden=YES;
        }
    
    }
    
    
    return cell;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UILabel*label=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 44) Font:15 Text:[NSString stringWithFormat:@"您的数字账号为：%@",[[NSUserDefaults standardUserDefaults] objectForKey:kXMPPmyJID]]];
    //对齐方式
    label.textAlignment=NSTextAlignmentCenter;
    return label;
}
-(float)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}
-(void)createAlertViewTitle:(NSString*)title tag:(NSInteger)tag{

    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:title delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    
    al.alertViewStyle=UIAlertViewStylePlainTextInput;
    al.tag=tag;
    [al show];
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    switch (indexPath.row) {
        case 0:
            //头像
        {
            UIActionSheet*sheet=[[UIActionSheet alloc]initWithTitle:@"选择照片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册", nil];
            [sheet showInView:self.view];
        }
            break;
        case 1:
            //昵称
            [self createAlertViewTitle:@"请填写一个你喜爱的昵称" tag:indexPath.row];
            break;

        case 2:
            //签名
            [self createAlertViewTitle:@"请填写一个狂拽炫酷的签名" tag:indexPath.row];
            break;

        case 3:
            //性别
            //不可修改
            break;

        case 4:
            //地区
            [self createAlertViewTitle:@"填写你现在的地址" tag:indexPath.row];
            break;

        case 5:
            //二维码  是不可修改，但是我们需要让他进入一个页面，给用户展现
            break;
            
        case 6:
            //手机号 一般会有一些需要要求更改手机号需要验证码或者半年才能更新一次，这样就需要从服务器另外开辟接口去进行验证
            [self createAlertViewTitle:@"填写你的手机号" tag:indexPath.row];
            break;

        default:
            break;
    }

}
#pragma mark 相关代理
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage*image=[info objectForKey:UIImagePickerControllerOriginalImage];
    //把获取的iamge进行压缩，保存在vcard中
    _myVcard.photo=UIImageJPEGRepresentation(image, 0.01);
    isUpDate=YES;
    [self dismissViewControllerAnimated:YES completion:nil];
    //刷新数据
    [self refresh];
    [_tableView reloadData];
    
    
    
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex!=2) {
        UIImagePickerController*picker=[[UIImagePickerController alloc]init];
        picker.delegate=self;
        
        if (buttonIndex) {
            //相册
        }else{
        //相机
            if ([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear]) {
                picker.sourceType=UIImagePickerControllerSourceTypeCamera;
 
            }
            
        }
        
        [self presentViewController:picker animated:YES completion:nil];
    }


}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (buttonIndex) {
        //获取文本输入框的文字
        UITextField*textField=[alertView textFieldAtIndex:0];
        if (textField.text.length==0) {
            return;
        }
        isUpDate=YES;
        ZCXMPPManager*manager=[ZCXMPPManager sharedInstance];
        switch (alertView.tag) {
            case 1:
                //昵称
                _myVcard.nickname=CODE(textField.text);
                
                break;
            case 2:
                //签名
                [manager customVcardXML:CODE(textField.text) name:QMD myVcard:_myVcard];
                break;
            case 4:
                //地区
                [manager customVcardXML:CODE(textField.text) name:ADDRESS myVcard:_myVcard ];
                break;
            case 6:
                //手机号
                [manager customVcardXML:CODE(textField.text) name:PHONENUM myVcard:_myVcard];
                break;
            default:
                break;
        }
        //先刷新数据源
        [self refresh];
        //在刷新表格
        [_tableView reloadData];
    }
    


}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
