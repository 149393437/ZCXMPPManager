
//
//  ThemeViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "ThemeViewController.h"
#import "ThemeManager.h"
@interface ThemeViewController ()

@end

@implementation ThemeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self loadData];
    
}
-(void)loadData{
HttpDownLoadBlock*block=[[HttpDownLoadBlock alloc]initWithStrUrl:@"http://imgcache.qq.com/club/item/theme/json/data_4.6+_3.json?callback=jsonp2" Block:^(BOOL isFinish, HttpDownLoadBlock *http) {
    
    [self jsonValue:http.data];
    
}];
    block=nil;

}
//解析
-(void)jsonValue:(NSData*)data{
//由于不是常规解析，需要进行相关字符串操作
    //转字符串
    NSString*str=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    //计算位置
    NSRange range=[str rangeOfString:@"("];
    NSRange range1=[str rangeOfString:@")"];
    NSString*newStr=[str substringWithRange:NSMakeRange(range.location+1, range1.location-range.location-1)];
    
    //解析
    NSDictionary*dic=[NSJSONSerialization JSONObjectWithData:[newStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
    self.dataArray=[NSMutableArray arrayWithArray:[dic[@"detailList"] allValues]];
    
    [_tableView reloadData];



}

-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
    }
    //读取字典
    NSDictionary*dic=self.dataArray[indexPath.row];
    cell.textLabel.text=dic[@"name"];
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary*dic=self.dataArray[indexPath.row];
    
    ThemeManager*manager=[ThemeManager shareManager];
    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"正在下载哦，🌲" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
    
   BOOL isSucceed =[manager downLoad:dic Block:^(BOOL isFinish) {
        if (isFinish) {
            NSLog(@"下载成功");
        }else{
            NSLog(@"下载失败");
        
        }
       [al dismissWithClickedButtonIndex:0 animated:YES];

    }];
    
    if (isSucceed==NO) {
        [al show];
    }

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
