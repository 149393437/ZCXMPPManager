//
//  SettingViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "SettingViewController.h"
#import "ZCAppDelegate.h"
#import "LoginViewController.h"
#import "ThemeViewController.h"
#import "MyVcardViewController.h"
@interface SettingViewController ()
@property(nonatomic,strong)NSArray*titleArray;
@end

@implementation SettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self loadData];
   

}
//读取数据
-(void)loadData{
    self.dataArray=[NSMutableArray arrayWithArray:@[@"buddy_header_icon_circle_small.png",@"found_icons_readcenter.png",@"circle_schoolmate.png",@"file_icon_picture.png",@"buddy_header_icon_troopGroup_small.png",@"buddy_header_icon_discussGroup_small.png"]];
    self.titleArray=@[@"个人资料",@"主题设置",@"气泡设置",@"聊天背景",@"关于我们",@"反馈"];
    [_tableView reloadData];
    
}
-(void)createTableView{
    NSLog(@"%f",self.view.frame.size.height);
    
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
    }
    
    
    //设置图片
    cell.imageView.image=[UIImage imageNamed:self.dataArray[indexPath.row]];
    //设置文字
    cell.textLabel.text=self.titleArray[indexPath.row];
    
    
    return cell;
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView*view=[ZCControl viewWithFrame:CGRectMake(0, 0, 320, 100)];
    UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(10, 10, self.view.frame.size.width-20, 40) ImageName:nil Target:self Action:@selector(logOut) Title:@"退出当前账号"];
    button.backgroundColor=[UIColor redColor];
    button.layer.cornerRadius=8;
    button.layer.masksToBounds=YES;
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [view addSubview:button];
    return view;
}
-(float)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 60;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
            //个人资料
        {
            MyVcardViewController*vc=[[MyVcardViewController alloc]init];
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
            
            break;
        case 1:
            //主题设置
        {
            ThemeViewController*vc=[[ThemeViewController alloc]init];
            //隐藏tabBar
            vc.hidesBottomBarWhenPushed=YES;
            [self.navigationController pushViewController:vc animated:YES];
        
        }
            break;
        case 2:
            //气泡设置
            break;
            
        case 3:
            //聊天设置
            break;
        case 4:
            //关于我们
            break;
        case 5:
            //反馈
            break;
            
        default:
            break;
    }

}





-(void)logOut{
//首先切断连接
//获取appdelegate的指针
//实例化loginViewController的指针
//切换根目录
    
    [[ZCXMPPManager sharedInstance]disconnect];
    
    ZCAppDelegate*app=[UIApplication sharedApplication].delegate;
    LoginViewController*vc=[[LoginViewController alloc]init];
    [UIView animateWithDuration:0.3 animations:^{
        app.window.rootViewController=vc;
        //删除登录记录
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:isLogin];
    }];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
