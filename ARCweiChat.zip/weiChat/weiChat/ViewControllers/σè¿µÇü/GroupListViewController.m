

//
//  GroupListViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "GroupListViewController.h"
#import "GroupChatViewController.h"
@interface GroupListViewController ()

@end

@implementation GroupListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    //搜索群
    [self loadData];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //创建TableView
    [self createTableView];
 
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"];
    }
    //获取字典
    NSDictionary*dic=self.dataArray[indexPath.row];
    cell.textLabel.text=dic[@"roomName"];
    cell.detailTextLabel.text=dic[@"roomJid"];
    return cell;

}
-(void)loadData{
//搜索群使用的是XMPP中的MUC发现协议，xmppframeWorks中没有，所需要内容是使用xmppStream拼接xml消息，然后通过代理进行截获，得到的，然后从中拆取有效信息，组成数组
    
    [[ZCXMPPManager sharedInstance]searchXmppRoomBlock:^(NSMutableArray *array) {
        
        self.dataArray=array;
        [_tableView reloadData];
        
    }];
    

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//获取房间jid
    NSDictionary*dic=self.dataArray[indexPath.row];
    NSString*jidStr=dic[@"roomJid"];
    GroupChatViewController*vc=[[GroupChatViewController alloc]init];
    vc.hidesBottomBarWhenPushed=YES;
    vc.roomJid=[[jidStr componentsSeparatedByString:@"@"]firstObject];
    [self.navigationController pushViewController:vc animated:YES];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
