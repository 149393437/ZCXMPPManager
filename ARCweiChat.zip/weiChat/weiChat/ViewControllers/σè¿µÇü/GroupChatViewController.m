//
//  GroupChatViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "GroupChatViewController.h"
#import "ZCFaceToolBar.h"
@interface GroupChatViewController ()
{
    ZCXMPPManager *manager;
    ZCFaceToolBar *toolBar;
    XMPPRoom*room;
}
@end

@implementation GroupChatViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc{
    [toolBar removeObserver:self forKeyPath:@"frame"];
    
    //设置退出
    [manager XmppOutRoom:room];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self createToolBar];
    [toolBar addObserver:self forKeyPath:@"frame" options:NSKeyValueObservingOptionNew context:nil];
    
    
    //进入房间
    manager=[ZCXMPPManager sharedInstance];
    self.dataArray=[NSMutableArray arrayWithCapacity:0];

    [self loadData];
    
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    _tableView.frame=CGRectMake(0, 0, self.view.frame.size.width, toolBar.frame.origin.y);
    //产生偏移
    if (self.dataArray.count) {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }

}
-(void)createToolBar{
toolBar=[[ZCFaceToolBar alloc]initWithFrame:CGRectMake(0, 0, 100, 100) voice:nil ViewController:self Block:^(NSString *sign, NSString *message) {
    [manager sendGroupMessage:[NSString stringWithFormat:@"%@%@",sign,message] roomName:self.roomJid];
    
}];
    [self.view addSubview:toolBar];

}
-(void)loadData{
    //xmpp的群聊  群聊属于是类似新浪聊天的类型，进入就可以进行聊天，那么在进入时候，如果没有这个jid则会创建，但是需要注意的是创建分2种方式创建，一种是临时创建的聊天室，当最后一个人退出时候，房间内无人，则会销毁该聊天室，另一种是永久性聊天室，房间不会销毁，另外当你下线时候，会默认退出聊天室
    
  room=[manager xmppRoomCreateRoomName:self.roomJid nickName:@"蜡笔小新" MessageBlock:^(NSDictionary *dic) {
        
        //dic为获得的所有信息 信息的多少服务器设置，可以获得50
        //XMPPMessage本身是一个数据模型
        XMPPMessage*message=dic[@"message"];
        //message.body就是内容
        [self.dataArray addObject:message.body];
        
        [_tableView reloadData];
        //产生偏移
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        
        
        
        
    } presentBlock:^(NSDictionary *dic) {
        //获取主持人，管理者名单
    }];

    


}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, self.view.frame.size.height-[ZCControl isIOS7]-44) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
    }
    
    cell.textLabel.text=self.dataArray[indexPath.row];
    return cell;

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
