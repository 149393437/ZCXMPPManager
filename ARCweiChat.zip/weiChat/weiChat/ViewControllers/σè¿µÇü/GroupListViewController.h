//
//  GroupListViewController.h
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RootViewController.h"

@interface GroupListViewController : RootViewController

@end
