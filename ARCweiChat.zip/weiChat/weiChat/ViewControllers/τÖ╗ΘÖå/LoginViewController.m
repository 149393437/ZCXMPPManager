//
//  LoginViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController1.h"
#import "MainTabViewController.h"
@interface LoginViewController ()<UITextFieldDelegate>
{
    UIImageView*bgImageView;
    UIImageView*logoImageView;
    UIImageView*textBgImageView;
    UITextField*userNameTextField;
    UITextField*passWordTextField;
    UIButton*registerButton;
    UIButton*loginButton;
 
}
@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createBgImageView];
    //观察键盘的弹出和消失
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    
    
}
#pragma mark 键盘的弹出
-(void)keyboardShow:(NSNotification*)notification{
//计算键盘弹出的高度
    int y=[[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey]CGRectValue].size.height;
    
//执行动画
    [UIView animateWithDuration:0.3 animations:^{
        bgImageView.center=CGPointMake(bgImageView.center.x, bgImageView.center.y-y/2);
        //修改logo的缩放
        logoImageView.transform=CGAffineTransformMakeScale(0, 0);
    }];
    
}
#pragma mark 键盘的消失
-(void)keyboardHide:(NSNotification*)notification{
[UIView  animateWithDuration:0.3 animations:^{
   
    bgImageView.center=self.view.center;
    logoImageView.transform=CGAffineTransformMakeScale(1, 1);
    
}];

}

-(void)createBgImageView{
    bgImageView=[ZCControl createImageViewWithFrame:self.view.frame ImageName:@"logo_bg_2.png"];
    //对bgImageView添加点击手势
    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick)];
    [bgImageView addGestureRecognizer:tap];
    
    [self.view addSubview:bgImageView];
    logoImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 120, 120) ImageName:@"logo_2.png"];
    //设置中心点
    int y=80;
    logoImageView.center=CGPointMake(self.view.center.x, y);
    //设置圆角
    logoImageView.layer.cornerRadius=60;
    //设置多余的裁剪
    logoImageView.layer.masksToBounds=YES;
    //在这里需要注意加载在bgImageView上
    [bgImageView addSubview:logoImageView];
    
    //设置输入框背景
    textBgImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 150, 300, 120) ImageName:@"login.png"];
    [bgImageView addSubview:textBgImageView];
    
    //设置输入框
    UIImageView*tempUserName=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 30) ImageName:nil];
    UIImageView*leftUserName=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"userName.png"];
    [tempUserName addSubview:leftUserName];
    
    userNameTextField=[ZCControl createTextFieldWithFrame:CGRectMake(10, 20, 280, 30) placeholder:@"请输入用户名" passWord:NO leftImageView:tempUserName rightImageView:nil Font:15 backgRoundImageName:nil];
    //设置返回按钮
    userNameTextField.returnKeyType=UIReturnKeyNext;
    //设置代理
    userNameTextField.delegate=self;
    
    [textBgImageView  addSubview:userNameTextField];
    
    //密码框
    UIImageView*tempPassImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 30) ImageName:nil];
    UIImageView*leftPassImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"passWord.png"];
    [tempPassImageView addSubview:leftPassImageView];
    passWordTextField=[ZCControl createTextFieldWithFrame:CGRectMake(10, 75, 280, 30) placeholder:@"请输入密码" passWord:YES leftImageView:tempPassImageView rightImageView:nil Font:15 backgRoundImageName:nil];
    //设置返回按钮
    passWordTextField.returnKeyType=UIReturnKeyGo;
    //设置代理
    passWordTextField.delegate=self;
    
    [textBgImageView addSubview:passWordTextField];
    
    
    // 注册
    registerButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 80, 40) ImageName:nil Target:self Action:@selector(registerClick) Title:@"注册"];
    registerButton.center=CGPointMake(self.view.center.x-60, 320);
    [bgImageView addSubview:registerButton];
    //登陆
    loginButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 80, 40) ImageName:nil Target:self Action:@selector(loginClick) Title:@"登陆"];
    loginButton.center=CGPointMake(self.view.center.x+60, 320);
    [bgImageView addSubview:loginButton];

}
#pragma mark 注册
-(void)registerClick{
    RegisterViewController1*vc=[[RegisterViewController1 alloc]init];
    //设置跳转的动画
    vc.modalTransitionStyle=UIModalTransitionStyleFlipHorizontal;
    //设置title文字
    vc.navigationItem.title=@"请输入昵称（1/4）";
    
    //加入导航
    UINavigationController*nc=[[UINavigationController alloc]initWithRootViewController:vc];
    [self presentViewController:nc animated:YES completion:nil];
    
    
}
#pragma mark 登陆
-(void)loginClick{

    if (userNameTextField.text.length>0&&passWordTextField.text.length>0) {
    //执行登陆
        //首先先进行本地存储
        NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
        [user setObject:userNameTextField.text forKey:kXMPPmyJID];
        [user setObject:passWordTextField.text forKey:kXMPPmyPassword];
        [user synchronize];
        
        //XMPP登陆服务器进行验证
        [[ZCXMPPManager sharedInstance]connectLogin:^(BOOL isSucceed) {
            if (isSucceed) {
                NSLog(@"~~~登陆成功");
                
                MainTabViewController*tbc=[[MainTabViewController alloc]init];
                
                [self presentViewController:tbc animated:YES completion:^{
                    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
                    [user setObject:isLogin forKey:isLogin];
                    [user synchronize];
                    
                }];
            }
            
        }];
        
        
    }else{
    //否则提示用户填写完整
        UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"提示" message:@"亲，请填写完整哦~😊" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
        [alert show];
    
    }
    
    
}
#pragma mark 点击手势
-(void)tapClick{
    //结束当前所有编辑
    [self.view endEditing:YES];
    //当结束编辑后，会触发收键盘
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==userNameTextField) {
        [passWordTextField becomeFirstResponder];
    }else{
    //执行登陆
        [self loginClick];
    }
    
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
