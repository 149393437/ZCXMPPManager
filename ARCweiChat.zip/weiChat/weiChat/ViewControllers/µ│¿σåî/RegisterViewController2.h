//
//  RegisterViewController2.h
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterRootViewController.h"

@interface RegisterViewController2 : RegisterRootViewController

@end
