//
//  RegisterViewController4.h
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterRootViewController.h"

@interface RegisterViewController4 : RegisterRootViewController

@end
