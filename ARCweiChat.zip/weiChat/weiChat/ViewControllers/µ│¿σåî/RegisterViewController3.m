//
//  RegisterViewController3.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterViewController3.h"
#import "RegisterViewController4.h"
@interface RegisterViewController3 ()<UITextFieldDelegate>
{
    UITextField*phoneNumTextField;
    UITextField*passWordTextField;
}
@end

@implementation RegisterViewController3

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createNavRightTitle:@"下一步"];
    //设置2个输入框
    [self createTextField];
    
}
#pragma mark 输入框
-(void)createTextField{
    UIImageView*tempPhoneNumImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 40) ImageName:nil];
    UIImageView*phoneNumImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"icon_register_mobile.png"];
    [tempPhoneNumImageView addSubview:phoneNumImageView];
    
    //创建输入手机号的输入框
    phoneNumTextField=[ZCControl createTextFieldWithFrame:CGRectMake(0, 60, self.view.frame.size.width, 40) placeholder:@"请输入手机号" passWord:NO leftImageView:tempPhoneNumImageView rightImageView:nil Font:15 backgRoundImageName:nil];
    //设置返回键
    phoneNumTextField.returnKeyType=UIReturnKeyNext;
    //设置代理
    phoneNumTextField.delegate=self;
    //设置颜色
    phoneNumTextField.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:phoneNumTextField];
    
    UIImageView*tempPassWordImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 40) ImageName:nil];
    UIImageView*passWordImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"icon_register_password.png"];
    [tempPassWordImageView addSubview:passWordImageView];
    //创建密码输入框
    passWordTextField =[ZCControl createTextFieldWithFrame:CGRectMake(0, 101, self.view.frame.size.width, 40) placeholder:@"请输入密码" passWord:YES leftImageView:tempPassWordImageView rightImageView:nil Font:15 backgRoundImageName:nil];
    passWordTextField.returnKeyType=UIReturnKeyGo;
    passWordTextField.delegate=self;
    //设置颜色
    passWordTextField.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:passWordTextField];
}
#pragma mark 导航右按钮
-(void)rightNavClick
{
    if (passWordTextField.text.length>0&&phoneNumTextField.text.length>0) {
        
        //单例存储，进入下一个界面
        RegisterManager*manager=[RegisterManager shareManager];
        manager.passWord=passWordTextField.text;
        manager.phoneNum=phoneNumTextField.text;
    
        RegisterViewController4*vc=[[RegisterViewController4 alloc   ]init];
        vc.navigationItem.title=@"完善资料（4/4）";
        [self.navigationController pushViewController:vc animated:YES];
        
        //进入下一个界面
    }else{
        UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"请填写完整" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [al show];
    
    }
    
}
#pragma mark 输入框代理
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==phoneNumTextField) {
        [passWordTextField becomeFirstResponder];
    }else{
        [self rightNavClick];

    }

    
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
