//
//  RegisterViewController1.m
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterViewController1.h"
#import "RegisterViewController2.h"
@interface RegisterViewController1 ()<UITextFieldDelegate>
{
    //用户名
    UILabel*userName;
    //对账号的详细说明
    UILabel*infoLabel;
    //昵称
    UITextField*nickNameTextField;
    //重试按钮
    UIButton*createUserName;
    //协议的按钮说明注册即表示同意
    UILabel*tempLable;
    UIButton*tempButton;
    
    
    

}
@end

@implementation RegisterViewController1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createNavRightTitle:@"下一步"];
    [self createView];
    
    
}
-(void)createView{
    //创建显示的数字账号
    userName=[ZCControl createLabelWithFrame:CGRectMake(30, 0, 200, 40) Font:15 Text:[NSString stringWithFormat:@"您的数字账号为：%ld",DTAETIME]];
    [self.view addSubview:userName];
    
    infoLabel=[ZCControl createLabelWithFrame:CGRectMake(30, 30, 200, 10) Font:5 Text:@"小诚为您创建数字账号，不满意请点击重试，重新为您生成"];
    [self.view addSubview:infoLabel];
    
    //输入框
    UIImageView*tempImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 30) ImageName:nil];
    UIImageView*leftImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 7, 20, 20) ImageName:@"icon_register_name.png"];
    [tempImageView addSubview:leftImageView];
    nickNameTextField=[ZCControl createTextFieldWithFrame:CGRectMake(0, 44, self.view.frame.size.width, 44) placeholder:@"请输入昵称" passWord:NO leftImageView:tempImageView rightImageView:nil Font:15 backgRoundImageName:nil];
    nickNameTextField.backgroundColor=[UIColor whiteColor];
    nickNameTextField.returnKeyType=UIReturnKeyGo;
    nickNameTextField.delegate=self;
    [self.view addSubview:nickNameTextField];
    
    
    //重试按钮
    createUserName=[ZCControl createButtonWithFrame:CGRectMake(self.view.frame.size.width-60, 10, 44, 30) ImageName:nil Target:self Action:@selector(createUserNameClick) Title:@"重试"];
    [self.view addSubview:createUserName];
    //说明按钮
    tempLable=[ZCControl createLabelWithFrame:CGRectMake(20, 90, 100, 20) Font:10 Text:@"注册即表示同意"];
    [self.view addSubview:tempLable];
    //用户协议
    tempButton=[ZCControl createButtonWithFrame:CGRectMake(90, 95, 100, 10) ImageName:nil Target:self Action:@selector(tempClick) Title:@"<微聊小圈用户协议>"];
    tempButton.titleLabel.font=[UIFont systemFontOfSize:10];
    [tempButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];;
    
    [self.view addSubview:tempButton];
    
    //返回按钮
    UIButton*backButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 44, 30) ImageName:@"header_leftbtn_black_nor.png" Target:self Action:@selector(backClick) Title:@"返回"];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:backButton];
}
#pragma mark 返回
-(void)backClick{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark 用户协议
-(void)tempClick{

}
#pragma mark 重试按钮
-(void)createUserNameClick{
    userName.text=[NSString stringWithFormat:@"您的数字账号为：%ld",DTAETIME];

}
#pragma mark 返回按钮
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //收键盘
    [textField resignFirstResponder];
    [self rightNavClick];
    return YES;
}
#pragma mark 重载的方法
-(void)rightNavClick
{
    //判断是否有输入
    if (nickNameTextField.text.length>0) {
        //使用单例进行记录
        RegisterManager*manager=[RegisterManager shareManager];
        manager.userName=[userName.text substringFromIndex:8];
        manager.nickName=nickNameTextField.text;

        //记录以后 进入下一个界面
        
        RegisterViewController2*vc=[[RegisterViewController2 alloc]init];
        vc.navigationItem.title=@"个人资料（2/4）";
        [self.navigationController pushViewController:vc animated:YES];
        
    }else
    {
        UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"提示" message:@"请填写昵称" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
        [alert show];

    }

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
