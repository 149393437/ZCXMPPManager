//
//  RegisterRootViewController.h
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterRootViewController : UIViewController
//该方法在子类中调用
-(void)createNavRightTitle:(NSString*)title;
//该方法在子类中重载
-(void)rightNavClick;
@end
