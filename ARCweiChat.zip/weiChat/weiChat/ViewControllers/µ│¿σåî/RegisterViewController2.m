
//
//  RegisterViewController2.m
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterViewController2.h"
#import "RegisterViewController3.h"
@interface RegisterViewController2 ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
//头像
    UIButton*headerButton;
//生日蛋糕的图片
    UIImageView*birthdayImageView;
//具体的生日
    UILabel*birthdayLable;
//性别的图片
    UIImageView*sexImageView;
//性别的文字
    UILabel*sexLabel;
//备注
    
    //选择日期的控件
    UIDatePicker*_dataPicker;
    
    //增加2个变量
    BOOL selectSex;
    BOOL selectBirthday;
    BOOL selectHeaderImage;
    

}
@end

@implementation RegisterViewController2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createNavRightTitle:@"下一步"];
    [self createView];
    
    
}
//创建页面
-(void)createView{
    headerButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 120, 120) ImageName:@"icon_register_camera.png" Target:self Action:@selector(headerClick) Title:nil];
    headerButton.center=CGPointMake(self.view.frame.size.width/2, 70);
    
    [self.view addSubview:headerButton];
    
    //设置生日的页面
    UIView*birthdayView=[ZCControl viewWithFrame:CGRectMake(0, 142, self.view.frame.size.width,44)];
    birthdayView.backgroundColor=[UIColor whiteColor];
    birthdayImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"icon_register_birthday.png"];
    [birthdayView addSubview:birthdayImageView];
    
    birthdayLable=[ZCControl createLabelWithFrame:CGRectMake(40, 10,200, 20) Font:10 Text:@"选择你的生日"];
    [birthdayView addSubview:birthdayLable];
    
    UIControl*birthdayControl=[[UIControl alloc]initWithFrame:CGRectMake(0, 0, birthdayView.frame.size.width, birthdayView.frame.size.height)];
    //添加方法
    [birthdayControl addTarget:self action:@selector(birthdayClick) forControlEvents:UIControlEventTouchUpInside];
    [birthdayView addSubview:birthdayControl];
    [self.view addSubview:birthdayView];
    
    UIView*sexView=[ZCControl viewWithFrame:CGRectMake(0, 187, self.view.frame.size.height, 44)];
    sexView.backgroundColor=[UIColor whiteColor];
    sexImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"icon_register_gender.png"];
    [sexView addSubview:sexImageView];
    sexLabel=[ZCControl createLabelWithFrame:CGRectMake(40, 10, 200, 20) Font:10 Text:@"请选择你的性别"];
    [sexView addSubview:sexLabel];
    UIControl *sexControl=[[UIControl alloc]initWithFrame:CGRectMake(0, 0, sexView.frame.size.width, sexView.frame.size.height)];
    [sexControl addTarget:self action:@selector(sexClick) forControlEvents:UIControlEventTouchUpInside];
    [sexView addSubview:sexControl];
    
    [self.view addSubview:sexView];
}
#pragma mark 选择生日
-(void)birthdayClick{
    if (_dataPicker) {
        //执行动画
        [UIView animateWithDuration:0.3 animations:^{
            _dataPicker.frame=CGRectMake(0, self.view.frame.size.height-216, 320, 216);
        }];
        
        return;
    }
    
    //dataPicker是固定大小无法改变，只能设置位置
    _dataPicker=[[UIDatePicker alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height, 320, 216)];
    //设置最小值
    NSDateFormatter*formatter=[[NSDateFormatter alloc]init];
    //设置格式
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date=[formatter dateFromString:@"1900-01-01"];
    [_dataPicker setMinimumDate:date];
    //设置一个最大值
    [_dataPicker setMaximumDate:[NSDate date]];
    
    //dataPicker添加一个方法
    [_dataPicker addTarget:self action:@selector(dataValueChange:) forControlEvents:UIControlEventValueChanged];
    
    [self.view addSubview:_dataPicker];
    
    //执行动画
    [UIView animateWithDuration:0.3 animations:^{
        _dataPicker.frame=CGRectMake(0, self.view.frame.size.height-216, 320, 216);
    }];
    

}
#pragma mark dataPickClick
-(void)dataValueChange:(UIDatePicker*)picke
{
//把时间转换为字符串
    selectBirthday=YES;
    NSDateFormatter*date=[[NSDateFormatter alloc]init];
    [date setDateFormat:@"yyyy-MM-dd"];
    birthdayLable.text=[date stringFromDate:picke.date];
}

#pragma mark 选择性别
-(void)sexClick{
    UIActionSheet*sheet=[[UIActionSheet alloc]initWithTitle:@"选择性别" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"男♂",@"女♀", nil];
    sheet.tag=100;
    [sheet showInView:self.view];
}
#pragma mark 选择头像
-(void)headerClick{
    UIActionSheet*sheet=[[UIActionSheet alloc]initWithTitle:@"请选择设备" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册", nil];
    sheet.tag=200;
    [sheet showInView:self.view];

}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (actionSheet.tag==100) {
        //选择性别
        if (buttonIndex==0) {
            selectSex=YES;
            //男
            sexLabel.text=@"男";
            //修改相应的图标
            sexImageView.image=[UIImage imageNamed:@"icon_register_man.png"];
        }else{
            if (buttonIndex==1) {
                selectSex=YES;
                //女
                sexLabel.text=@"女";
                //修改相应的图标
                sexImageView.image=[UIImage imageNamed:@"icon_register_woman.png"];
            }
            
       
        }
        
        
        
    }else{
    //选择相机或者相册
        UIImagePickerController*picker=[[UIImagePickerController alloc]init];
        
        if (buttonIndex==0) {
            //相机
            if ([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear]) {
                
                picker.sourceType=UIImagePickerControllerCameraDeviceRear;
                
            }else{
            
            }
            
            
        }else{
            if (buttonIndex==2) {
                return;
            }
        
        }
        //设置代理方法
        picker.delegate=self;
        [self presentViewController:picker animated:YES completion:nil];

    }
    

}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //获取图片
    selectHeaderImage=YES;
    UIImage*image=[info objectForKey:UIImagePickerControllerOriginalImage ];
    //赋值
    [headerButton setBackgroundImage:image forState:UIControlStateNormal];
    //单例保存
    RegisterManager*manager=[RegisterManager shareManager];
    manager.headImage=image;
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];

}
//重载方法
-(void)rightNavClick
{
    if (selectHeaderImage==YES&&selectSex==YES&&selectBirthday==YES) {
        //进行记录
        RegisterManager*manager=[RegisterManager shareManager];
        manager.sex=sexLabel.text;
        manager.birthday=birthdayLable.text;
        
    }
    
    
    RegisterViewController3*vc=[[RegisterViewController3 alloc]init];
    vc.navigationItem.title=@"登陆信息（3/4）";
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark 收回dataPicker
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
[UIView animateWithDuration:0.3 animations:^{
    _dataPicker.frame=CGRectMake(0, self.view.frame.size.height, 320, 216);
}];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
