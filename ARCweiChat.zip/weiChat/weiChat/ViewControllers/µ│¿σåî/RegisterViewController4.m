//
//  RegisterViewController4.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterViewController4.h"
#import "MainTabViewController.h"
@interface RegisterViewController4 ()<UITextFieldDelegate>
{
    UITextField*qmdTextField;
    UITextField*addressTextField;

}
@end

@implementation RegisterViewController4

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createNavRightTitle:@"完成"];
    [self createTextField];
    
    // Do any additional setup after loading the view.
}
-(void)createTextField{
    UIImageView*tempQmdImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 40) ImageName:nil];
    UIImageView*qmdImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"icon_edit.png"];
    [tempQmdImageView addSubview:qmdImageView];
    qmdTextField=[ZCControl createTextFieldWithFrame:CGRectMake(0, 60, self.view.frame.size.width, 40) placeholder:@"请给自己起一个很酷的签名" passWord:NO leftImageView:tempQmdImageView rightImageView:nil Font:15 backgRoundImageName:nil];
    qmdTextField.returnKeyType=UIReturnKeyNext;
    qmdTextField.delegate=self;
    qmdTextField.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:qmdTextField];
    
    UIImageView*tempAddressImageView=[ZCControl createImageViewWithFrame:CGRectMake(0, 0, 40, 40) ImageName:nil];
    UIImageView*addressImageView=[ZCControl createImageViewWithFrame:CGRectMake(10, 10, 20, 20) ImageName:@"feed_loc_new.png"];
    [tempAddressImageView addSubview:addressImageView];
    addressTextField=[ZCControl createTextFieldWithFrame:CGRectMake(0, 101, self.view.frame.size.width, 40) placeholder:@"请输入地址" passWord:NO leftImageView:tempAddressImageView rightImageView:nil Font:15 backgRoundImageName:nil];
    
    addressTextField.backgroundColor=[UIColor whiteColor];
    
    addressTextField.returnKeyType=UIReturnKeyGo;
    addressTextField.delegate=self;
    [self.view addSubview:addressTextField];
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//收回键盘
    [self.view endEditing:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==qmdTextField) {
        [addressTextField becomeFirstResponder];
    }else{
    
        [self rightNavClick];
    }

    return YES;
}
-(void)rightNavClick
{
//判断是否为空
    if (qmdTextField.text.length>0&&addressTextField.text.length>0) {
        //开始注册
        
        RegisterManager*manager=[RegisterManager shareManager];
        manager.qmd=qmdTextField.text;
        manager.address=addressTextField.text;
        
        //开始注册
        
        //注册我们需要进行本地记录
        NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
        [user setObject:manager.userName forKey:kXMPPmyJID];
        [user setObject:manager.passWord forKey:kXMPPmyPassword];
        [user synchronize];
        
        ZCXMPPManager*xmppManager=[ZCXMPPManager sharedInstance];
        //执行注册方法
        [xmppManager registerMothod:^(BOOL isSucceed) {
            if (isSucceed) {
                NSLog(@"注册成功");
                
                //登陆，登陆完成以后，完善个人资料
                [xmppManager connectLogin:^(BOOL isSucceed) {
                   
                    if (isSucceed) {
                        NSLog(@"登陆成功");
                        //获取个人信息
                        [xmppManager getMyVcardBlock:^(BOOL isSucceed, XMPPvCardTemp*myVcard ) {
                            if (isSucceed) {
                    //开始更新个人信息
                            //头像
                                myVcard.photo=UIImageJPEGRepresentation(manager.headImage, 0.01);
                            //昵称
                                myVcard.nickname=CODE(manager.nickName);
                            
                             //自定义节点 第一个参数你要设置的值，第二参数是你要设置的key，第三个参数传递你的Vcard
                            //设置性别
                                [xmppManager customVcardXML:CODE(manager.sex) name:SEX myVcard:myVcard];
                            //设置签名
                                [xmppManager customVcardXML:CODE(manager.qmd) name:QMD myVcard:myVcard];
                            //设置地址
                                [xmppManager customVcardXML:CODE(manager.qmd) name:ADDRESS myVcard:myVcard];
                            //设置电话号码
                                [xmppManager customVcardXML:CODE(manager.phoneNum) name:PHONENUM myVcard:myVcard];
                            //设置生日
                                [xmppManager customVcardXML:CODE(manager.birthday) name:BYD myVcard:myVcard];
                            //最后不要忘记，因为以上操作都是一些字符串操作，需要把该数据更新到服务器上
                                [xmppManager upData:myVcard];
                                
                                //同时为了防止数据反复回调造成数据卡死，需要把block指向nil
                                xmppManager.myVcardBlock=nil;
                                
                                
                                
                            }
                            
                            
                            
                        }];
                        //进入主界面
                        MainTabViewController*tbc=[[MainTabViewController alloc]init];
                        [self presentViewController:tbc animated:YES completion:^{
                           
                            NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
                            [user setObject:isLogin forKey:isLogin];
                            [user synchronize];
                            
                        }];
                        
                        
                        
                    }
                    
                }];
                
                
            }
            
        }];
        
        
        
        
        
    }


}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
