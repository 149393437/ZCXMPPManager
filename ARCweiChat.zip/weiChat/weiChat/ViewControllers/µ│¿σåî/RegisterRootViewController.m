
//
//  RegisterRootViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-4.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterRootViewController.h"

@interface RegisterRootViewController ()

@end

@implementation RegisterRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //设置背景颜色 从图像中汲取颜色作为背景色
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"logo_bg_2.png"]];
    
    
}
//设置导航
-(void)createNavRightTitle:(NSString*)title{
//title主要有下一步和完成
    //设置导航的title颜色，大小，这个需要判断版本
    
    if (iOS7) {
        //[UINavigationBar appearance]是针对没有创建的有效，对已经创建的无效
[self.navigationController.navigationBar setTitleTextAttributes:@{
        NSFontAttributeName:[UIFont boldSystemFontOfSize:15],NSForegroundColorAttributeName:[UIColor purpleColor]
                            }];
        
        
    }else{
        [self.navigationController.navigationBar   setTitleTextAttributes:@{UITextAttributeFont:[UIFont boldSystemFontOfSize:15],UITextAttributeTextColor:[UIColor purpleColor]}];
    
    }
    
    //设置导航为不透明
    self.navigationController.navigationBar.translucent=NO;
    
    //右边导航按钮
    UIButton*rightButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 60, 30) ImageName:nil Target:self Action:@selector(rightNavClick) Title:title];
    //右导航
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    
}
#pragma mark 在子类中重载
-(void)rightNavClick{

    

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
