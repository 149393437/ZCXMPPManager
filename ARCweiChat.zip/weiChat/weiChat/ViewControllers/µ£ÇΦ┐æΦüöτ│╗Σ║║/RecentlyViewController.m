//
//  RecentlyViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RecentlyViewController.h"
#import "ZCMessageObject.h"
#import "ChatViewController.h"
#import "GroupChatViewController.h"
@interface RecentlyViewController ()

@end

@implementation RecentlyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    //判断是否需要登录
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    NSString* islogin=[user objectForKey:isLogin];
    
    if (islogin) {
    //直接在主界面，需要执行登录操作
        [[ZCXMPPManager sharedInstance]connectLogin:^(BOOL isSucceed) {
            if (isSucceed) {
                NSLog(@"在最近联系人中执行的登录");
            }
        }];
    }else{
    //是从登录界面直接过来的,无需执行操作

    }
    
    
    [self createTableView];
    //获得数据
    [self loadData];
    
    //建立通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loadData) name:kXMPPNewMsgNotifaction object:nil];
    
    
}
-(void)loadData{
    //获取20条最新联系人信息
    self.dataArray=[ZCMessageObject fetchRecentChatByPage:20];
    
    NSLog(@"%@",self.dataArray);
    [_tableView reloadData];
    
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];


}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ID"];
    }
    NSArray*array=self.dataArray[indexPath.row];
    cell.textLabel.text=array[2];
    //消息类型
    NSString*str=[array firstObject];
    NSString*message;
    if (str.length>3) {
        message=[str substringFromIndex:3];
    }else{
    message=@"未知消息";
    }
    if ([str hasPrefix:MESSAGE_STR]) {
        cell.detailTextLabel.text=message;
    }else{
        if ([str hasPrefix:MESSAGE_BIGIMAGESTR]) {
            cell.detailTextLabel.text=@"大表情";
        }else{
            if ([str hasPrefix:MESSAGE_VOICE]) {
                cell.detailTextLabel.text=@"语音";
            }else{
                if ([str hasPrefix:MESSAGE_IMAGESTR]) {
                    cell.detailTextLabel.text=@"图片";
                    
                }else{
                    cell.detailTextLabel.text=@"未知类型";
                }
            }
        
        }
    
    }
    
    
    
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//获取用户的jid
    NSString*jid=self.dataArray[indexPath.row][2];
    //判断是群聊还是单聊
    NSString*type=[self.dataArray[indexPath.row] lastObject];
    if ([type isEqualToString:GROUPCHAT]) {
        //群聊
        GroupChatViewController*vc=[[GroupChatViewController alloc]init];
        vc.hidesBottomBarWhenPushed=YES;
        vc.roomJid=jid;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else{
    //单聊
        ChatViewController*vc=[[ChatViewController alloc]init];
        vc.firendJid=jid;
        vc.hidesBottomBarWhenPushed=YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    }


}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
