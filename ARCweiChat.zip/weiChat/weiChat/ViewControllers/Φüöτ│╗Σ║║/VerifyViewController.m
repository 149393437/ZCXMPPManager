
//
//  VerifyViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-6.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "VerifyViewController.h"

@interface VerifyViewController ()

@end

@implementation VerifyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self loadData];
    
    
}
-(void)loadData{
    self.dataArray=[ZCXMPPManager sharedInstance].subscribeArray;
    
    [_tableView reloadData];

}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
        UIButton*agree=[ZCControl createButtonWithFrame:CGRectMake(self.view.frame.size.width-80, 0, 60, 30) ImageName:nil Target:self Action:@selector(agreeClick:) Title:@"同意"];
        [cell.contentView addSubview:agree];
        
        UIButton*reject=[ZCControl createButtonWithFrame:CGRectMake(self.view.frame.size.width-40, 0, 60, 30) ImageName:nil Target:self Action:@selector(rejectClick:) Title:@"拒绝"];
        [cell.contentView addSubview:reject];
    
        
    }
    
    cell.contentView.tag=indexPath.row;
    
    XMPPPresence *presence=self.dataArray[indexPath.row];
    //获取账号
    cell.textLabel.text=presence.from.user;
    
    
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;

}
//同意
-(void)agreeClick:(UIButton*)button{
    int tag=button.superview.tag;
    XMPPPresence*presence=self.dataArray[tag];
    
    //同意请求
    [[ZCXMPPManager sharedInstance] agreeRequest:presence.from.user];
    //同意后马上重新请求数据，防止越界崩溃
    [self loadData];

}
//拒绝
-(void)rejectClick:(UIButton*)button{
    XMPPPresence*presence=self.dataArray[button.superview.tag];
    //拒绝请求
    [[ZCXMPPManager sharedInstance]reject:presence.from.user];
    [self loadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
