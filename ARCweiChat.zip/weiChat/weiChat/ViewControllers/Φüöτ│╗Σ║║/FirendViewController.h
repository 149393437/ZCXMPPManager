//
//  FirendViewController.h
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RootViewController.h"

@interface FirendViewController : RootViewController
{
    //用于记录展开和闭合的数组
    int isOpen[4];
    
    //好友请求的按钮
    UIButton*verifyButton;
    

}
@property(nonatomic,strong)NSArray*titleArray;
@end








