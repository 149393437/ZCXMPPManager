//
//  ChatViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "ChatViewController.h"
#import "ZCFaceToolBar.h"
#import "MessageCell.h"
#import "Photo.h"
@interface ChatViewController ()
{
    ZCFaceToolBar*toolBar;
    ZCXMPPManager*manager;
}
@end

@implementation ChatViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc{
    [toolBar removeObserver:self forKeyPath:@"frame"];
    //不在通过回调来进行记录消息，记住一定不要写在viewWillDisappear,
    [manager valuationChatPersonName:nil IsPush:NO MessageBlock:nil];

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self createFaceToolBar];
    
    //使用kvo观察toolBar的坐标值变化
    [toolBar addObserver:self forKeyPath:@"frame" options:NSKeyValueObservingOptionNew context:nil];
    
    //进入之后先设置聊天的对象
    manager=[ZCXMPPManager sharedInstance];
    
    [manager valuationChatPersonName:[NSString stringWithFormat:@"%@@%@",self.firendJid,DOMAIN] IsPush:YES MessageBlock:^(ZCMessageObject *message) {
    //收到关于这个用户的消息，需要重新读取数据
        [self loadData];
    }];
    
    [self loadData];
    
    
    //获得自己的头像
    [manager getMyVcardBlock:^(BOOL isFinish, XMPPvCardTemp *vcard) {
        if (isFinish) {
            UIImage*image;
            if (vcard.photo) {
                image=[UIImage imageWithData:vcard.photo];
            }else{
                image=[UIImage imageNamed:@"logo_2.png"];
            }
            self.myHeaderImage=image;
            [_tableView reloadData];
        }
    }];
    [[ZCXMPPManager sharedInstance]friendsVcard:self.firendJid Block:^(BOOL isFinish, XMPPvCardTemp *firendVcard) {
        if (isFinish) {
            UIImage*image;
            if (firendVcard.photo) {
                image=[UIImage imageWithData:firendVcard.photo];
            }else{
                image=[UIImage imageNamed:@"logo_2.png"];
            }
            self.firendHeaderImage=image;
            [_tableView reloadData];
        }
        
    }];
    
    
    
}
-(void)loadData{
//获得数据
    self.dataArray=[NSMutableArray arrayWithArray:[manager messageRecord]];
   
    if (self.dataArray.count) {
        [_tableView reloadData];
        //进行偏移
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
//接收到值的变化
    _tableView.frame=CGRectMake(0, 0, self.view.frame.size.width, toolBar.frame.origin.y);
    
    //信息进行相应的偏移
    if (self.dataArray.count) {
          [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
    
  

}
-(void)createFaceToolBar{
toolBar=[[ZCFaceToolBar alloc]initWithFrame:CGRectMake(0, 0, 100, 30) voice:nil ViewController:self Block:^(NSString *sign, NSString *str) {
    //sign 发送的类型    str为内容

    [manager sendMessageWithJID:self.firendJid Message:str Type:sign];
    //0.1秒后刷新数据
    [self performSelector:@selector(loadData) withObject:nil afterDelay:0.1];
}];
    
    [self.view addSubview:toolBar];

}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]-44) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    //线隐藏
    _tableView.separatorStyle=UITableViewCellSeparatorStyleNone;

    [self.view addSubview:_tableView];
    
    //对tableView添加手势
    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(xx)];
    [_tableView addGestureRecognizer:tap];
    
    
}
-(void)xx{
    [toolBar dismissKeyBoard];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MessageCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[MessageCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.backgroundColor=[UIColor clearColor];
    }
    //这里需要自定义cell
    //获取数据源
    XMPPMessageArchiving_Message_CoreDataObject*object=self.dataArray[indexPath.row];
    
    //获取发送的内容
    
    //cell.textLabel.text=object.body;
    [cell configleftImage:self.firendHeaderImage rightImage:self.myHeaderImage Message:object];
    
    return cell;

}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//不同类型设置不同的行高
    XMPPMessageArchiving_Message_CoreDataObject*object=self.dataArray[indexPath.row];
    NSString*message=[object.body substringFromIndex:3];
    
    if ([object.body hasPrefix:MESSAGE_STR]) {
        //计算文字大小
        CGSize size=[message sizeWithFont:[UIFont systemFontOfSize:10] constrainedToSize:CGSizeMake(200, 1000)];
        return size.height+20;
        
    }else{
        if ([object.body hasPrefix:MESSAGE_IMAGESTR]) {
            UIImage*image=[Photo string2Image:message];
            return image.size.height+20;
        }else{
            if ([object.body hasPrefix:MESSAGE_VOICE]) {
                return 60;
            }else{
                if ([object.body hasPrefix:MESSAGE_BIGIMAGESTR]) {
                    return 220;
                }
            
            }
        
        
        }
    
    
    }
    
    return 0;

    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
