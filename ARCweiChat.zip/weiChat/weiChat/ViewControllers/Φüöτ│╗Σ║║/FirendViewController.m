
//
//  FirendViewController.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "FirendViewController.h"
#import "VerifyViewController.h"
#import "ChatViewController.h"
@interface FirendViewController ()<UIAlertViewDelegate>

@end

@implementation FirendViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [self loadData];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.titleArray=@[@"我的好友",@"被关注",@"关注",@"陌生人"];
    [self createTableView];
    
    
}


-(void)loadData{
    //函数直接返回就是好友列表，block回调代表有新的好友加入你的好友列表，我们需要重新读取数据，来获得新的还有列表
    
    NSArray*array=[[ZCXMPPManager sharedInstance]friendsList:^(BOOL isFinish) {
        [self loadData];
    }];
    
    self.dataArray=[NSMutableArray arrayWithArray:array];
    
    //重新获取现在有多少条请求
    int num=[ZCXMPPManager sharedInstance].subscribeArray.count;
    if (num) {
        [verifyButton setTitle:[NSString stringWithFormat:@"您有%d条好友请求",num] forState:UIControlStateNormal];
    }else{
        [verifyButton setTitle:@"未有新消息" forState:UIControlStateNormal];
    }
    
    
    [_tableView reloadData];
    
    
}
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-[ZCControl isIOS7]-49) style:UITableViewStyleGrouped];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    [self.view addSubview:_tableView];
    
    //显示多少条好友请求
    verifyButton=[ZCControl createButtonWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44) ImageName:nil Target:self Action:@selector(verifyClick) Title:@"未有新消息"];
    _tableView.tableHeaderView=verifyButton;

}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return isOpen[section]?0:[self.dataArray[section] count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
    }
    //读取数据源
    XMPPUserCoreDataStorageObject*object=self.dataArray[indexPath.section][indexPath.row];
    //获得对方账号
    NSString*firendJid=[[object.jidStr componentsSeparatedByString:@"@"]firstObject];
    //获得这个好友的名片
    [[ZCXMPPManager sharedInstance]friendsVcard:firendJid Block:^(BOOL isFinish, XMPPvCardTemp *vcard) {
        if (vcard.nickname) {
            cell.textLabel.text=vcard.nickname;
        }else{
            cell.textLabel.text=firendJid;
        }
        
    }];
    
    cell.textLabel.text=firendJid;
    
    //获得头像
    cell.imageView.image=[[ZCXMPPManager sharedInstance]avatarForUser:object];
    
    return cell;

}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArray.count;
}
//分组
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UILabel*label=[ZCControl createLabelWithFrame:CGRectMake(0, 0, 320, 30) Font:15 Text:self.titleArray[section]];
    
    label.userInteractionEnabled=YES;
    
    UIControl*control=[[UIControl alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 30)];
    
    [control addTarget:self action:@selector(openClick:) forControlEvents:UIControlEventTouchUpInside];
    
    control.tag=section;
    
    [label addSubview:control];
    
    return label;
}

-(float)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

-(void)openClick:(UIControl*)control{
    isOpen[control.tag]=!isOpen[control.tag];
    //刷新某一行
    [_tableView reloadSections:[NSIndexSet indexSetWithIndex:control.tag] withRowAnimation:UITableViewRowAnimationLeft];

}
//点击进入显示请求的按钮
-(void)verifyClick{
    VerifyViewController*vc=[[VerifyViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];

}
//重写父类方法,当接收到通知的时候，此方法也会调用
-(void)themeMothod
{
    UIButton*button=[ZCControl createButtonWithFrame:CGRectMake(0, 0, 30,30) ImageName:nil Target:self Action:@selector(addfriend) Title:nil];
    
    [button setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@header_icon_add.png",self.path]] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:button];
    
    
    

}
-(void)addfriend{
    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"请输入对方的数字账号" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    al.alertViewStyle=UIAlertViewStylePlainTextInput;
    [al show];
    
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex) {
        UITextField*textField=[alertView textFieldAtIndex:0];
        if (textField.text.length) {
            [[ZCXMPPManager sharedInstance]addSomeBody:textField.text Newmessage:nil];
            
        }
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//获取对方账号
    XMPPUserCoreDataStorageObject*object=self.dataArray[indexPath.section][indexPath.row];
    ChatViewController*vc=[[ChatViewController alloc]init];
    vc.firendJid=[[object.jidStr componentsSeparatedByString:@"@"]firstObject];
    vc.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:vc animated:YES];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
