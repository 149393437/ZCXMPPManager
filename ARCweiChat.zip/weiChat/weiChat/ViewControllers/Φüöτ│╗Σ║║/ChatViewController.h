//
//  ChatViewController.h
//  weiChat
//
//  Created by 张诚 on 14-10-7.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RootViewController.h"

@interface ChatViewController : RootViewController
//firendJid,好友的账号
@property(nonatomic,copy)NSString*firendJid;
//需要记录我的头像
@property(nonatomic)UIImage*myHeaderImage;
//记录好友的头像
@property(nonatomic)UIImage*firendHeaderImage;

@end






