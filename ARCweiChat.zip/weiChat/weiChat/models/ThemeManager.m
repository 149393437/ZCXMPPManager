
//
//  ThemeManager.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "ThemeManager.h"
#import "ZipArchive.h"
@implementation ThemeManager
static ThemeManager *manager=nil;
+(id)shareManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager=[[ThemeManager alloc]init];
    });
    
    return manager;
}
-(id)init
{
    if (self=[super init]) {
        //获取存储主题的文件路径
        NSString*path=[NSString stringWithFormat:@"%@%@.plist",LIBPATH,THEME];
        //打开这个plist
        self.dataArray=[NSMutableArray arrayWithContentsOfFile:path];
        if (self.dataArray==nil) {
            self.dataArray=[NSMutableArray arrayWithCapacity:0];
        }
        
        
    }
    return self;

}
-(BOOL)downLoad:(NSDictionary *)dic Block:(void (^)(BOOL))a
{
    //保存block
    self.downLoad=a;
    //保存主题名称
    self.tempTheme=dic[@"name"];
    //判断是否已经存在
    if ([self.dataArray containsObject:self.tempTheme]) {
        //如果存在直接返回
        NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
        [user setObject:self.tempTheme forKey:THEME];
        [user synchronize];
        //发送通知
        [[NSNotificationCenter defaultCenter]postNotificationName:THEME object:nil];
        return YES;
    }else{
    //如果不存在就进行下载
        HttpDownLoadBlock*request=[[HttpDownLoadBlock alloc]initWithStrUrl:dic[@"url"] Block:^(BOOL isFinish, HttpDownLoadBlock *http) {
            if (isFinish) {
                
                [self saveData:http.data];
                
            }else{
                if (self.downLoad) {
                    self.downLoad(NO);
                }
            
            }
            
        }];
        request=nil;
    
    
    
    }
    
    return NO;

}
-(void)saveData:(NSData*)data{
    //写入到沙盒目录
    NSString*path=[NSString stringWithFormat:@"%@data.zip",LIBPATH];
    //写入为data.zip,由于已经存在，再次写入会覆盖
    [data writeToFile:path atomically:YES];
    //写入完成后，解压缩
    NSString*toPath=[NSString stringWithFormat:@"%@%@",LIBPATH,self.tempTheme];
    ZipArchive*zip=[[ZipArchive alloc]init];
    [zip UnzipOpenFile:path];
    [zip UnzipFileTo:toPath overWrite:YES];
    [zip UnzipCloseFile];
    
    //解压缩完成后，保存在主题
    NSUserDefaults*user=[NSUserDefaults standardUserDefaults];
    [user setObject:self.tempTheme forKey:THEME];
    [user synchronize];
    
    //保存主题后，追加已经下载完的目录
    [self.dataArray addObject:self.tempTheme];
    //追加完目录后，写入plist，持久化保存
    [self.dataArray writeToFile:[NSString stringWithFormat:@"%@%@.plist",LIBPATH,THEME] atomically:YES];
    //持久化保存，发送广播
    [[NSNotificationCenter defaultCenter]postNotificationName:THEME object:nil];
    //发送广播，调用回调
    if (self.downLoad) {
        self.downLoad(YES);
    }
    


}

@end





