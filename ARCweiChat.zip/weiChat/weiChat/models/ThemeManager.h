//
//  ThemeManager.h
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThemeManager : NSObject
@property(nonatomic,copy)NSString*tempTheme;
//记录block指针
@property(nonatomic,copy)void(^downLoad)(BOOL);
@property(nonatomic,strong)NSMutableArray*dataArray;

+(id)shareManager;

//下载方法 函数直接的返回值是判断有没有可用缓存，block判断是否下载完成
-(BOOL)downLoad:(NSDictionary*)dic Block:(void(^)(BOOL))a;

@end







