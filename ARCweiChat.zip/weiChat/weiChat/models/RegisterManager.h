//
//  RegisterManager.h
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RegisterManager : NSObject
@property(nonatomic,copy)NSString*userName;
@property(nonatomic,copy)NSString*passWord;
@property(nonatomic,copy)NSString*sex;
@property(nonatomic,copy)NSString*birthday;
@property(nonatomic,copy)NSString*phoneNum;
@property(nonatomic,copy)NSString*address;
@property(nonatomic,copy)NSString*nickName;
@property(nonatomic,copy)NSString*qmd;
@property(nonatomic)UIImage*headImage;

+(id)shareManager;
@end
