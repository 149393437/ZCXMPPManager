
//
//  RegisterManager.m
//  weiChat
//
//  Created by 张诚 on 14-10-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "RegisterManager.h"

@implementation RegisterManager
static RegisterManager*manager=nil;
+(id)shareManager{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager=[[RegisterManager alloc]init];
    });
    return manager;

}



@end
