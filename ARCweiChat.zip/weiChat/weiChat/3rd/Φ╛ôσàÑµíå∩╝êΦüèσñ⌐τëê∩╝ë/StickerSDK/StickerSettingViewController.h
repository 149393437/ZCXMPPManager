//
//  StickerSettingViewController.h
//  StickerSDKDemo
//
//  Created by mike on 13-11-19.
//  Copyright (c) 2013年 dong mike. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PackageSettingCell.h"

@interface StickerSettingViewController : UIViewController <PackageSettingCellDelegate, UITableViewDataSource, UITableViewDelegate>

@end
