//
//  MoreStickerViewController.h
//  StickerSDKDemo
//
//  Created by mike on 13-11-12.
//  Copyright (c) 2013年 dong mike. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PackageTableCell.h"

@interface MoreStickerViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, PackageTableCellDelegate>

@end
