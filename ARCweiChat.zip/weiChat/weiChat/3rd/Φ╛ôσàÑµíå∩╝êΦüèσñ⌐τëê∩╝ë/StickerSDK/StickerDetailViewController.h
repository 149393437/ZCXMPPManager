//
//  StickerDetailViewController.h
//  StickerSDKDemo
//
//  Created by mike on 13-11-14.
//  Copyright (c) 2013年 dong mike. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PackageInfo.h"

@interface StickerDetailViewController : UIViewController

-(id)initWithPackageInfo:(PackageInfo *)package;

@end
